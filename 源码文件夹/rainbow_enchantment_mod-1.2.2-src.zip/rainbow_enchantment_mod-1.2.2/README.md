# 彩虹附魔 · rainbow_enchantment_mod

Minecraft **1.20.1** / **Forge** 模组。

| | |
|---|---|
| 模组 ID | `rainbow_enchantment_mod` |
| 版本 | **1.2.2** |
| 显示名 | 彩虹附魔 |
| 作者 | 1766702633@qq.com |
| 许可 | All Rights Reserved |
| 内容 | 38 个附魔 · 9 个状态效果 · 3 个自定义伤害类型 |

成品 jar 就在本目录：`rainbow_enchantment_mod-1.2.2.jar`
（`./gradlew build` 生成的同名产物在 `build/libs/`）

---

## 一、安装

1. 装好 Minecraft **1.20.1** 与对应版本的 **Forge**；
2. 把 `rainbow_enchantment_mod-1.2.0.jar` 放进 `.minecraft/mods/`；
3. 启动游戏。

> ⚠ **同一个 `mods/` 目录里不要同时放两个版本的 jar。** 模组 ID 相同，Forge 会判定为重复模组并拒绝启动。
> 升级时请先删掉旧 jar。

配置文件在 `config/rainbow_enchantment_mod-common.toml`，首次启动自动生成。

---

## 二、从源码构建

需要 **JDK 17**（Forge 1.20.1 的要求）。

```bash
./gradlew build          # Windows: gradlew.bat build
```

产物：`build/libs/rainbow_enchantment_mod-1.2.0.jar`

开发时常用：

```bash
./gradlew build        # 打包
./gradlew runClient    # 启动开发客户端（手测用）
./gradlew runServer    # 启动开发服务端
```

> 如果你的默认 JDK 不是 17，有两种办法：
> 用 `-Dorg.gradle.java.home=/path/to/jdk-17` 传参，
> 或在 `gradle.properties` 里加一行 `org.gradle.java.home=...`。

---

## 三、目录结构

```
src/main/java/cn/autoforged/rainbow_enchantment_mod/
├── RainbowEnchantmentMod.java      @Mod 入口：注册配置 / 附魔 / 效果 / 创造栏
├── ModCreativeTab.java             创造模式「附魔」页签
├── config/
│   ├── ModConfig.java              全部配置项（COMMON）
│   └── ConfigAutoFixer.java        配置文件损坏自修复
├── client/WindChargeHud.java       千风之力蓄力进度条（客户端 HUD）
├── damage/ModDamageTypes.java      3 个自定义伤害类型
├── effect/                         9 个自定义状态效果
├── enchantment/                    38 个附魔 + 注册表
│   └── StarTreasureMinerals.java   星光财宝的 17 类矿物表（数值唯一来源）
├── mixin/StarTreasureMixin.java    注入 ItemStack#getMaxDamage（星光财宝的最大耐久）
├── event/
│   ├── ModEvents.java              模组绝大部分逻辑
│   └── ClientModEvents.java        客户端侧（tooltip 等）
└── particle/ParticleEffectManager.java   扩散类特效的服务端状态机

src/main/resources/
├── META-INF/accesstransformer.cfg  访问转换器（SRG 名）
├── assets/rainbow_enchantment_mod/lang/{en_us,zh_cn}.json
└── data/
    ├── rainbow_enchantment_mod/{advancements,damage_type}
    └── minecraft/tags/damage_type/  对原版伤害类型标签的补充

src/main/templates/                 mods.toml / pack.mcmeta（Gradle 展开 ${...} 占位符）
.github/workflows/build.yml         CI：ubuntu + JDK 21 跑 ./gradlew build
changelog.txt                       版本历史
```

---

## 四、改代码时的注意事项

- **模组 ID 不要随意改。** `gradle.properties` 里的 `mod_id` 必须与 `@Mod(...)` 的 `MOD_ID` 常量一致，
  `assets/<mod_id>` 目录名、语言文件的 key 前缀、以及生成的 `<mod_id>-common.toml` 文件名都要跟着改，
  改 ID 等于换配置文件。

- **`gradle.properties` 里的中文必须保持 `\uXXXX` 转义。** 该文件按 ISO-8859-1 读取，
  直接写中文会在模组列表里显示成乱码。

- **`mods.toml` 的字符集是个坑。** `generateModMetadata` 与 `processResources` 都已显式设置
  `filteringCharset = 'UTF-8'`，**别删**：Gradle 的 `expand` 默认按平台字符集写文件
  （中文 Windows 上是 GBK），而 Forge 按 UTF-8 解析 `mods.toml`，
  轻则模组列表乱码，重则 TOML 解析失败、启动即崩。

- **`META-INF/accesstransformer.cfg` 别删。** 源码直接访问了几个非公开成员：
  `ItemEntity.health`（private）、`ThrownTrident.getPickupItem()`（protected）、
  `MobEffectInstance.duration` / `amplifier`（private）。
  注意该文件用的是 **SRG 名**（`f_31987_` / `m_7941_` / `f_19503_` / `f_19504_`），不是官方名。

- **改访问转换器、或换 Forge / MC 版本会触发 MC 产物重建**，需要能联网。

- **`event/ModEvents.java` 是巨石类**：38 个附魔的逻辑几乎都在里面，
  按 `@SubscribeEvent` 方法名定位（`onLivingHurt`、`onLivingTick`、`onUndyingTick`、
  `handleSpaceSlash`、`onItemFished`、`onLevelTick` …）。

- **星光财宝的数值只在 `StarTreasureMinerals` 一处改。** 锻造（`handleStarTreasureAnvil`）、
  属性计算（`handleStarTreasureAttribute`）与 tooltip（`ClientModEvents`）都读那张枚举表，
  别在别处再抄一份数字。

- **星光财宝的「耐久 +N」靠 Mixin 实现。** Forge 1.20.1 没有出口能改大物品最大耐久：
  属性系统的 `MAX_DAMAGE` 是 MC 1.21 才加的（这里没有该常量）、
  `ItemStack#getMaxDamage()` 不是扩展点也没有对应事件。
  所以 `mixin/StarTreasureMixin.java` 注入 `ItemStack#getMaxDamage()`，把点数加到最大耐久上。
  `durability_mode` 控制它是否生效（`NONE` / `RESTORE_ON_BREAK` 时跳过）。

- **Mixin 的 refmap 由注解处理器自动生成，不要手写、也不要把它加进版本库。**
  构建走的是 MDG legacyforge 自带的 `mixin { }` 扩展（`build.gradle` 顶部）：
  `add sourceSets.main, "…refmap.json"` 把 Mixin 注解处理器接进 `compileJava`，
  生成物落在 `build/mixin/`（已被 `.gitignore` 覆盖），并自动进 jar；
  `config "…mixins.json"` 让 MDG 给每个 dev run 自动补 `--mixin.config`。
  因此**新增/改动 mixin 引用时不需要同步任何映射表**，改完源码直接构建即可。

  两点仍然要记住：
  1. `org.spongepowered:mixin:<版本>:processor` 必须自己声明，而且它的仓库
     （`repo.spongepowered.org`）也要声明——该工件不在 Maven Central 上。
     版本要与 Forge 运行时用的 Mixin 一致（1.20.1 / Forge 47.x 是 0.8.5）。
  2. `jar` 的 manifest 里那行 `MixinConfigs` 不能删：正式环境就是靠它加载配置的
     （dev 环境没有 manifest，靠的是 `--mixin.config` 程序参数）。

  `build/moddev/serverRunProgramArgs.txt` 可以直接看到最终传给游戏的参数；
  `verifyDevMixinConfig` 任务会断言每个 dev run 都带上了 `--mixin.config`，
  谁把 `mixin { config … }` 删了都会当场构建失败（这个坑踩过一次：删掉之后
  游戏照常启动、日志一个字不提、注入静默失效）。

  > 历史备注：本项目此前是手写 refmap + `verifyMixinRefmap` 反查 SRG 名。
  > 那套已经被手写 refmap 的「格式看着合理但无效、构建照样能过」坑过一次，现已删除。

- **附魔描述（`enchantment.<modid>.<名称>.desc`）本模组自己不读取**，是留给「附魔描述」类模组的
  社区约定键（最常用的是 [Enchantment Descriptions](https://modrinth.com/mod/enchantment-descriptions) /
  [附魔描述](https://www.mcmod.cn/class/1945.html)，modid `enchdesc`）。它把描述插在附魔名的下一行，
  文字颜色由**它自己的** `<实例>/config/enchdesc.json` 里的 `style` 决定。
  因此这 37 条 `.desc` 的值**统一以 `§7`（灰）开头**：无论渲染者是哪个模组、配置里写没写颜色，
  描述都会是原版附魔名那种灰（`#AAAAAA`）而不是默认的纯白。
  > 已知代价：`§7` 是原版格式码，mcmod/百科之类直接读 lang 的站点会把它原样显示出来。
  > 如果更在意那边干净，把这 37 条的 `§7` 去掉，并让使用者在 `enchdesc.json` 里设
  > `"style": { "color": "gray" }`（该模组默认的 `dark_gray` 比附魔名更暗）。

- **附魔名后面的等级后缀由 `ModEnchantment#getFullname` 自己拼。** 原版的
  `enchantment.level.*` 只定义到 10，而**判决最高 30 级**、**永恒最高级来自 `eternal_max_level`
  配置（默认 20）**，照原版走会让 `enchantment.level.11` 这样的 key 直接漏在名字后面
  （表现为「附魔名后面挂一段英文」）。所以这里改成：等级键存在就照原版走，缺失则用本地罗马数字兜底。

- **不死附魔的「保护窗口」只有一个权威来源**：`UndyingGuard` 里我们自己记的到期游戏刻。
  不再读冥界花效果是否存在（效果可以被别人清掉，效果只作展示并在窗口内自动补挂）。
  窗口内的死亡拦截分四道门（死亡调用 / 濒死判定 / 死亡计时 / 移除标记）+ 一道自愈，
  由 `LivingEntityGuardMixin`、`PlayerGuardMixin`、`ServerPlayerGuardMixin`、`EntityGuardMixin`
  织入；客户端只加一道最小拦截（不打开死亡界面），见 `ClientPacketListenerGuardMixin`。
  改这里必须守住三条：**不点名任何别的模组、所有回调包异常并放行、日志限频**。
  ⚠️ 尤其**不要在「界面即将打开」的回调里调用开界面方法** —— 原版在玩家濒死时会把
  「打开空界面」自动换成死亡界面，于是回调再开一次界面就会无限自递归、把客户端打爆。
  另注：`Entity#setRemoved(null)` 会空指针，清移除原因只能直接写字段。

- **`star_treasure_data` 的计数是「点数」不是「物品数」**：一个方块记 10 点、一块材料记 1 点。
  增幅一律按「每点」定义，所以方块天然就是锭的 10 倍。改动这里务必同时看
  `StarTreasureMinerals.POINTS_PER_BLOCK_FORGE` 与 `handleStarTreasureAnvil`。

---

## 五、版本历史

见 [`changelog.txt`](changelog.txt)。
