package cn.autoforged.rainbow_enchantment_mod.effect;

import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;

public class EternalBurnEffect extends MobEffect {
    public EternalBurnEffect(MobEffectCategory category, int color) {
        super(category, color);
    }

    @Override
    public void applyEffectTick(LivingEntity entity, int amplifier) {
        if (!entity.level().isClientSide) {
            entity.hurt(entity.damageSources().magic(), ModConfig.COMMON.eternalBaseDamage.get().floatValue());
            entity.setRemainingFireTicks(Math.max(entity.getRemainingFireTicks(), 40));
        }
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        java.util.List<? extends Integer> intervals = ModConfig.COMMON.eternalDamageIntervalTicks.get();
        int index = Math.min(amplifier, intervals.size() - 1);
        int interval = intervals.get(index);
        if (interval < 1) interval = 1;
        return duration % interval == 0;
    }
}
