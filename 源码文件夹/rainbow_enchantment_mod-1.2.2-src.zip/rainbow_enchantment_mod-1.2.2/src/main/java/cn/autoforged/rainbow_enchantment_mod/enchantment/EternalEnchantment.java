package cn.autoforged.rainbow_enchantment_mod.enchantment;

import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.PotionItem;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentCategory;

public class EternalEnchantment extends ModEnchantment {
    public static final String ETERNAL_USES_TAG = "eternal_uses";

    protected EternalEnchantment(Rarity rarity, EquipmentSlot... slots) {
        super(rarity, EnchantmentCategory.BREAKABLE, slots);
    }

    @Override
    public int getMinCost(int level) {
        return 20 + 5 * (level - 1);
    }

    @Override
    public int getMaxCost(int level) {
        return super.getMinCost(level) + 50;
    }

    @Override
    public int getMaxLevel() {
        return ModConfig.COMMON.eternalMaxLevel.get();
    }

    @Override
    public boolean isTreasureOnly() {
        return true;
    }

    @Override
    public boolean canEnchant(ItemStack stack) {
        // Check blacklist first
        var blacklist = ModConfig.COMMON.eternalItemBlacklist.get();
        ResourceLocation stackId = BuiltInRegistries.ITEM.getKey(stack.getItem());
        String stackStr = stackId.toString();
        if (blacklist.contains(stackStr)) return false;

        // Check whitelist
        var whitelist = ModConfig.COMMON.eternalItemWhitelist.get();
        if (!whitelist.isEmpty()) {
            return whitelist.contains(stackStr);
        }

        // Default built-in whitelist
        return stack.is(Items.ENCHANTED_GOLDEN_APPLE) || stack.is(Items.GOLDEN_APPLE)
            || stack.is(Items.TOTEM_OF_UNDYING) || stack.getItem() instanceof PotionItem;
    }

    public static int getMaxUses(int level) {
        return (level * level + 3 * level + 6) / 2;
    }

    public static int getRemainingUses(ItemStack stack) {
        var tag = stack.getTag();
        if (tag == null || !tag.contains(ETERNAL_USES_TAG)) {
            int level = stack.getEnchantmentLevel(ModEnchantments.ETERNAL.get());
            if (level <= 0) return 0;
            int maxUses = getMaxUses(level);
            tag = stack.getOrCreateTag();
            tag.putInt(ETERNAL_USES_TAG, maxUses);
            stack.setTag(tag);
            return maxUses;
        }
        return tag.getInt(ETERNAL_USES_TAG);
    }
}
