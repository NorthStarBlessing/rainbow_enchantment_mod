package cn.autoforged.rainbow_enchantment_mod.enchantment;

import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import cn.autoforged.rainbow_enchantment_mod.effect.ModEffects;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 不死附魔的「保护窗口」权威状态，以及所有「救他一命」时刻的唯一入口。
 *
 * <h2>为什么要有这个类</h2>
 * 在加厚死亡拦截之前，「玩家是否处于不死保护」有两个互相矛盾的判据：读冥界花效果（可被清掉）
 * 和读我们自己记的到期时刻。现在统一成<b>一个来源</b>：
 *
 * <ul>
 *   <li><b>服务端</b>：{@link #GUARD_UNTIL} 里我们自己记的到期游戏刻。
 *       别人能改血量、能清效果、能改同步数据，但改不到我们内存里这个数 —— 这就是
 *       「让他改，但改了没用」。</li>
 *   <li><b>客户端</b>：客户端没有这份内存记录，只认同步过来的冥界花效果。
 *       客户端这一层只用于「别弹死亡界面 / 别播死亡动画」，判定错了也不会影响服务端的生死。</li>
 * </ul>
 *
 * <h2>三条硬规矩（本类全程遵守）</h2>
 * <ol>
 *   <li><b>不针对任何模组</b>：这里没有、也不会有任何别的模组的名字、包名或「看调用栈猜是谁在调」
 *       这类判断。所有判定只读原版的公开状态与我们自己的记录。</li>
 *   <li><b>宁可不生效，绝不把游戏搞死</b>：每个入口都包异常，出异常一律<b>放行</b>（fail-open），
 *       异常只报一次，绝不刷屏。</li>
 *   <li><b>有界</b>：收尾每 tick 每玩家最多一次、带重入保护；日志每玩家限频；
 *       所有记录表都有 TTL 清理。</li>
 * </ol>
 *
 * <h2>刻意不做的事</h2>
 * 不做常驻无敌、不做「血量只增不减」、不做每 tick 覆盖血量格、不改最大生命值。
 * 保护只在<b>触发那一次</b>打开的窗口内有效，窗口一过就彻底放手 —— 窗口结束时如果血量
 * 还是 0，让原版死亡流程正常接管，不留「卡在 0 血不死」的中间态。
 */
public final class UndyingGuard {

    private static final Logger LOGGER = LogManager.getLogger();

    /** 旧版本把次数记在这个 persistentData 键上，触发时顺手清掉。 */
    private static final String LEGACY_COUNTER_KEY = "undying_remaining";

    /** 服务端权威：保护窗口的到期游戏刻。存在即代表「这个玩家现在被不死保着」。 */
    private static final Map<UUID, Long> GUARD_UNTIL = new ConcurrentHashMap<>();

    /** 服务端：上次真正触发（扣掉一级）的游戏刻，用于冷却。 */
    private static final Map<UUID, Long> TRIGGERED_AT = new ConcurrentHashMap<>();

    /** 收尾防抖：上次收尾的游戏刻，每 tick 每玩家最多一次。 */
    private static final Map<UUID, Long> LAST_RECOVER = new ConcurrentHashMap<>();

    /** 日志限频：上次打印的游戏刻。 */
    private static final Map<UUID, Long> LAST_LOG = new ConcurrentHashMap<>();

    /**
     * 收尾重入保护。收尾会改动死亡痕迹字段，而这些字段的改动有可能再次触发死亡判定相关的调用，
     * 所以必须挡住「收尾里再收尾」。用 ThreadLocal 而不是静态布尔：收尾只在当前线程发生。
     */
    private static final ThreadLocal<Boolean> IN_RECOVER = ThreadLocal.withInitial(() -> Boolean.FALSE);

    /** 异常只报一次。 */
    private static final AtomicBoolean FAILURE_REPORTED = new AtomicBoolean();

    /** 同一个玩家的日志最小间隔（tick）。 */
    private static final long LOG_INTERVAL_TICKS = 40L;

    private UndyingGuard() {
    }

    // ===================== 权威判定 =====================

    /**
     * 这个实体现在是否处于不死的保护窗口内。
     *
     * <p>只对玩家为真；非玩家实体直接返回 false，调用方不必再判类型。
     * 任何异常都返回 false（= 不保护、原样放行）。
     */
    public static boolean isGuarded(Entity entity) {
        if (!(entity instanceof Player player)) {
            return false;
        }
        try {
            if (player.level() == null) {
                return false;
            }
            // 客户端没有服务端那份内存记录，只认同步过来的效果标记。
            if (player.level().isClientSide) {
                return player.hasEffect(ModEffects.NETHER_FLOWER.get());
            }
            Long until = GUARD_UNTIL.get(player.getUUID());
            return until != null && player.level().getGameTime() < until;
        } catch (Throwable t) {
            reportFailureOnce(t);
            return false;
        }
    }

    /** 是否还在触发冷却里。 */
    public static boolean isOnCooldown(ServerPlayer player) {
        try {
            Long last = TRIGGERED_AT.get(player.getUUID());
            return last != null
                    && player.level().getGameTime() - last < Math.max(1, ModConfig.COMMON.undyingCooldownTicks.get());
        } catch (Throwable t) {
            reportFailureOnce(t);
            return false;
        }
    }

    // ===================== 唯一入口：救他一命 =====================

    /**
     * 尝试保住这个玩家。
     *
     * <p><b>幂等</b>：已经在窗口里就直接返回 true，<b>不重复扣级</b>。
     * 不管是「致命伤害事件」还是「死亡调用」先到，一次保护窗口只扣一次。
     *
     * <p><b>救不了就放行</b>：冷却中、或者身上已经扣不出不死等级，一律返回 false，
     * 调用方必须让这次死亡正常发生 —— 否则会变成「没有不死附魔也免死」。
     *
     * @return true 表示这次确实保住了（调用方应把伤害清零 / 取消死亡）
     */
    public static boolean tryGuard(ServerPlayer player) {
        if (player == null) {
            return false;
        }
        try {
            if (player.level().isClientSide) {
                return false;
            }

            // 已经在窗口里：幂等，不重复扣级。
            if (isGuarded(player)) {
                return true;
            }
            // 冷却中，这次救不了。
            if (isOnCooldown(player)) {
                return false;
            }
            // 扣不到一级就不救。
            if (!consumeOneLevel(player)) {
                return false;
            }

            long now = player.level().getGameTime();
            int duration = Math.max(1, ModConfig.COMMON.undyingEffectDuration.get());

            TRIGGERED_AT.put(player.getUUID(), now);
            GUARD_UNTIL.put(player.getUUID(), now + duration);

            player.heal(Math.max(0.0f, ModConfig.COMMON.undyingHealAmount.get().floatValue()));
            player.addEffect(new MobEffectInstance(ModEffects.NETHER_FLOWER.get(), duration, 0));
            player.getPersistentData().remove(LEGACY_COUNTER_KEY);

            recover(player);
            log(player, "触发不死：扣 1 级，保护窗口 " + duration + " tick");
            return true;
        } catch (Throwable t) {
            reportFailureOnce(t);
            return false;
        }
    }

    /**
     * 保护窗口内的致死伤害压制：把「这一下会打死他」的伤害压到留 1 点血。
     *
     * @return 修正后的伤害；返回 null 表示不在保护窗口内，调用方继续走原有逻辑
     */
    public static Float damageAfterGuard(Player player, float damage) {
        if (!isGuarded(player)) {
            return null;
        }
        try {
            float health = player.getHealth();
            if (health - damage <= 0.0f) {
                return Math.max(0.0f, health - 1.0f);
            }
            return damage;
        } catch (Throwable t) {
            reportFailureOnce(t);
            return null;
        }
    }

    // ===================== 收尾：把「死」的痕迹清干净 =====================

    /**
     * 取消死亡之后清掉残留的死亡痕迹。
     *
     * <p>只碰原版<b>公开</b>的计时字段和公开方法，不做字段反射、不猜字段名。
     * 死亡标志（{@code dead}）由 {@code LivingEntityGuardMixin} 直接写，本类拿不到。
     *
     * <p>每 tick 每玩家最多执行一次（防抖），并且带重入保护。
     */
    public static void recover(Player player) {
        if (player == null) {
            return;
        }
        if (Boolean.TRUE.equals(IN_RECOVER.get())) {
            return;
        }
        try {
            long now = player.level().getGameTime();
            Long last = LAST_RECOVER.get(player.getUUID());
            if (last != null && last == now) {
                return;
            }
            LAST_RECOVER.put(player.getUUID(), now);
        } catch (Throwable t) {
            reportFailureOnce(t);
            return;
        }

        IN_RECOVER.set(Boolean.TRUE);
        try {
            player.deathTime = 0;
            player.hurtTime = 0;
            player.hurtDuration = 0;
            player.clearFire();
            player.setAirSupply(300);
            player.getCombatTracker().recheckStatus();
        } catch (Throwable t) {
            reportFailureOnce(t);
        } finally {
            IN_RECOVER.set(Boolean.FALSE);
        }
    }

    // ===================== 每 tick：窗口维持与放手 =====================

    /**
     * 服务端每 tick 推进一次保护窗口。
     *
     * <p>窗口内：清死亡痕迹 + 保证冥界花图标在（别人清掉了就补挂，幂等）。
     * 窗口结束：摘记录、结算「后遗症」伤害，然后<b>彻底放手</b>。
     */
    public static void serverTick(ServerPlayer player) {
        if (player == null) {
            return;
        }
        try {
            Long until = GUARD_UNTIL.get(player.getUUID());
            if (until == null) {
                return;
            }
            long now = player.level().getGameTime();

            if (now < until) {
                recover(player);
                if (!player.hasEffect(ModEffects.NETHER_FLOWER.get())) {
                    int remaining = (int) Math.max(1L, Math.min(Integer.MAX_VALUE, until - now));
                    player.addEffect(new MobEffectInstance(ModEffects.NETHER_FLOWER.get(), remaining, 0));
                }
                return;
            }

            // 窗口结束。此处刻意不做任何「再保一次」的动作：
            // 如果这时候血量还是 0（被别的写入按住），原版死亡流程会正常接管。
            GUARD_UNTIL.remove(player.getUUID());
            float postDamage = Math.max(0.0f, ModConfig.COMMON.undyingPostEffectDamage.get().floatValue());
            if (postDamage > 0.0f && player.isAlive()) {
                player.hurt(player.damageSources().magic(), postDamage);
            }
            log(player, "保护窗口结束，已彻底放手");
        } catch (Throwable t) {
            reportFailureOnce(t);
        }
    }

    // ===================== 维护 =====================

    /** 清理过期记录，避免记录表随玩家数无界增长。由既有的定期清理任务调用。 */
    public static void prune(long now) {
        try {
            long guardTtl = Math.max(1, ModConfig.COMMON.undyingEffectDuration.get()) + 200L;
            GUARD_UNTIL.entrySet().removeIf(e -> now > e.getValue() + guardTtl);

            long cooldownTtl = Math.max(1, ModConfig.COMMON.undyingCooldownTicks.get()) * 4L;
            TRIGGERED_AT.entrySet().removeIf(e -> now - e.getValue() > cooldownTtl);

            LAST_RECOVER.entrySet().removeIf(e -> now - e.getValue() > 200L);
            LAST_LOG.entrySet().removeIf(e -> now - e.getValue() > 200L);
        } catch (Throwable t) {
            reportFailureOnce(t);
        }
    }

    // ===================== 内部工具 =====================

    /**
     * 扣掉一级不死附魔：取<b>等级最高</b>的那一件护甲扣（并列时按 {@link EquipmentSlot} 枚举顺序），
     * 等级降到 0 时把该附魔整条移除。
     *
     * @return 是否真的扣掉了
     */
    private static boolean consumeOneLevel(ServerPlayer player) {
        Enchantment undying = ModEnchantments.UNDYING.get();
        if (undying == null) {
            return false;
        }

        EquipmentSlot targetSlot = null;
        int targetLevel = 0;
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            if (slot.getType() != EquipmentSlot.Type.ARMOR) {
                continue;
            }
            int level = player.getItemBySlot(slot).getEnchantmentLevel(undying);
            if (level > targetLevel) {
                targetLevel = level;
                targetSlot = slot;
            }
        }
        if (targetSlot == null || targetLevel <= 0) {
            return false;
        }

        ItemStack armor = player.getItemBySlot(targetSlot);
        if (armor.isEmpty()) {
            return false;
        }

        Map<Enchantment, Integer> enchantments = EnchantmentHelper.getEnchantments(armor);
        if (targetLevel <= 1) {
            enchantments.remove(undying);
        } else {
            enchantments.put(undying, targetLevel - 1);
        }
        EnchantmentHelper.setEnchantments(enchantments, armor);
        // 立刻同步物品栏，否则减级要等下一次背包广播才看得到。
        player.containerMenu.broadcastChanges();
        return true;
    }

    /** 限频日志：同一玩家每 {@link #LOG_INTERVAL_TICKS} tick 最多一条。 */
    private static void log(Player player, String message) {
        try {
            long now = player.level().getGameTime();
            Long last = LAST_LOG.get(player.getUUID());
            if (last != null && now - last < LOG_INTERVAL_TICKS) {
                return;
            }
            LAST_LOG.put(player.getUUID(), now);
            LOGGER.info("[不死] {} {}", player.getGameProfile().getName(), message);
        } catch (Throwable ignored) {
            // 日志本身出问题不该影响任何流程
        }
    }

    /** 异常只报一次，且不刷屏。 */
    private static void reportFailureOnce(Throwable t) {
        if (FAILURE_REPORTED.compareAndSet(false, true)) {
            LOGGER.warn("[不死] 防御回调出现异常，已静默放行（只报这一次，后续不再刷）", t);
        }
    }
}
