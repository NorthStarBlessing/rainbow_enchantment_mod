package cn.autoforged.rainbow_enchantment_mod.particle;

import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 星光之力 / 千风之力的**服务端演出状态机**。
 *
 * <h2>为什么要有单独一套状态机</h2>
 * 原来的实现是「攻击命中的那一瞬间，在目标身上撒一坨静态粒子 + 立刻结算 AOE」。
 * 而维护者要的是：
 * <ul>
 *   <li>星光之力：<b>左键空气</b>从天上射下一道流星 → 有下落过程 → 落地后先播放扩散特效，
 *       <b>扩散环扫到才造成伤害</b>（不是落地瞬间就全范围结算）；</li>
 *   <li>千风之力：<b>蓄力进度条满了射出的箭</b>才算特殊箭 → 打地面只触发最低级扩散、
 *       打怪物才触发最高级扩散，两种情况都有扩散动画。</li>
 * </ul>
 * 这两件事都是「跨很多 tick 的过程」，所以必须在服务端按 tick 推进，并且每 tick 发一批粒子。
 * 每个 tick 做什么、发什么粒子、什么时候结算伤害，全部照抄预览实验室定稿的那一套。
 *
 * <h2>伤害时序（这一版的核心）</h2>
 * 扩散阶段第 t tick 的冲击波半径是 {@code R * t / spreadTicks}。
 * 一个距离爆心 d 的目标，在 {@code t = d / R * spreadTicks} 那一 tick 被扫到、<b>那一刻才受伤</b>。
 * <b>超过判定半径的目标永远扫不到，也就永远不受伤</b> ——
 * 这条是实验室里踩过的坑：曾把比值 clamp 到 1，结果半径外的怪会在扩散最后一刻被判为「到达」而全部受伤。
 */
public final class ParticleEffectManager {

    /** 特效种类。 */
    public enum Kind { STARLIGHT, WIND }

    private ParticleEffectManager() {}

    // ── 生效范围上限 ────────────────────────────────────────────────────────
    /**
     * 参与结算的实体搜索盒半边长上限（格）。
     * 判定半径可以很大，但没必要遍历整张地图：按「本 tick 的冲击波半径」取盒，
     * 既省开销，又天然满足「环还没扫到就不用管」。
     */
    private static final double MAX_TARGET_SEARCH = 96.0;

    /**
     * 场上同时存在的演出数上限。防止有玩家拿连发装置刷出一堆流星把服务端压死。
     */
    private static final int MAX_ACTIVE = 64;

    /** 所有进行中的演出，key 用随机 UUID（同一玩家可以有多发在飞）。 */
    private static final Map<UUID, Active> ACTIVE = new ConcurrentHashMap<>();

    /** 千风蓄力：玩家 UUID → 蓄力 tick 数。由 ArrowLooseEvent / 每 tick 维护。 */
    private static final Map<UUID, Integer> CHARGING = new ConcurrentHashMap<>();

    // ══════════════════════════════════════════════════════════════════════
    //  演出实体状态
    // ══════════════════════════════════════════════════════════════════════

    private static final class Active {
        final Kind kind;
        final ServerLevel level;
        final Vec3 origin;          // 爆心
        final UUID casterId;
        final int enchantLevel;
        final int stars;            // 下界之星数
        final boolean maxSpread;    // 千风：打怪物=最高级；星光恒为 true
        final double radius;        // 判定半径
        final double damage;        // 范围伤害
        final int spreadTicks;

        int tick = 0;               // 当前阶段内的 tick
        boolean falling = true;     // 星光：是否还在下落
        boolean justImpact = true;  // 是否刚落地（起手爆点只发一次）
        int emitted = 0;            // 本 tick 已发粒子数（预算控制用）

        Active(Kind kind, ServerLevel level, Vec3 origin, UUID casterId,
               int enchantLevel, int stars, boolean maxSpread,
               double radius, double damage, int spreadTicks) {
            this.kind = kind;
            this.level = level;
            this.origin = origin;
            this.casterId = casterId;
            this.enchantLevel = enchantLevel;
            this.stars = stars;
            this.maxSpread = maxSpread;
            this.radius = radius;
            this.damage = damage;
            this.spreadTicks = spreadTicks;
        }

        /** 总时长：星光 = 下落 + 扩散；千风 = 直接扩散。 */
        int totalTicks() {
            int n = spreadTicks;
            if (kind == Kind.STARLIGHT) n += ModConfig.COMMON.fxStarlightMeteorTicks.get();
            return n;
        }

        boolean done() { return tick >= totalTicks(); }
    }

    // ══════════════════════════════════════════════════════════════════════
    //  对外入口
    // ══════════════════════════════════════════════════════════════════════

    /**
     * 触发一次星光之力：从天上射下一道流星砸向 {@code impact}。
     *
     * @param caster 施法者（用于伤害归属，可以是 null）
     */
    public static void triggerStarlight(ServerLevel level, Vec3 impact, LivingEntity caster,
                                        int enchantLevel, int stars) {
        if (ACTIVE.size() >= MAX_ACTIVE) return;
        var c = ModConfig.COMMON;
        // 伤害 / 半径口径与实验室一致
        // 【2026-10-12】这里的基数 1.3 以前是写死的，现在提到配置项
        // starlight_enchantment.fx_star_base_multiplier（默认仍是 1.3，行为不变）。
        // 星数缩放保持「加性」：每颗下界之星 +1 倍。
        double starBase = c.fxStarlightStarBaseMultiplier.get();
        double rad = c.starlightBaseRadius.get() * (starBase + stars);
        double dmg = (1.0 + (enchantLevel + 1) * 2.75) * (starBase + stars);
        Active a = new Active(Kind.STARLIGHT, level, impact,
            caster == null ? null : caster.getUUID(),
            enchantLevel, stars, true, rad, dmg, c.fxStarlightSpreadTicks.get());
        ACTIVE.put(UUID.randomUUID(), a);
    }

    /**
     * 触发一次千风之力扩散。
     *
     * @param maxSpread true = 打中怪物（最高级扩散）；false = 打中地面（最低级扩散）
     */
    public static void triggerWind(ServerLevel level, Vec3 impact, LivingEntity caster,
                                   int enchantLevel, int stars, boolean maxSpread) {
        if (ACTIVE.size() >= MAX_ACTIVE) return;
        var c = ModConfig.COMMON;
        // 打地面 → 按最低级（星数不参与）；打怪物 → 最高级
        // 【2026-10-12】基数 1.3 以前是写死的，现在提到配置项
        // wind_force_enchantment.fx_star_base_multiplier（默认仍是 1.3，行为不变）。
        // 星数缩放保持「加性」：每颗下界之星 +1 倍。
        double starBase = c.fxWindStarBaseMultiplier.get();
        double mult = maxSpread ? (starBase + stars) : starBase;
        double rad = c.fxWindRadiusBase.get() * mult;
        double dmg = c.fxWindDamageBase.get() * mult;
        Active a = new Active(Kind.WIND, level, impact,
            caster == null ? null : caster.getUUID(),
            enchantLevel, stars, maxSpread, rad, dmg, c.fxWindSpreadTicks.get());
        ACTIVE.put(UUID.randomUUID(), a);
    }

    /** 蓄力状态：供 ArrowLooseEvent 判断"蓄满了没有"。 */
    public static void setCharging(UUID playerId, int ticks) {
        CHARGING.put(playerId, ticks);
    }

    public static int getCharging(UUID playerId) {
        return CHARGING.getOrDefault(playerId, 0);
    }

    public static void clearCharging(UUID playerId) {
        CHARGING.remove(playerId);
    }

    // ══════════════════════════════════════════════════════════════════════
    //  每 tick 推进
    // ══════════════════════════════════════════════════════════════════════

    /** 由 ModEvents.onLevelTick 调用。 */
    public static void tick(ServerLevel level) {
        if (ACTIVE.isEmpty()) return;
        Iterator<Map.Entry<UUID, Active>> it = ACTIVE.entrySet().iterator();
        while (it.hasNext()) {
            Active a = it.next().getValue();
            if (a.level != level) continue;
            try {
                step(a);
            } catch (Exception e) {
                // 单发演出出错不该拖垮整个 tick 循环
                it.remove();
                continue;
            }
            if (a.done()) it.remove();
        }
    }

    private static void step(Active a) {
        var c = ModConfig.COMMON;
        a.emitted = 0;

        if (a.kind == Kind.STARLIGHT) {
            int fallTicks = c.fxStarlightMeteorTicks.get();
            if (a.falling) {
                emitStarlightFall(a, fallTicks);
                a.tick++;
                if (a.tick >= fallTicks) {
                    a.falling = false;
                    a.tick = 0;
                    a.justImpact = true;
                    // 落地音效：低沉一记，不用爆炸音（那太"炸"了）
                    a.level.playSound(null, a.origin.x, a.origin.y, a.origin.z,
                        SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.1F, 0.55F);
                }
                return;
            }
            stepSpread(a, c.fxStarlightSpreadTicks.get(), true);
            return;
        }

        // 千风：直接进入扩散
        stepSpread(a, c.fxWindSpreadTicks.get(), false);
    }

    /** 扩散阶段：发粒子 + 按"环扫到"结算伤害。 */
    private static void stepSpread(Active a, int spreadTicks, boolean starlight) {
        double p = Mth.clamp((float) a.tick / Math.max(1, spreadTicks), 0F, 1F);
        double r = a.radius * p;

        // 1) 起手爆点（只在刚落地那一 tick 发一次）
        if (a.justImpact) {
            a.justImpact = false;
            emitImpact(a, starlight);
        }

        // 2) 波前环：把"扩散边界"用粒子做实
        emitWaveRing(a, r, starlight);

        // 3) 球壳 / 旋臂（体积感）
        if (starlight) emitStarlightShell(a, r, p);
        else emitWindVortex(a, r, p);

        // 4) 伤害：只结算「本 tick 环扫到」的目标
        applyDamage(a, r, spreadTicks, starlight);

        a.tick++;
    }

    // ══════════════════════════════════════════════════════════════════════
    //  伤害结算
    // ══════════════════════════════════════════════════════════════════════

    private static void applyDamage(Active a, double ringRadius, int spreadTicks, boolean starlight) {
        if (ringRadius <= 0.01) return;
        double box = Math.min(MAX_TARGET_SEARCH, ringRadius + 1.0);
        AABB area = new AABB(
            a.origin.x - box, a.origin.y - box * 0.5, a.origin.z - box,
            a.origin.x + box, a.origin.y + box, a.origin.z + box);

        List<LivingEntity> targets = a.level.getEntitiesOfClass(LivingEntity.class, area,
            e -> e.isAlive() && !e.isSpectator());

        var c = ModConfig.COMMON;
        double kbMin = starlight ? c.fxStarlightKnockbackMin.get() : 0.0;
        double kbMax = starlight ? c.fxStarlightKnockbackMax.get() : 0.0;

        for (LivingEntity e : targets) {
            if (e.getUUID().equals(a.casterId)) continue;
            double d = horizontalDistance(a.origin, e.position());
            // 【关键】超出判定半径的目标永远扫不到 —— 不能 clamp 掉这个判断
            if (d > a.radius) continue;
            // 本 tick 环是否刚好扫过它？用「上一 tick 半径 < d <= 本 tick 半径」判定，
            // 保证每个目标只挨一次，且时刻与视觉上的环一致。
            double prevR = a.radius * Mth.clamp((float) (a.tick - 1) / Math.max(1, spreadTicks), 0F, 1F);
            if (!(d > prevR && d <= ringRadius)) continue;

            var src = a.level.damageSources().indirectMagic(
                a.casterId == null ? null : a.level.getEntity(a.casterId), null);
            e.invulnerableTime = 0;
            e.hurt(src, (float) a.damage);

            // 星光之力：被扫到的目标额外吃「星光」持续伤害 + 缓慢 + 向外击飞。
            // 这部分原来挂在附魔的 doPostAttack 里（攻击即生效），现在改成"环扫到才生效"，
            // 与「扩散到了才造成伤害」的时序保持一致。
            if (starlight) {
                e.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                    cn.autoforged.rainbow_enchantment_mod.effect.ModEffects.STARLIGHT.get(),
                    c.starlightEffectDuration.get(),
                    Math.min(Math.max(0, a.enchantLevel - 1), 4)));
                e.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                    net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN,
                    c.starlightSlowDuration.get() * 20, c.starlightSlowAmplifier.get()));
            }

            if (kbMax > 0) {
                Vec3 dir = new Vec3(e.getX() - a.origin.x, 0, e.getZ() - a.origin.z);
                if (dir.lengthSqr() < 1.0E-6) dir = new Vec3(0, 0, 1);
                dir = dir.normalize();
                double f = kbMin + Math.random() * (kbMax - kbMin);
                // 向外击飞：knockback 的 (dx,dz) 是从击退源指向目标的反方向，所以传 -dir
                e.knockback(f, -dir.x, -dir.z);
            }
        }
    }

    private static double horizontalDistance(Vec3 a, Vec3 b) {
        double dx = a.x - b.x, dz = a.z - b.z;
        return Math.sqrt(dx * dx + dz * dz);
    }

    // ══════════════════════════════════════════════════════════════════════
    //  调色板（与预览实验室的 PAL 逐字对应）
    // ══════════════════════════════════════════════════════════════════════

    /**
     * 调色板。全部是冷色 —— 维护者前后提过两次「金色的粒子太多了，遮挡视线」
     * 「完全取消金色的拟火花粒子」，所以这里一份暖色（色相 20°~70°）都没有。
     *
     * <p>星光 = 宇宙深处陨石，拆成三支分工用（核心白 / 等离子青 / 星尘紫），
     * 而不是一支调色板撒满全场；千风 = 原神风元素的青绿薄荷，与星光的靛蓝差 60° 色相。
     */
    private static final int[][] PAL_DEEP = {{104, 96, 210}, {72, 128, 214}, {138, 116, 224}, {70, 176, 206}};
    private static final int[][] PAL_DUST = {{126, 108, 196}, {96, 124, 200}, {150, 134, 212}, {88, 152, 190}};
    private static final int[][] PAL_PLASMA = {{96, 206, 236}, {130, 220, 240}, {112, 180, 244}, {168, 232, 246}};
    private static final int[][] PAL_CORE = {{238, 248, 255}, {226, 242, 255}, {244, 252, 255}};
    private static final int[][] PAL_ANEMO = {{122, 226, 202}, {148, 240, 216}, {104, 208, 196}, {176, 246, 226}};
    private static final int[][] PAL_ANEMO_HI = {{226, 252, 244}, {204, 248, 236}, {240, 255, 250}};
    /** 未指定调色板时的默认（深空）。 */
    private static final int[][] PAL_DEFAULT = PAL_DEEP;

    private static int[] pickColor(int[][] pal) {
        int[][] p = (pal == null || pal.length == 0) ? PAL_DEFAULT : pal;
        return p[(int) (Math.random() * p.length)];
    }

    /**
     * 有色粉尘。{@code ParticleTypes.DUST} 不是无参粒子 —— 它要求 {@link DustParticleOptions}
     * （颜色 + 大小），直接当 ParticleOptions 传给 sendParticles 是编译不过的。
     * 颜色无法逐粒子定制（一个粒子类型一个实例），所以按调色板逐次取一支，效果等价。
     */
    private static ParticleOptions dust(int[][] pal, float scale) {
        int[] c = pickColor(pal);
        return new DustParticleOptions(
            new Vector3f(c[0] / 255.0F, c[1] / 255.0F, c[2] / 255.0F), scale);
    }

    // ══════════════════════════════════════════════════════════════════════
    //  发粒子
    // ══════════════════════════════════════════════════════════════════════

    /** 受预算限制地发一个粒子。返回 false 表示本 tick 预算用尽。 */
    private static boolean send(Active a, ParticleOptions type,
                                double x, double y, double z,
                                double vx, double vy, double vz, double speed) {
        int budget = a.kind == Kind.STARLIGHT
            ? ModConfig.COMMON.fxStarlightParticleBudget.get()
            : ModConfig.COMMON.fxWindParticleBudget.get();
        if (a.emitted >= budget) return false;
        a.emitted++;
        a.level.sendParticles(type, x, y, z, 1, vx, vy, vz, speed);
        return true;
    }

    /** 星光的物理坠落高度：p^accel 让流星越掉越快（不是匀速）。 */
    private static double meteorHeight(double p, double fromY, double accel) {
        double q = Math.pow(Mth.clamp(p, 0, 1), Math.max(0.2, accel));
        return fromY * (1.0 - q);
    }

    /** 星光：下落拖尾（四层分工：星核 / 等离子尾 / 星尘 / 星尘幕）。 */
    private static void emitStarlightFall(Active a, int fallTicks) {
        var c = ModConfig.COMMON;
        double fromY = c.fxStarlightMeteorFromY.get();
        double accel = c.fxStarlightFallAccel.get();
        double p = (double) a.tick / Math.max(1, fallTicks);
        double y = a.origin.y + meteorHeight(p, fromY, accel);

        // 下落速度（格/tick）→ 决定拖尾张开度与密度
        double dt = 1.0 / Math.max(1, fallTicks);
        double speed = Math.abs(meteorHeight(p, fromY, accel)
            - meteorHeight(Math.min(1, p + dt), fromY, accel));
        double fast = Mth.clamp((float) (speed * 0.55), 0F, 1F);

        int n = Math.max(1, (int) Math.round(c.fxStarlightTrailDensity.get() * (0.35 + speed * 0.5)));
        for (int i = 0; i < n; i++) {
            double spread = 0.16 + 0.75 * fast;
            double ja = Math.random() * Math.PI * 2;
            double jr = Math.pow(Math.random(), 0.6) * spread;
            double jx = Math.cos(ja) * jr, jz = Math.sin(ja) * jr;
            double back = Math.random() * (1.2 + 3.4 * fast);   // 落在核后（上方）多远
            double py = y + back;
            double roll = Math.random();
            if (roll < 0.42) {
                // 等离子尾：青蓝
                if (!send(a, Math.random() < 0.5 ? ParticleTypes.SOUL_FIRE_FLAME : ParticleTypes.ELECTRIC_SPARK,
                    a.origin.x + jx, py, a.origin.z + jz,
                    (Math.random() - 0.5) * 0.02, 0.02 + Math.random() * 0.05, (Math.random() - 0.5) * 0.02, 0.0)) return;
            } else if (roll < 0.78) {
                // 星尘：靛紫微光粉尘
                if (!send(a, dust(PAL_DUST, 1.7F),
                    a.origin.x + jx * 1.6, py + (Math.random() - 0.5) * 1.2, a.origin.z + jz * 1.6,
                    (Math.random() - 0.5) * 0.03, -0.01 + Math.random() * 0.04, (Math.random() - 0.5) * 0.03, 0.0)) return;
            } else {
                // 星核外沿：近白短促
                if (!send(a, ParticleTypes.END_ROD,
                    a.origin.x + jx * 0.5, py * 0.92 + y * 0.08, a.origin.z + jz * 0.5,
                    (Math.random() - 0.5) * 0.02, 0.05 + Math.random() * 0.08, (Math.random() - 0.5) * 0.02, 0.0)) return;
            }
        }
        // 星尘幕：极慢的粉尘留在原处
        if (Math.random() < 0.55) {
            send(a, dust(PAL_DUST, 1.9F),
                a.origin.x + (Math.random() - 0.5) * 2.6, y + (Math.random() - 0.2) * 2.0,
                a.origin.z + (Math.random() - 0.5) * 2.6,
                (Math.random() - 0.5) * 0.012, -0.012, (Math.random() - 0.5) * 0.012, 0.0);
        }
    }

    /** 落地起手：扬尘 + 向外推的碎屑（不是爆炸火球）。 */
    private static void emitImpact(Active a, boolean starlight) {
        if (starlight) {
            send(a, ParticleTypes.POOF, a.origin.x, a.origin.y + 0.6, a.origin.z, 0, 0.05, 0, 0.0);
            int burst = Math.min(70, (int) Math.round(16 + a.radius * 1.4));
            for (int b = 0; b < burst; b++) {
                double ang = Math.random() * Math.PI * 2, rr = 0.3 + Math.random() * 0.6;
                if (!send(a, Math.random() < 0.5 ? ParticleTypes.LARGE_SMOKE : ParticleTypes.CLOUD,
                    a.origin.x + Math.cos(ang) * rr, a.origin.y + 0.35, a.origin.z + Math.sin(ang) * rr,
                    Math.cos(ang) * 0.10, 0.03 + Math.random() * 0.05, Math.sin(ang) * 0.10, 0.0)) return;
            }
        } else {
            // 千风：贴地铺开的一圈气浪
            send(a, ParticleTypes.CLOUD, a.origin.x, a.origin.y + 0.5, a.origin.z, 0, 0.03, 0, 0.0);
            int pb = Math.min(34, (int) Math.round(12 + a.radius * 0.9));
            for (int t = 0; t < pb; t++) {
                double at = Math.random() * Math.PI * 2, rt = 0.4 + Math.random() * 0.9;
                if (!send(a, Math.random() < 0.5 ? ParticleTypes.CLOUD : ParticleTypes.POOF,
                    a.origin.x + Math.cos(at) * rt, a.origin.y + 0.15 + Math.random() * 0.35,
                    a.origin.z + Math.sin(at) * rt,
                    Math.cos(at) * 0.11, 0.015 + Math.random() * 0.03, Math.sin(at) * 0.11, 0.0)) return;
            }
        }
    }

    /**
     * 波前环 —— 把预览里那圈"看得见的扩散边界"用粒子做实。
     * 沿当前冲击波半径摆一圈，密度随周长增长。
     */
    private static void emitWaveRing(Active a, double radius, boolean starlight) {
        var c = ModConfig.COMMON;
        if (!c.fxWaveRing.get()) return;
        if (radius <= 0.3) return;
        int n = Math.max(6, (int) Math.round(radius * Math.PI * 2 * c.fxWaveDensity.get()));
        double lift = c.fxWaveLift.get();
        float scale = c.fxWaveScale.get().floatValue();
        for (int i = 0; i < n; i++) {
            double ang = (i / (double) n) * Math.PI * 2;
            double jr = radius * (1 + (Math.random() - 0.5) * 0.03);
            double ja = ang + (Math.random() - 0.5) * 0.08;
            double px = a.origin.x + Math.cos(ja) * jr;
            double pz = a.origin.z + Math.sin(ja) * jr;
            double py = a.origin.y + lift + Math.random() * (starlight ? 0.16 : 0.12);
            double ca = Math.cos(ja), sa = Math.sin(ja);
            ParticleOptions type;
            if (starlight) {
                // 星光波前：冷白冲击环（END_ROD 打主力、GLOW 做亮边），带向外的初速
                type = Math.random() < 0.45 ? ParticleTypes.END_ROD : ParticleTypes.GLOW;
            } else {
                // 千风波前：青绿气浪（ELECTRIC_SPARK 打主力、CLOUD 做气感）
                type = Math.random() < 0.5 ? ParticleTypes.ELECTRIC_SPARK : ParticleTypes.CLOUD;
            }
            if (!send(a, type, px, py, pz,
                ca * 0.055 * scale, (0.015 + Math.random() * 0.025) * scale, sa * 0.055 * scale,
                0.0)) return;
        }
    }

    /** 星光：球壳 + 旋臂（星核翻滚带出的角动量）。 */
    private static void emitStarlightShell(Active a, double r, double spreadP) {
        var c = ModConfig.COMMON;
        if (r <= 0.15) return;
        int rings = Math.max(1, c.fxStarlightShellRings.get());
        double airborne = c.fxStarlightAirborneShare.get();
        double density = c.fxStarlightShellDensity.get();

        for (int ring = 0; ring < rings; ring++) {
            double rp = spreadP - ring * 0.09;
            if (rp <= 0) continue;
            double rr = a.radius * Mth.clamp((float) rp, 0F, 1F);
            int cnt = Math.min(70, (int) Math.round(Math.max(1, rr * density * 0.5)));
            double baseArm = ring * 2.0944 + spreadP * 1.6;
            double armCurl = 3.0 * (0.55 + 0.45 * Mth.clamp((float) rp, 0F, 1F));
            for (int j = 0; j < cnt; j++) {
                double u = Math.random() * 2 - 1, th = Math.random() * Math.PI * 2;
                double sr = Math.sqrt(Math.max(0, 1 - u * u));
                double ny = Math.abs(u);
                double squash = 0.16 + airborne * ny;
                double jr = rr * (1 + (Math.random() - 0.5) * 0.06);
                double out = 0.035 * (1 - rp * 0.45);
                double roll2 = Math.random();
                double armAngle = baseArm + ((int) (Math.random() * 3)) * 2.0944
                    + (jr / Math.max(0.3, rr)) * armCurl;
                double pull = 0.55 * Math.max(0, Math.cos(3 * (th - armAngle)));
                double ang = roll2 < pull ? armAngle + (Math.random() - 0.5) * 0.18 : th;
                double px = a.origin.x + Math.cos(ang) * jr;
                double pz = a.origin.z + Math.sin(ang) * jr;
                double py = a.origin.y + ny * jr * squash + 0.08;

                ParticleOptions type;
                if (roll2 < pull) type = ParticleTypes.SOUL_FIRE_FLAME;       // 旋臂：青蓝
                else if (roll2 < 0.42) type = ParticleTypes.GLOW;             // 冷白（比例调小）
                else if (roll2 < 0.82) type = dust(PAL_DUST, 1.7F);             // 靛紫星尘
                else type = dust(PAL_DUST, 1.5F);                             // 靛紫星尘（原为近白 SNOWFLAKE，白色过多）

                if (!send(a, type, px, py, pz,
                    Math.cos(ang) * out, ny * out * 0.4 + 0.015, Math.sin(ang) * out, 0.0)) return;
            }
        }

        // 球内持续粒子
        int inner = Math.min(55, (int) Math.round(a.radius * density * c.fxStarlightInteriorShare.get() * 0.22));
        for (int m = 0; m < inner; m++) {
            double u2 = Math.random() * 2 - 1, th2 = Math.random() * Math.PI * 2;
            double sr2 = Math.sqrt(Math.max(0, 1 - u2 * u2));
            double rr2 = r * Math.cbrt(Math.random());
            if (!send(a, Math.random() < 0.62 ? dust(PAL_DUST, 1.6F) : ParticleTypes.SOUL,
                a.origin.x + sr2 * Math.cos(th2) * rr2,
                a.origin.y + Math.abs(u2) * rr2 * 0.55 + 0.15,
                a.origin.z + sr2 * Math.sin(th2) * rr2,
                (Math.random() - 0.5) * 0.02, 0.025 + Math.random() * 0.045,
                (Math.random() - 0.5) * 0.02, 0.0)) return;
        }
    }

    /**
     * 千风：涡心 + N 条螺旋臂 + 向心塌缩。
     *
     * 螺旋臂的角度必须**随半径线性累计**（{@code ang = base + f * curl}），
     * 不能写成 {@code phase + (rr/r)*const} —— 后者整条臂看起来是直的斜线，"卷"的感觉就没了。
     */
    private static void emitWindVortex(Active a, double r, double spreadP) {
        var c = ModConfig.COMMON;
        if (r <= 0.15) return;
        int arms = Math.max(2, c.fxWindArms.get());
        double density = c.fxWindShellDensity.get();
        double airborne = c.fxWindAirborneShare.get();
        double TAU = Math.PI * 2;

        // ① 涡心
        int coreN = Math.min(18, Math.max(3, (int) Math.round(3 + r * 0.25)));
        for (int i = 0; i < coreN; i++) {
            double ac = Math.random() * TAU;
            double rc = 0.25 + Math.random() * Math.max(0.4, r * 0.12);
            if (!send(a, Math.random() < 0.35 ? ParticleTypes.ELECTRIC_SPARK : dust(PAL_ANEMO_HI, 1.2F),
                a.origin.x + Math.cos(ac) * rc, a.origin.y + 0.12 + Math.random() * 0.5,
                a.origin.z + Math.sin(ac) * rc,
                0, 0.02 + Math.random() * 0.05, 0, 0.0)) return;
        }

        // ② 螺旋臂
        double curl = 4.5 * (0.7 + 0.5 * (1 - spreadP));
        for (int arm = 0; arm < arms; arm++) {
            double base = ((double) arm / arms) * TAU + spreadP * 2.2;
            int segs = Math.min(30, (int) Math.round(Math.max(6, r * density * 0.6)));
            for (int s = 0; s < segs; s++) {
                double f = s / (double) Math.max(1, segs - 1);
                double rad = r * Math.pow(f, 0.82);
                if (rad < 0.12) continue;
                double ang = base + f * curl + Math.sin(f * 5.1 + arm) * 0.16 * (1 - f);
                double yy = a.origin.y + 0.1 + (0.35 + airborne * 1.5) * f
                    * (0.55 + 0.45 * Math.sin(ang * 2));
                double jitter = 0.10 * rad + 0.05;
                double px = a.origin.x + Math.cos(ang) * rad + (Math.random() - 0.5) * jitter;
                double pz = a.origin.z + Math.sin(ang) * rad + (Math.random() - 0.5) * jitter;
                // 切向速度：垂直于半径 → 这就是"卷"的方向
                double tangent = ang + Math.PI / 2;
                double sp = 0.05 + 0.05 * f;
                double roll = Math.random();
                ParticleOptions type = roll < 0.45 ? dust(PAL_ANEMO, 1.7F)
                    : (roll < 0.78 ? dust(PAL_ANEMO, 1.1F) : ParticleTypes.ELECTRIC_SPARK);
                if (!send(a, type, px, yy, pz,
                    Math.cos(tangent) * sp, 0.03 + Math.random() * 0.06,
                    Math.sin(tangent) * sp, 0.0)) return;
            }
        }

        // ③ 向心塌缩的碎叶/尘埃
        int inner = Math.min(50, (int) Math.round(r * density * c.fxWindInteriorShare.get() * 0.2));
        for (int q = 0; q < inner; q++) {
            double a3 = Math.random() * TAU;
            double r3 = r * (0.45 + 0.55 * Math.sqrt(Math.random()));
            double y3 = a.origin.y + 0.1 + Math.random() * (0.4 + airborne * 1.2);
            boolean leaf = Math.random() < 0.55;
            if (!send(a, leaf ? dust(PAL_ANEMO, 1.5F) : dust(PAL_ANEMO_HI, 1.0F),
                a.origin.x + Math.cos(a3) * r3, y3, a.origin.z + Math.sin(a3) * r3,
                0, 0, 0, 0.0)) return;
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    //  千风蓄力法阵（平铺在玩家脚下）
    // ══════════════════════════════════════════════════════════════════════

    /**
     * 法阵把整个图案按角度切成 {@code SLICES} 份，每 tick 只画其中一份（轮转）。
     *
     * <p>粉尘粒子本身会存活 16~80 tick，所以「每 tick 只画 1/N」看上去仍是完整的一个阵，
     * 单 tick 开销却只有 1/N。这是把粒子量压下来的关键，也是这套法阵能每 tick 常驻的原因。
     */
    private static final int CHARGE_ARRAY_SLICES = 6;

    /**
     * 千风之力：<b>蓄力法阵</b>，平铺在射手脚下的水平面上。
     *
     * <p>【2026-10-12 改版】维护者口径：「现在改为在玩家脚下放一个法阵，
     * 关键点再加上少量粒子效果」。旧实现是「以箭尖为原点、垂直于箭矢的三道风环」
     * （还会被反馈「环直径是角色的三倍多」「白色粒子太多」），已整体替换。
     *
     * <p>几何照维护者给的法阵图（同心圆 + 六芒星 + 12 个内嵌小阵 + 核心）在水平面上重画：
     * <ol>
     *   <li>外圈 16 个菱形 / 星点（{@code r = 1.55 × 基准半径}）；</li>
     *   <li>{@code fx_charge_rings} 道同心圆，半径从 {@code 1.00} 均匀收到 {@code 0.56}
     *       —— 对应原图 180~220 那一圈符文带；最外一道实线，内圈虚线（原图本来就是 dasharray）；</li>
     *   <li>六芒星：两个交叠的正三角形 = 6 条边，落在最外两道圆环之间，按蓄力进度一条条「画」出来；</li>
     *   <li>12 个内嵌小阵的中心点，压在最内那道圆环上；</li>
     *   <li>核心环。</li>
     * </ol>
     *
     * <p><b>★ 关键点</b>（维护者特别要求的那「少量粒子效果」）= 六芒星的 6 个顶点
     * ＋ 12 个小阵中心 ＋ 核心中心，每处每 tick 只打 1 颗 {@link ParticleTypes#ELECTRIC_SPARK}，
     * 只做点缀、不铺面积。核心那两颗要蓄满（{@code charge >= 0.999}）才出现，
     * 兼作「可以松手了」的信号。
     *
     * <p><b>随蓄力逐步展开</b>：0.15 起最外圆环 → 0.35 起外圈装饰与第二道圆 →
     * 0.50 起六芒星逐段生长 → 0.70 起 12 个小阵 → 1.00 核心点亮。
     *
     * <p><b>半径</b> = {@code max(1.2, 风墙半径 × fx_charge_ring_scale)}，
     * 而风墙半径含附魔等级，所以等级越高法阵越大。
     *
     * <p><b>性能</b>：单 tick 上限 {@code min(96, fx_particle_budget)}。
     * 粉尘存活最多 80 tick，按 96/tick 算最坏情况七千多颗；
     * 旧实现按 260/tick 会到两万多颗 —— 那才是真正的掉帧源。
     *
     * <p>由服务端每 tick 调用（{@code ModEvents#onPlayerTickChargeRings}）；
     * 这里只发粒子，不改任何状态。
     */
    public static void spawnChargeArray(ServerLevel level, LivingEntity shooter,
                                        double wallRadius, double charge) {
        var c = ModConfig.COMMON;
        // 【粒子上限】粉尘会存活 16~80 tick，所以「每 tick 发多少」直接决定存活总量。
        // 旧实现按 fx_wind_particle_budget（默认 260）/tick 发，最坏情况两万多颗同时存活 —— 掉帧源。
        // 法阵不需要那个量级：每 tick 只画图案的 1/CHARGE_ARRAY_SLICES，
        // 再夹一道 96 的硬上限，最坏也就七千多颗。
        int[] left = {Math.max(24, Math.min(96, c.fxWindParticleBudget.get()))};

        double ch = Mth.clamp(charge, 0.0, 1.0);
        // 半径随附魔等级增长（windWallRadius 已经含等级），但给一个下限，
        // 免得低级时法阵小到看不清图案。
        double base = Math.max(1.2, wallRadius * c.fxWindChargeRingScale.get());
        double ox = shooter.getX();
        double oz = shooter.getZ();
        double y = shooter.getY() + 0.06;      // 贴着脚底，抬 6cm 免得和地面完全重叠

        long t = level.getGameTime();
        int slice = (int) Math.floorMod(t, CHARGE_ARRAY_SLICES);
        double spin = t * 0.012;               // 整阵缓慢自转（约 8.7 秒一圈）

        // ── 1) 外圈装饰：16 个菱形 / 星点（原图最外层的 24 菱形 + 24 星，取 16 组省预算）──
        if (ch >= 0.35) {
            final int n = 16;
            for (int i = slice; i < n; i += CHARGE_ARRAY_SLICES) {
                double a = spin + i * (Math.PI * 2 / n);
                double r = base * 1.55;
                double px = ox + Math.cos(a) * r;
                double pz = oz + Math.sin(a) * r;
                arrayParticle(level, left, dust(PAL_ANEMO_HI, 1.4F), px, y, pz, 0.0, 0.004, 0.0, 0.0);
                if ((i & 1) == 0) {
                    arrayParticle(level, left, ParticleTypes.ELECTRIC_SPARK, px, y + 0.05, pz, 0.0, 0.012, 0.0, 0.0);
                }
            }
        }

        // ── 2) 同心圆：对应原图 180~220 那一圈符文带 ──────────────────
        // 半径从 1.00 均匀收到 0.56（相邻圆环约 0.22×基准，视觉上分得开），
        // 点距按 0.35 格取样 —— 取样太稀（旧值 12r）会散成一片噪点，读不出「线」。
        int rings = Math.max(1, c.fxWindChargeRings.get());
        for (int k = 0; k < rings; k++) {
            if (ch < 0.15 + k * 0.20) break;                 // 蓄力越多，圆环一道道亮起来
            double ratio = 1.0 - k * (0.44 / Math.max(1, rings - 1));
            double rr = base * ratio;
            if (rr < 0.15) break;
            int n = Math.max(16, (int) Math.round(rr * 18));
            boolean dashed = k > 0;                          // 最外一道实线，内圈虚线（原图就是 dasharray）
            for (int i = slice; i < n; i += CHARGE_ARRAY_SLICES) {
                if (dashed && ((i / CHARGE_ARRAY_SLICES) & 1) == 1) continue;
                double a = -spin + i * (Math.PI * 2 / n);    // 圆环反向转，和六芒星错开
                arrayParticle(level, left,
                    dust(k == 0 ? PAL_ANEMO : PAL_ANEMO_HI, k == 0 ? 1.5F : 1.1F),
                    ox + Math.cos(a) * rr, y, oz + Math.sin(a) * rr,
                    0.0, 0.004, 0.0, 0.0);
            }
        }

        // ── 3) 六芒星：两个交叠的正三角形 = 6 条边 ────────────────────
        if (ch >= 0.5) {
            double rv = base * 0.89;                         // 落在最外两道圆环之间
            double grow = Math.min(1.0, (ch - 0.5) / 0.5);   // 蓄力过程中一条条「画」出来
            int per = Math.max(4, (int) Math.round(rv * 5));
            for (int tri = 0; tri < 2; tri++) {
                double off = spin * 0.5 + tri * (Math.PI / 3);
                for (int e = 0; e < 3; e++) {
                    double a0 = off + e * (Math.PI * 2 / 3);
                    double a1 = off + ((e + 1) % 3) * (Math.PI * 2 / 3);
                    double x0 = ox + Math.cos(a0) * rv, z0 = oz + Math.sin(a0) * rv;
                    double x1 = ox + Math.cos(a1) * rv, z1 = oz + Math.sin(a1) * rv;
                    for (int j = slice; j < per; j += CHARGE_ARRAY_SLICES) {
                        double f = (double) j / Math.max(1, per - 1);
                        if (f > grow) break;
                        arrayParticle(level, left, dust(PAL_ANEMO_HI, 1.2F),
                            x0 + (x1 - x0) * f, y, z0 + (z1 - z0) * f, 0.0, 0.004, 0.0, 0.0);
                    }
                }
            }
            // ★ 关键点：六芒星的 6 个顶点
            for (int v = 0; v < 6; v++) {
                double a = spin * 0.5 + v * (Math.PI / 3);
                arrayParticle(level, left, ParticleTypes.ELECTRIC_SPARK,
                    ox + Math.cos(a) * rv, y + 0.05, oz + Math.sin(a) * rv, 0.0, 0.02, 0.0, 0.0);
            }
        }

        // ── 4) 12 个内嵌小阵：正好压在最内那道圆环上（★ 关键点）──────
        if (ch >= 0.7) {
            double rn = base * 0.56;
            for (int i = 0; i < 12; i++) {
                double a = -spin * 1.4 + i * (Math.PI * 2 / 12);
                arrayParticle(level, left, ParticleTypes.ELECTRIC_SPARK,
                    ox + Math.cos(a) * rn, y + 0.03, oz + Math.sin(a) * rn, 0.0, 0.02, 0.0, 0.0);
            }
        }

        // ── 5) 核心 ──────────────────────────────────────────────────
        double coreR = base * 0.30;
        int coreN = Math.max(8, (int) Math.round(coreR * 18));
        for (int i = slice; i < coreN; i += CHARGE_ARRAY_SLICES) {
            double a = spin * 2.2 + i * (Math.PI * 2 / coreN);
            arrayParticle(level, left, dust(PAL_ANEMO_HI, 1.6F),
                ox + Math.cos(a) * coreR, y + 0.02, oz + Math.sin(a) * coreR, 0.0, 0.01, 0.0, 0.0);
        }
        // ★ 关键点：核心中心 —— 只有真正拉满才亮，作为「可以松手了」的信号
        if (ch >= 0.999) {
            arrayParticle(level, left, ParticleTypes.ELECTRIC_SPARK, ox, y + 0.10, oz, 0.0, 0.03, 0.0, 0.0);
            arrayParticle(level, left, ParticleTypes.ELECTRIC_SPARK, ox, y + 0.24, oz, 0.0, 0.03, 0.0, 0.0);
        }
    }

    /** 法阵粒子：{@code left[0]} 是剩余预算，扣完就什么都不发（可变计数器用数组，省一次对象分配）。 */
    private static void arrayParticle(ServerLevel level, int[] left,
                                      ParticleOptions type,
                                      double x, double y, double z,
                                      double vx, double vy, double vz, double speed) {
        if (left[0] <= 0) return;
        left[0]--;
        level.sendParticles(type, x, y, z, 1, vx, vy, vz, speed);
    }

    /** 风墙半径 = 基础 + 等级 × 每级（+ 星数，仅"打怪物"时）。 */
    public static double windWallRadius(int enchantLevel, int stars, boolean maxSpread) {
        var c = ModConfig.COMMON;
        return c.fxWindWallBaseRadius.get()
            + (double) enchantLevel * c.fxWindWallRadiusPerLevel.get()
            + (maxSpread ? stars : 0);
    }

    /** 清理某个维度里由某玩家发起的演出（玩家退出/死亡时用）。 */
    public static void clearByCaster(UUID casterId) {
        if (casterId == null) return;
        ACTIVE.values().removeIf(a -> casterId.equals(a.casterId));
        CHARGING.remove(casterId);
    }

    /** 调试统计。 */
    public static int activeCount() { return ACTIVE.size(); }

    /** 供外部遍历用（只读）。 */
    public static List<String> describe() {
        List<String> out = new ArrayList<>();
        for (Active a : ACTIVE.values()) {
            out.add(a.kind + "@" + a.origin + " r=" + String.format("%.2f", a.radius)
                + " t=" + a.tick + "/" + a.totalTicks());
        }
        return out;
    }
}
