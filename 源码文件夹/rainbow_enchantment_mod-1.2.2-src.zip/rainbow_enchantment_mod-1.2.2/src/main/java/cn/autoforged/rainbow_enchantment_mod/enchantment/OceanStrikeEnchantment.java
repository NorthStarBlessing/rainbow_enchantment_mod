package cn.autoforged.rainbow_enchantment_mod.enchantment;

import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import cn.autoforged.rainbow_enchantment_mod.effect.ModEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentCategory;

public class OceanStrikeEnchantment extends ModEnchantment {
    protected OceanStrikeEnchantment(Rarity rarity, EquipmentSlot... slots) {
        super(rarity, EnchantmentCategory.WEAPON, slots);
    }

    @Override
    public int getMinCost(int level) {
        return 15;
    }

    @Override
    public int getMaxCost(int level) {
        return 45;
    }

    @Override
    public int getMaxLevel() {
        return 1;
    }

    @Override
    public boolean isTreasureOnly() {
        return true;
    }

    @Override
    public void doPostAttack(LivingEntity attacker, Entity target, int level) {
        if (target instanceof LivingEntity livingTarget && !target.level().isClientSide) {
            int duration = ModConfig.COMMON.oceanDeepSeaDuration.get();
            livingTarget.addEffect(new MobEffectInstance(ModEffects.DEEP_SEA.get(), duration, 0));
        }
    }
}
