package cn.autoforged.rainbow_enchantment_mod.config;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.config.ModConfig.Type;
import net.minecraftforge.fml.event.config.ModConfigEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@EventBusSubscriber(
   modid = "rainbow_enchantment_mod"
)
public class ConfigAutoFixer {
   private static final Logger LOGGER = LogManager.getLogger();
   private static final AtomicBoolean HAS_CHECKED_CONFIG = new AtomicBoolean(false);

   @SubscribeEvent
   public static void onConfigLoading(ModConfigEvent.Loading event) {
      HAS_CHECKED_CONFIG.set(false);
      net.minecraftforge.fml.config.ModConfig config = event.getConfig();
      if (config.getType().equals(Type.COMMON)) {
         // 配置项 debug_log 的用途：打开后把「配置从哪个文件加载、值是否来自默认」打到日志，
         // 方便玩家 / 整合包作者排查「我改了配置但没生效」这类问题。
         if (ModConfig.COMMON.debugLog.get()) {
            LOGGER.info("[RainbowEnchantment] 已加载配置文件: {} (类型 {})",
               config.getFileName(), config.getType());
            LOGGER.info("[RainbowEnchantment] 调试日志已启用（general.debug_log = true）");
         }
         checkAndFixConfigFile(config.getFileName());
      }
   }

   @SubscribeEvent
   public static void onConfigReloading(ModConfigEvent.Reloading event) {
      HAS_CHECKED_CONFIG.set(false);
      net.minecraftforge.fml.config.ModConfig config = event.getConfig();
      if (config.getType().equals(Type.COMMON)) {
         if (ModConfig.COMMON.debugLog.get()) {
            LOGGER.info("[RainbowEnchantment] 配置文件已重载: {}", config.getFileName());
         }
         checkAndFixConfigFile(config.getFileName());
      }
   }

   private static void checkAndFixConfigFile(String fileName) {
      if (!HAS_CHECKED_CONFIG.getAndSet(true)) {
         try {
            Path configDir = getConfigDirectory();
            Path configFile = configDir.resolve(fileName);
            Path badFile = configDir.resolve(fileName + ".bad");
            if (Files.exists(badFile, new LinkOption[0])) {
               LOGGER.warn("[RainbowEnchantment] 检测到损坏的配置文件备份: {}", badFile.getFileName());
               // 【2026-10-12】这里原本会把「当前这份（很可能完好的）配置」直接 Files.delete 掉，
               // 再用 .bad 覆盖上去 —— 那是实打实的数据丢失：只要目录里存在一个陈旧的 .bad，
               // 每次启动都会把玩家当前的设置删掉。改成：有冲突就先给当前文件留备份，不删任何东西。
               if (Files.exists(configFile, new LinkOption[0])) {
                  Path keep = configDir.resolve(fileName + ".backup_" + System.currentTimeMillis());
                  try {
                     Files.copy(configFile, keep);
                     LOGGER.info("[RainbowEnchantment] 当前配置已备份到: {}", keep.getFileName());
                  } catch (IOException e) {
                     LOGGER.error("[RainbowEnchantment] 备份当前配置失败，跳过 .bad 恢复以免覆盖: {}", e.getMessage());
                     return;
                  }
               }

               try {
                  Files.move(badFile, configFile, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                  LOGGER.info("[RainbowEnchantment] 已恢复配置文件备份");
               } catch (IOException e) {
                  LOGGER.error("[RainbowEnchantment] 恢复配置文件备份失败: {}", e.getMessage());
               }

               return;
            }

            if (Files.exists(configFile, new LinkOption[0])) {
               validateConfigSyntax(configFile, fileName);
            }
         } catch (Exception e) {
            LOGGER.error("[RainbowEnchantment] \u68c0\u67e5\u914d\u7f6e\u6587\u4ef6\u65f6\u53d1\u751f\u9519\u8bef: {}", e.getMessage());
         }

      }
   }

   private static void validateConfigSyntax(Path configFile, String fileName) {
      try {
         String content = Files.readString(configFile);
         if (!isValidToml(content)) {
            LOGGER.warn("[RainbowEnchantment] 配置文件的语法验证未通过（仅备份，不删除）: {}", fileName);
            Path backupFile = configFile.getParent().resolve(fileName + ".backup_" + System.currentTimeMillis());
            Files.copy(configFile, backupFile);
            LOGGER.info("[RainbowEnchantment] 已备份疑似损坏的配置文件到: {}", backupFile.getFileName());
            // 【2026-10-12】这里原本还会 Files.delete(configFile)。已去掉，原因：
            //   1) isValidToml 只是括号 / 引号计数，判不了真正的 TOML 语义错误，
            //      合法文件也可能被误判成「损坏」；
            //   2) 这个回调跑在 Forge 已经读完配置之后，删文件救不了本次启动，
            //      却会让下一次启动整份配置回落到默认值 —— 玩家的设置会静默丢失；
            //      而 run/config 里那份文件被外部删掉后，日志里就会出现成百上千条
            //      「Incorrect key xxx was corrected from null to its default」，
            //      正是维护者看到的那一大批警告（Forge 对新建文件逐键纠正是正常行为）。
            //   3) 真损坏时 Forge 自己会抛 ConfigLoadingException 并保留现场。
            // 若确实想按默认值重建，请显式调用 ForgeConfigSpec.correct(...) 再 save()，而不是删文件。
         }
      } catch (IOException e) {
         LOGGER.error("[RainbowEnchantment] 读取配置文件失败: {}", e.getMessage());
      }

   }

   private static boolean isValidToml(String content) {
      if (content != null && !content.isEmpty()) {
         int braceDepth = 0;
         int bracketDepth = 0;
         boolean inComment = false;
         boolean inString = false;
         char stringDelimiter = 0;

         for(int i = 0; i < content.length(); ++i) {
            char c = content.charAt(i);
            if (inComment) {
               if (c == '\n') {
                  inComment = false;
               }
            } else if (inString) {
               if (c == stringDelimiter) {
                  inString = false;
                  stringDelimiter = 0;
               } else if (c == '\\' && i + 1 < content.length()) {
                  ++i;
               }
            } else if (c == '#') {
               inComment = true;
            } else if (c != '"' && c != '\'') {
               if (c == '{') {
                  ++braceDepth;
               } else if (c == '}') {
                  --braceDepth;
                  if (braceDepth < 0) {
                     return false;
                  }
               } else if (c == '[') {
                  ++bracketDepth;
               } else if (c == ']') {
                  --bracketDepth;
                  if (bracketDepth < 0) {
                     return false;
                  }
               }
            } else {
               inString = true;
               stringDelimiter = c;
            }
         }

         return !inString && !inComment && braceDepth == 0 && bracketDepth == 0;
      } else {
         return false;
      }
   }

   private static Path getConfigDirectory() {
      Path gameDir = Paths.get(".").toAbsolutePath().normalize();
      Path configPath = gameDir.resolve("config");
      if (Files.exists(configPath, new LinkOption[0]) && Files.isDirectory(configPath, new LinkOption[0])) {
         return configPath;
      } else {
         configPath = gameDir.getParent().resolve("config");
         return Files.exists(configPath, new LinkOption[0]) && Files.isDirectory(configPath, new LinkOption[0]) ? configPath : gameDir.resolve("config");
      }
   }
}
