package cn.autoforged.rainbow_enchantment_mod.enchantment;

import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import cn.autoforged.rainbow_enchantment_mod.effect.ModEffects;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.phys.AABB;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class StarlightForceEnchantment extends ModEnchantment {
    public static final String STARLIGHT_STARS_TAG = "starlight_stars";
    private static final Map<UUID, Long> STARLIGHT_COOLDOWN = new HashMap<>();

    protected StarlightForceEnchantment(Rarity rarity, EquipmentSlot... slots) {
        super(rarity, EnchantmentCategory.WEAPON, slots);
    }

    @Override
    public int getMinCost(int level) {
        return 15 + 10 * (level - 1);
    }

    @Override
    public int getMaxCost(int level) {
        return super.getMinCost(level) + 50;
    }

    @Override
    public int getMaxLevel() {
        return 5;
    }

    @Override
    public boolean isTreasureOnly() {
        return true;
    }

    @Override
    public boolean canEnchant(ItemStack stack) {
        return stack.getItem() instanceof SwordItem;
    }

    public static int getStarCount(ItemStack stack) {
        var tag = stack.getTag();
        if (tag == null || !tag.contains(STARLIGHT_STARS_TAG)) return 0;
        return tag.getInt(STARLIGHT_STARS_TAG);
    }

    public static double getRangeMultiplier(ItemStack stack) {
        int stars = getStarCount(stack);
        return Math.pow(ModConfig.COMMON.starlightNetherStarBase.get(), stars);
    }

    public static double getDamageMultiplier(ItemStack stack) {
        int stars = getStarCount(stack);
        return Math.pow(ModConfig.COMMON.starlightNetherStarBase.get(), stars);
    }

    private static int getCooldownTicks(LivingEntity entity) {
        double attackSpeed = 4.0;
        if (entity instanceof Player p) {
            attackSpeed = p.getAttributeValue(Attributes.ATTACK_SPEED);
        }
        return Math.max(5, (int) (20.0 / attackSpeed));
    }

    public static boolean checkAndSetCooldown(Player player) {
        long now = player.level().getGameTime();
        UUID uuid = player.getUUID();
        Long last = STARLIGHT_COOLDOWN.get(uuid);
        int cooldownTicks = getCooldownTicks(player);
        if (last != null && (now - last) < cooldownTicks) return false;
        STARLIGHT_COOLDOWN.put(uuid, now);
        return true;
    }

    /**
     * 摘掉过期的冷却记录。
     *
     * <p>{@link #STARLIGHT_COOLDOWN} 以实体 UUID 为键、每次触发写入，原本**从不清理**。
     * TTL 取该功能自己的冷却上限时，摘掉与保留在语义上完全等价
     * （过了这个时间，原逻辑只会走「冷却已过」分支并覆盖掉旧值）。
     */
    public static void pruneCooldowns(long now, long ttlTicks) {
        STARLIGHT_COOLDOWN.entrySet().removeIf(e -> now - e.getValue() > ttlTicks);
    }

    /**
     * ⚠ 星光之力<b>不再</b>在攻击命中时触发。
     *
     * <p>维护者口径：「星光之力的触发特效为，<b>左键空气</b>时，将会从天上射下一道流星，并砸向地面」，
     * 并且明确指出旧实现「现在的星光之力是攻击时触发，和原效果不一致」。
     *
     * <p>现在的流程是：
     * 客户端左键空气 → {@code StarlightTriggerPacket} → 服务端
     * {@code ParticleEffectManager.triggerStarlight()} → 流星下落 → 落地 → 扩散环扫到才伤害。
     * 整套演出由服务端按 tick 推进，所以这里不再做任何事。
     */
    @Override
    public void doPostAttack(LivingEntity attacker, Entity target, int level) {
        // 故意留空：触发点已经移到「左键空气」，见 ClientModEvents.onLeftClickEmpty
    }
}
