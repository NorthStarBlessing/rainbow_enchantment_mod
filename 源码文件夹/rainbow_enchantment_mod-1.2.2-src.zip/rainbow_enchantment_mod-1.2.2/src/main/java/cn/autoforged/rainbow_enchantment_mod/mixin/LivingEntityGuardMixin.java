package cn.autoforged.rainbow_enchantment_mod.mixin;

import cn.autoforged.rainbow_enchantment_mod.enchantment.UndyingGuard;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 不死附魔的死亡拦截（{@code LivingEntity} 这一层，三道门里的「死亡计时」与「死亡调用」）。
 *
 * <h2>为什么是这几处</h2>
 * <ul>
 *   <li>{@code isDeadOrDying()}：原版实现就是 {@code getHealth() <= 0}。只要血量被任何东西按成 0，
 *       原版的每 tick 逻辑就会认为「他死了」。所以保护窗口内这里必须答「没死」——
 *       <b>这是不依赖血量数值的那道门</b>。</li>
 *   <li>{@code tickDeath()}：已经进入死亡计时就取消，把状态收回来。</li>
 *   <li>{@code die(DamageSource)}：死亡调用的父类那道。</li>
 *   <li>{@code tick()}：自愈。任何东西把死亡标志按成 true，窗口内每 tick 还原一次。</li>
 * </ul>
 *
 * <h2>规矩</h2>
 * 判定全部交给 {@link UndyingGuard}（只读原版公开状态与我们自己的记录，不点名任何模组）。
 * 每个回调都包异常并静默放行：<b>宁可这一帧没防住，也绝不让游戏崩</b>。
 */
@Mixin(LivingEntity.class)
public abstract class LivingEntityGuardMixin {

    /** 原版死亡标志（{@code LivingEntity} 的 protected 字段）。反射/猜名字都不如直接写它干净。 */
    @Shadow
    protected boolean dead;

    /** 门：血量为 0 时原版每 tick 都会问「死了没」，窗口内一律答「没死」。 */
    @Inject(method = "isDeadOrDying", at = @At("HEAD"), cancellable = true)
    private void rainbow$guardedNotDying(CallbackInfoReturnable<Boolean> cir) {
        try {
            LivingEntity self = (LivingEntity) (Object) this;
            if (UndyingGuard.isGuarded(self)) {
                this.dead = false;
                cir.setReturnValue(false);
            }
        } catch (Throwable ignored) {
            // 失败一律放行
        }
    }

    /** 门：已经进入死亡计时，取消并收尾。 */
    @Inject(method = "tickDeath", at = @At("HEAD"), cancellable = true)
    private void rainbow$guardedNoTickDeath(CallbackInfo ci) {
        try {
            LivingEntity self = (LivingEntity) (Object) this;
            if (UndyingGuard.isGuarded(self)) {
                this.dead = false;
                ci.cancel();
                if (self instanceof Player player) {
                    UndyingGuard.recover(player);
                }
            }
        } catch (Throwable ignored) {
            // 失败一律放行
        }
    }

    /** 门：死亡调用的父类那道（玩家类自己重写过的那两处另见 Player / ServerPlayer 的 mixin）。 */
    @Inject(method = "die", at = @At("HEAD"), cancellable = true)
    private void rainbow$guardedNoDie(DamageSource source, CallbackInfo ci) {
        try {
            LivingEntity self = (LivingEntity) (Object) this;
            if (UndyingGuard.isGuarded(self)) {
                this.dead = false;
                ci.cancel();
                if (self instanceof Player player) {
                    UndyingGuard.recover(player);
                }
            }
        } catch (Throwable ignored) {
            // 失败一律放行
        }
    }

    /**
     * 自愈：死亡标志被任何来源按成 true 时，窗口内每 tick 还原一次。
     * 只在标志真的为 true 时才做判定，正常路径上零开销。
     */
    @Inject(method = "tick", at = @At("HEAD"))
    private void rainbow$keepAliveFlag(CallbackInfo ci) {
        try {
            if (!this.dead) {
                return;
            }
            if (UndyingGuard.isGuarded((LivingEntity) (Object) this)) {
                this.dead = false;
            }
        } catch (Throwable ignored) {
            // 失败一律放行
        }
    }
}
