package cn.autoforged.rainbow_enchantment_mod.acquisition;

import cn.autoforged.rainbow_enchantment_mod.config.AcquisitionSection;
import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * 「满级附魔台附加池」的运行时状态。
 *
 * <p>需求：哈气 / 末影注视 / 蛮兵先锋 / 夜行者 / 变态 / 超级核弹 / 大运 这 7 个
 * **作为正常附魔进附魔池**（会出现在三档预览里、玩家正常选中），条件是**原版满级附魔台**，
 * 且**每次刷新三档候选时有 12.75% 概率把它们纳入候选**。
 *
 * <p>为什么需要「按物品打标记」而不是直接改 `isDiscoverable`：
 * <ul>
 *   <li>原版刷新三档（`EnchantmentMenu#slotsChanged`）和玩家点击附魔（`clickMenuButton` 里重新算一次列表）
 *       是两次独立计算，但必须给出**同一个结果**（否则预览与实际不符）；</li>
 *   <li>所以「这次候选是否包含这 7 个」必须与物品绑定并保持稳定 —— 在
 *       {@code EnchantmentLevelSetEvent}（每次刷新都会按行触发，我们只取第 0 行）里掷一次 12.75%，
 *       把结果记在槽位里的那个 {@link ItemStack} 实例上，之后预览与点击都读同一个标记。</li>
 * </ul>
 */
public final class ModEnchantTableState {
    /** 键是附魔台上那个 ItemStack 实例（ItemStack 未重写 equals，天然是身份语义）。 */
    private static final Map<ItemStack, Boolean> MARKED = new WeakHashMap<>();

    private ModEnchantTableState() {
    }

    /** 该附魔是否属于「满级附魔台附加池」（由 `[acquisition.enchanting.enchanting_table]` 配置）。 */
    public static boolean isPoolMember(Enchantment enchantment) {
        AcquisitionSection.EnchantingTable cfg;
        try {
            cfg = ModConfig.COMMON.acquisition.enchantingTable;
            if (!cfg.enabled.get()) {
                return false;
            }
            List<? extends String> names = cfg.enchantments.get();
            ResourceLocation key = ForgeRegistries.ENCHANTMENTS.getKey(enchantment);
            if (key == null) {
                return false;
            }
            for (String name : names) {
                String trimmed = name == null ? "" : name.trim();
                if (trimmed.equals(key.toString()) || trimmed.equals(key.getPath())) {
                    return true;
                }
            }
        } catch (Exception e) {
            return false;
        }
        return false;
    }

    /** 要求的最低书架威力（默认 15 = 原版满级）。 */
    public static int requiredPower() {
        try {
            return ModConfig.COMMON.acquisition.enchantingTable.requiredPower.get();
        } catch (Exception e) {
            return 15;
        }
    }

    /** 触发概率（默认 0.1275）。 */
    public static double poolChance() {
        try {
            return ModConfig.COMMON.acquisition.enchantingTable.chance.get();
        } catch (Exception e) {
            return 0.1275D;
        }
    }

    /** 每次刷新三档候选时掷一次骰子，结果绑定到物品实例上（null 表示这次不纳入）。 */
    public static void refreshMark(ItemStack stack, int power, RandomSource random) {
        if (stack == null || stack.isEmpty()) {
            return;
        }
        if (power < requiredPower()) {
            MARKED.put(stack, Boolean.FALSE);
            return;
        }
        MARKED.put(stack, random.nextDouble() < poolChance());
    }

    /** 这次候选是否允许这 7 个进池。 */
    public static boolean isMarked(ItemStack stack) {
        if (stack == null) {
            return false;
        }
        Boolean marked = MARKED.get(stack);
        return marked != null && marked;
    }

    /** 是否任意物品当前处于「已纳入」状态（给没有 stack 参数的 isAllowedOnBooks 用）。 */
    public static boolean anyMarked() {
        for (Boolean value : MARKED.values()) {
            if (Boolean.TRUE.equals(value)) {
                return true;
            }
        }
        return false;
    }

    /** 物品离开附魔台时清掉标记。 */
    public static void clear(ItemStack stack) {
        if (stack != null) {
            MARKED.remove(stack);
        }
    }
}
