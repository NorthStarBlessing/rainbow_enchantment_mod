package cn.autoforged.rainbow_enchantment_mod.mixin;

import cn.autoforged.rainbow_enchantment_mod.enchantment.UndyingGuard;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 不死附魔的「移除标记」拦截。
 *
 * <h2>拦的是什么</h2>
 * 一个实体「死了」在原版里有两层含义：血量到 0，以及被标记成「已移除」。
 * 只要有人把玩家标成「已移除」，很多系统就会当他不存在了。这里：
 * <ul>
 *   <li>{@code isRemoved()}：读取到「已移除」时，如果原因是<b>被杀 / 被丢弃</b>，
 *       就把原因清掉并回答「没被移除」。</li>
 *   <li>{@code remove(RemovalReason)}：直接拦下「被杀」这一次移除动作。</li>
 * </ul>
 *
 * <h2>硬红线</h2>
 * <b>只处理「被杀」与「被丢弃」两种原因</b>，绝不碰跨维度、卸载区块这类正常移除 ——
 * 碰了会把传送和区块卸载卡死。这里按原因区分，区分的是<b>原版自己的语义</b>，
 * 不是任何别的模组。
 *
 * <h2>另一个坑</h2>
 * 不能用 {@code setRemoved(null)} 来清原因：原版那个方法内部会立刻解引用原因字段，
 * 传 null 会直接空指针。所以这里直接写字段。
 */
@Mixin(Entity.class)
public abstract class EntityGuardMixin {

    /** 原版「移除原因」字段（{@code Entity} 的 private 字段）。 */
    @Shadow
    private Entity.RemovalReason removalReason;

    /** 读取到「已移除」时按原因决定是否压制。 */
    @Inject(method = "isRemoved", at = @At("RETURN"), cancellable = true)
    private void rainbow$guardedNotRemoved(CallbackInfoReturnable<Boolean> cir) {
        try {
            if (!Boolean.TRUE.equals(cir.getReturnValue())) {
                return;
            }
            Entity self = (Entity) (Object) this;
            if (!UndyingGuard.isGuarded(self)) {
                return;
            }
            Entity.RemovalReason reason = this.removalReason;
            if (reason == Entity.RemovalReason.KILLED || reason == Entity.RemovalReason.DISCARDED) {
                this.removalReason = null;
                cir.setReturnValue(false);
            }
        } catch (Throwable ignored) {
            // 失败一律放行
        }
    }

    /** 直接拦下「被杀」这一次移除动作。 */
    @Inject(method = "remove", at = @At("HEAD"), cancellable = true)
    private void rainbow$guardedNoKilledRemoval(Entity.RemovalReason reason, CallbackInfo ci) {
        try {
            if (reason != Entity.RemovalReason.KILLED) {
                return;
            }
            Entity self = (Entity) (Object) this;
            if (UndyingGuard.isGuarded(self)) {
                ci.cancel();
            }
        } catch (Throwable ignored) {
            // 失败一律放行
        }
    }
}
