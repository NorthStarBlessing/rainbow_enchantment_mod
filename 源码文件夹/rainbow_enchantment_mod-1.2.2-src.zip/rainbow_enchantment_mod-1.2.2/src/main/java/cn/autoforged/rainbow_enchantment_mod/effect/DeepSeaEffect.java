package cn.autoforged.rainbow_enchantment_mod.effect;

import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;

public class DeepSeaEffect extends MobEffect {
    public DeepSeaEffect(MobEffectCategory category, int color) {
        super(category, color);
    }

    @Override
    public void applyEffectTick(LivingEntity entity, int amplifier) {
        if (!entity.level().isClientSide && entity.isInWaterOrRain()) {
            float dmg = ModConfig.COMMON.oceanWaterDamagePerSecond.get();
            entity.hurt(entity.damageSources().magic(), dmg);
        }
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        return duration % 20 == 0;
    }
}
