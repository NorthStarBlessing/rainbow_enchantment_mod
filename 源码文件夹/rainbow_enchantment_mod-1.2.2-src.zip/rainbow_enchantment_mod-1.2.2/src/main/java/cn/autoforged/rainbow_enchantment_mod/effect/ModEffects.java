package cn.autoforged.rainbow_enchantment_mod.effect;

import cn.autoforged.rainbow_enchantment_mod.RainbowEnchantmentMod;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEffects {
    public static final DeferredRegister<MobEffect> EFFECTS =
        DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, RainbowEnchantmentMod.MOD_ID);

    public static final RegistryObject<MobEffect> COLD = EFFECTS.register("cold",
        () -> new ColdEffect(MobEffectCategory.HARMFUL, 0x88DDFF));

    public static final RegistryObject<MobEffect> ENDER_SHACKLE = EFFECTS.register("ender_shackle",
        () -> new EnderShackleEffect(MobEffectCategory.HARMFUL, 0x4400AA));

    public static final RegistryObject<MobEffect> DEEP_SEA = EFFECTS.register("deep_sea",
        () -> new DeepSeaEffect(MobEffectCategory.HARMFUL, 0x0066AA));

    public static final RegistryObject<MobEffect> ETERNAL_BURN = EFFECTS.register("eternal_burn",
        () -> new EternalBurnEffect(MobEffectCategory.HARMFUL, 0x8B0000));

    public static final RegistryObject<MobEffect> CORROSION = EFFECTS.register("corrosion",
        () -> new CorrosionEffect(MobEffectCategory.HARMFUL, 0x44BB44));

    public static final RegistryObject<MobEffect> RUIN_WITHER = EFFECTS.register("ruin_wither",
        () -> new RuinWitherEffect(MobEffectCategory.HARMFUL, 0x800080));

    public static final RegistryObject<MobEffect> SINFUL = EFFECTS.register("sinful",
        () -> new SinfulEffect(MobEffectCategory.HARMFUL, 0x4A0E4E));

    public static final RegistryObject<MobEffect> STARLIGHT = EFFECTS.register("starlight",
        () -> new StarlightEffect(MobEffectCategory.HARMFUL, 0xFFDD55));

    public static final RegistryObject<MobEffect> NETHER_FLOWER = EFFECTS.register("nether_flower",
        () -> new NetherFlowerEffect(MobEffectCategory.BENEFICIAL, 0xAA44AA));
}
