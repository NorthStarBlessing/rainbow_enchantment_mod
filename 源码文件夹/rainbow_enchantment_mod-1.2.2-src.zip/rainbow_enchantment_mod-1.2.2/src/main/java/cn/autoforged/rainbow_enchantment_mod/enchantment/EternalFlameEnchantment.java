package cn.autoforged.rainbow_enchantment_mod.enchantment;

import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import cn.autoforged.rainbow_enchantment_mod.effect.ModEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.Enchantments;

public class EternalFlameEnchantment extends ModEnchantment {
    protected EternalFlameEnchantment(Rarity rarity, EquipmentSlot... slots) {
        super(rarity, EnchantmentCategory.WEAPON, slots);
    }

    @Override
    public int getMinCost(int level) {
        return 15 + 10 * (level - 1);
    }

    @Override
    public int getMaxCost(int level) {
        return super.getMinCost(level) + 50;
    }

    @Override
    public int getMaxLevel() {
        return 5;
    }

    @Override
    public boolean checkCompatibility(Enchantment pOther) {
        if (pOther == Enchantments.FIRE_ASPECT) return false;
        if (pOther == ModEnchantments.QUANTUM_BLADE.get()) return false;
        return super.checkCompatibility(pOther);
    }

    @Override
    public void doPostAttack(LivingEntity attacker, Entity target, int level) {
        if (target instanceof LivingEntity livingTarget && !target.level().isClientSide) {
            applyBurnEffect(livingTarget, level);
            sweepAttack(attacker, target, level);
        }
    }

    private void applyBurnEffect(LivingEntity target, int level) {
        int duration = ModConfig.COMMON.eternalEffectDuration.get();
        target.addEffect(new MobEffectInstance(ModEffects.ETERNAL_BURN.get(), duration, level - 1));
    }

    private void sweepAttack(LivingEntity attacker, Entity target, int level) {
        if (!(attacker instanceof Player player)) return;
        if (player.getMainHandItem().getEnchantmentLevel(Enchantments.SWEEPING_EDGE) <= 0) return;

        var box = player.getMainHandItem().getSweepHitBox(player, target);
        for (LivingEntity le : player.level().getEntitiesOfClass(LivingEntity.class, box)) {
            if (le != player && le != target && !player.isAlliedTo(le)) {
                applyBurnEffect(le, level);
            }
        }
    }
}
