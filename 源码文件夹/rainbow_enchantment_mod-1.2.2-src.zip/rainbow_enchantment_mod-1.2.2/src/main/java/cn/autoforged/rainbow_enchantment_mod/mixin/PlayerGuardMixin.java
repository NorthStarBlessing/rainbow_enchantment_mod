package cn.autoforged.rainbow_enchantment_mod.mixin;

import cn.autoforged.rainbow_enchantment_mod.enchantment.UndyingGuard;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 不死附魔的死亡拦截（{@code Player} 重写的那道 {@code die}）。
 *
 * <p>原版 {@code Player} 自己声明了 {@code die(DamageSource)}，它内部会调用父类实现。
 * 父类那道已经由 {@link LivingEntityGuardMixin} 拦了，这里再补一层的目的只是：
 * 万一将来（或别的改动）让玩家类的死亡流程从别处开始，父类那道不至于被绕过。
 *
 * <p>这里同样不做任何「猜来源」的判断 —— 只要在保护窗口内就拦，与是谁触发的无关。
 */
@Mixin(Player.class)
public abstract class PlayerGuardMixin {

    @Inject(method = "die", at = @At("HEAD"), cancellable = true)
    private void rainbow$guardedNoDie(DamageSource source, CallbackInfo ci) {
        try {
            Player self = (Player) (Object) this;
            if (UndyingGuard.isGuarded(self)) {
                ci.cancel();
                UndyingGuard.recover(self);
            }
        } catch (Throwable ignored) {
            // 失败一律放行
        }
    }
}
