package cn.autoforged.rainbow_enchantment_mod.event;

import cn.autoforged.rainbow_enchantment_mod.RainbowEnchantmentMod;
import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import cn.autoforged.rainbow_enchantment_mod.damage.ModDamageTypes;
import cn.autoforged.rainbow_enchantment_mod.effect.ModEffects;
import cn.autoforged.rainbow_enchantment_mod.enchantment.EternalEnchantment;
import cn.autoforged.rainbow_enchantment_mod.enchantment.JudgmentEnchantment;
import cn.autoforged.rainbow_enchantment_mod.enchantment.ModEnchantments;
import cn.autoforged.rainbow_enchantment_mod.enchantment.CherryBlossomEnchantment;
import cn.autoforged.rainbow_enchantment_mod.enchantment.PlunderEnchantment;
import cn.autoforged.rainbow_enchantment_mod.enchantment.StarTreasureEnchantment;
import cn.autoforged.rainbow_enchantment_mod.enchantment.StarTreasureMinerals;
import cn.autoforged.rainbow_enchantment_mod.enchantment.StarlightForceEnchantment;
import cn.autoforged.rainbow_enchantment_mod.enchantment.ThousandWindForceEnchantment;
import cn.autoforged.rainbow_enchantment_mod.enchantment.UndyingGuard;
import net.minecraft.advancements.Advancement;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.DiggerItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.Tiers;
import net.minecraftforge.common.TierSortingRegistry;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.event.entity.living.MobEffectEvent;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.AbstractIllager;
import net.minecraft.world.entity.monster.Skeleton;
import net.minecraft.world.entity.monster.piglin.PiglinBrute;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.npc.WanderingTrader;
import net.minecraft.world.entity.raid.Raid;
import net.minecraft.world.Difficulty;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.SwordItem;
import net.minecraftforge.event.AnvilUpdateEvent;
import net.minecraftforge.event.entity.player.AnvilRepairEvent;
import net.minecraftforge.event.ItemAttributeModifierEvent;
import net.minecraftforge.event.entity.EntityTeleportEvent;
import net.minecraftforge.event.entity.ProjectileImpactEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.living.LivingEquipmentChangeEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingHealEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingUseTotemEvent;
import net.minecraftforge.event.entity.living.MobSpawnEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;

import net.minecraft.world.entity.projectile.AbstractArrow;
import cn.autoforged.rainbow_enchantment_mod.particle.ParticleEffectManager;
import cn.autoforged.rainbow_enchantment_mod.particle.WindArrowMarker;
import net.minecraftforge.event.entity.player.ArrowLooseEvent;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ThrownTrident;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.item.TridentItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraftforge.event.TickEvent;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.minecraft.world.phys.Vec3;

@Mod.EventBusSubscriber(modid = RainbowEnchantmentMod.MOD_ID)
public final class ModEvents {
    private static final String RAINBOW_DYES_TAG = "rainbow_dyes";
    private static final UUID RAINBOW_DAMAGE_MODIFIER_UUID = UUID.fromString("a1b2c3d4-e5f6-7890-abcd-ef1234567890");

    private static final ThreadLocal<Boolean> PROCESSING_HURT = ThreadLocal.withInitial(() -> false);
    private static final Map<UUID, Long> RAINBOW_REFLECT_COOLDOWN = new HashMap<>();

    private static final UUID IMMACULATE_HP_PCT_UUID = UUID.nameUUIDFromBytes("immaculate_hp_pct".getBytes());
    private static final UUID IMMACULATE_HP_FLAT_UUID = UUID.nameUUIDFromBytes("immaculate_hp_flat".getBytes());
    private static final UUID IMMACULATE_ATK_PCT_UUID = UUID.nameUUIDFromBytes("immaculate_atk_pct".getBytes());
    private static final UUID IMMACULATE_ATK_FLAT_UUID = UUID.nameUUIDFromBytes("immaculate_atk_flat".getBytes());
    private static final String SIN_LEVEL_KEY = "rainbow_sin_level";

    /** 旧「千风落地 AOE」用的实体 NBT 键。该路径已删除，键保留仅作历史说明，勿再使用。 */
    @Deprecated
    private static final String THOUSAND_WIND_ARROW_TAG = "thousand_wind_arrow";

    public static final Map<UUID, Long> COLD_APPLY_TIMES = new HashMap<>();
    public static final Map<UUID, UUID> COLD_APPLY_ATTACKER = new HashMap<>();

    private static final Map<UUID, net.minecraft.resources.ResourceKey<net.minecraft.world.level.Level>> ETERNAL_LOYALTY_ITEM_ENTITIES = new HashMap<>();

    private static final ThreadLocal<Boolean> PROCESSING_SUPER_NUKE = ThreadLocal.withInitial(() -> false);

    private static final Map<UUID, Long> SPACE_SLASH_COOLDOWN = new HashMap<>();
    private static final ThreadLocal<Boolean> PROCESSING_SPACE_SLASH = ThreadLocal.withInitial(() -> false);
    private static final Map<UUID, int[]> PENDING_SPACE_SLASHES = new HashMap<>();

    /** 空间斩每段递减：由配置项 space_slash_enchantment 控制（见 segmentDecayFactor）。 */

    /**
     * 本次攻击的暴击倍率（玩家 UUID → 倍率，未暴击为 1.0）。
     *
     * 由 onCriticalHit(CriticalHitEvent) 在 Player.attack() 内写入，
     * 供 handleSpaceSlash 取用；每次消费后由 cleanupStaleEntries 清掉过期项。
     * 维护者口径：空间斩三段都吃跳劈暴击，但不跳劈就不吃暴击数值。
     */
    private static final Map<UUID, Float> CRIT_DAMAGE = new HashMap<>();

    @SubscribeEvent
    public static void onEntityJoinLevel(EntityJoinLevelEvent event) {
        // 末影珍珠投出时，让「永恒」的次数生效（消耗次数而不是消耗珍珠本体）
        if (event.getEntity() instanceof net.minecraft.world.entity.projectile.ThrownEnderpearl pearl) {
            handleEnderPearlEternal(pearl);
            return;
        }
        handleEntityJoinLevelRest(event);
    }

    /**
     * 永恒附魔 · 末影珍珠。
     *
     * 维护者口径：「抛射类单指末影珍珠」。
     *
     * 为什么挂在 EntityJoinLevelEvent 上：末影珍珠被投出时，原版在
     * `EnderpearlItem.use()` 里直接 `stack.shrink(1)` 消耗掉珍珠，之后才 `level.addFreshEntity(pearl)`；
     * 等模组收到事件时手里的珍珠已经少了一个。
     * 所以这里的做法是：珍珠生成的那一刻，把玩家的永恒次数减 1，
     * 并**补偿那一个被原版消耗掉的珍珠**（次数还没用完的话），
     * 等价于「用永恒次数代替珍珠本体被消耗」。
     */
    private static void handleEnderPearlEternal(net.minecraft.world.entity.projectile.ThrownEnderpearl pearl) {
        if (pearl.level().isClientSide) return;
        if (!(pearl.getOwner() instanceof ServerPlayer player)) return;

        // 找出真正掏出珍珠的那只手
        ItemStack stack = null;
        boolean mainHand = true;
        if (isEternalPearl(player.getMainHandItem())) {
            stack = player.getMainHandItem();
        } else if (isEternalPearl(player.getOffhandItem())) {
            stack = player.getOffhandItem();
            mainHand = false;
        }
        if (stack == null) return;

        int remaining = EternalEnchantment.getRemainingUses(stack);
        if (remaining <= 0) return;

        // 扣一次永恒次数
        var tag = stack.getOrCreateTag();
        if (remaining > 1) {
            tag.putInt(EternalEnchantment.ETERNAL_USES_TAG, remaining - 1);
        } else {
            tag.remove(EternalEnchantment.ETERNAL_USES_TAG);   // 次数用尽，退回普通珍珠
        }
        stack.setTag(tag);

        // 补偿原版已经扣掉的那一个珍珠，让「消耗的是次数、不是珍珠」
        ItemStack refund = new ItemStack(net.minecraft.world.item.Items.ENDER_PEARL);
        if (mainHand) {
            ItemStack held = player.getMainHandItem();
            if (!held.isEmpty() && held.is(net.minecraft.world.item.Items.ENDER_PEARL)) {
                held.grow(1);
            } else if (!player.addItem(refund)) {
                player.drop(refund, false);
            }
        } else if (!player.addItem(refund)) {
            player.drop(refund, false);
        }

        if (!player.getPersistentData().getBoolean("eternal_any_granted")) {
            player.getPersistentData().putBoolean("eternal_any_granted", true);
            grantAdvancement(player, "eternal_any");
            int lvl = stack.getEnchantmentLevel(ModEnchantments.ETERNAL.get());
            if (lvl >= ModConfig.COMMON.eternalMaxLevel.get()) {
                grantAdvancement(player, "eternal_max");
            }
        }
    }

    /** 该物品是不是「带永恒次数」的末影珍珠。 */
    private static boolean isEternalPearl(ItemStack stack) {
        return !stack.isEmpty()
            && stack.is(net.minecraft.world.item.Items.ENDER_PEARL)
            && stack.getEnchantmentLevel(ModEnchantments.ETERNAL.get()) > 0;
    }

    // ══════════════════════════════════════════════════════════════════════
    //  千风之力：蓄力特殊箭 + 命中点决定扩散等级
    // ══════════════════════════════════════════════════════════════════════

    /**
     * 千风之力：满蓄力射出的箭变成「特殊箭」。
     *
     * 【怎么判断蓄满】Forge 的 {@link ArrowLooseEvent} 直接给了 {@code getCharge()}，
     * 就是原版 {@code BowItem.releaseUsing} 里算出来的拉弓 tick 数（满蓄力 = 20）。
     * 所以既不需要自己攒状态，也不需要额外加网络包。
     *
     * 未满 / 被打断 → 直接 return，什么都不做，射出的还是普通箭（与维护者口径一致）。
     */
    @SubscribeEvent
    public static void onArrowLoose(ArrowLooseEvent event) {
        if (event.getLevel().isClientSide) return;
        if (!(event.getEntity() instanceof ServerPlayer player)) return;

        int windLvl = event.getBow().getEnchantmentLevel(ModEnchantments.THOUSAND_WIND_FORCE.get());
        if (windLvl <= 0) return;

        // ★ 蓄力拉满才算「特殊箭」。
        // 硬性口径与 vanilla 完全一致：BowItem.getPowerForTime(charge) 在 charge >= 20 时才等于 1.0
        // （BowItem.java:94-102，getPowerForTime(20) = (1+2)/3 = 1.0），
        // 而 vanilla 也正是用 `if (f == 1.0F) setCritArrow(true)` 来标识满蓄力的。
        // 这样「特效 + 伤害」的门槛不会因为配置漂移而和原版手感脱节。
        if (net.minecraft.world.item.BowItem.getPowerForTime(event.getCharge()) < 1.0F) return;

        // 配置项可以再往后压（默认 20，与 vanilla 一致；调大则需要拉更久）
        int need = ModConfig.COMMON.fxWindChargeTicks.get();
        if (event.getCharge() < need) return;        // 未满 → 普通箭（什么都不做，射出的还是普通箭）
        if (!event.hasAmmo()) return;                // 没箭了，别凭空造一支

        // ⚠ 取消原版分支会**连带跳过"消耗一支箭"**。
        // 原版 BowItem.releaseUsing 的结构是：
        //     if (!event.isCanceled()) { 找箭 → 扣一支 → new Arrow(...) → addFreshEntity }
        // 我们把事件 cancel 掉、自己发特殊箭，那一步扣箭就被跳过了 —— 不补就是白嫖箭。
        // 所以这里手动扣一支（创造模式不扣）。
        if (!player.getAbilities().instabuild) {
            boolean consumed = false;
            for (int i = 0; i < player.getInventory().items.size(); i++) {
                ItemStack ammo = player.getInventory().items.get(i);
                if (ammo.isEmpty() || !ammo.is(net.minecraft.world.item.Items.ARROW)) continue;
                ammo.shrink(1);
                consumed = true;
                break;
            }
            if (!consumed) return;   // 背包里只有药箭之类：这一发当没发生，交给原版
        }

        // 射出一支带标记的「特殊箭」：它飞出去，命中点决定扩散等级
        var windArrow = new net.minecraft.world.entity.projectile.Arrow(player.level(), player);
        windArrow.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, 3.0F, 1.0F);
        windArrow.setCritArrow(true);
        windArrow.pickup = AbstractArrow.Pickup.DISALLOWED;   // 特殊箭不回收
        WindArrowMarker.mark(windArrow, windLvl, ThousandWindForceEnchantment.getStarCount(event.getBow()));
        player.level().addFreshEntity(windArrow);

        player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
            net.minecraft.sounds.SoundEvents.ARROW_SHOOT,
            net.minecraft.sounds.SoundSource.PLAYERS, 1.0F, 0.7F);
        event.setCanceled(true);                     // 原版那支普通箭不再射出
    }

    /**
     * 千风之力：特殊箭落地 / 命中时开扩散。
     *
     * 走到这里才知道打到的是什么 —— <b>打地面 = 最低级扩散，打怪物 = 最高级扩散</b>。
     * 这正是维护者要的那条差别，两种情况都有扩散动画。
     */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onWindArrowImpact(ProjectileImpactEvent event) {
        if (event.getEntity().level().isClientSide) return;
        if (!(event.getEntity() instanceof AbstractArrow arrow)) return;
        if (!WindArrowMarker.isMarked(arrow)) return;
        if (!(arrow.level() instanceof ServerLevel level)) return;

        int lvl = WindArrowMarker.getLevel(arrow);
        int stars = WindArrowMarker.getStars(arrow);
        WindArrowMarker.clear(arrow);

        boolean hitEntity = event.getRayTraceResult().getType() == HitResult.Type.ENTITY;
        Vec3 impact = event.getRayTraceResult().getLocation();
        LivingEntity caster = arrow.getOwner() instanceof LivingEntity le ? le : null;

        event.setCanceled(true);        // 特殊箭自己不结算伤害，改由扩散负责
        arrow.discard();
        ParticleEffectManager.triggerWind(level, impact, caster, lvl, stars, hitEntity);
    }

    /**
     * 千风蓄力时，在**玩家脚下**画一个法阵。
     *
     * <p>【2026-10-12 改版】维护者口径：「现在改为在玩家脚下放一个法阵，
     * 关键点再加上少量粒子效果」。旧版是在箭尖前方画垂直于箭矢的三道风环，已替换 ——
     * 所以这里不再需要把 yaw / pitch 传进去（法阵是平铺在脚下的）。
     *
     * <p>服务端每 tick 发一批粒子；蓄力进度直接取
     * {@code player.getTicksUsingItem()}，满蓄力时 charge = 1。
     */
    @SubscribeEvent
    public static void onPlayerTickChargeRings(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.player instanceof ServerPlayer player)) return;
        if (!(player.level() instanceof ServerLevel level)) return;

        ItemStack useItem = player.getUseItem();
        boolean drawing = player.isUsingItem()
            && useItem.getItem() instanceof net.minecraft.world.item.BowItem;
        int lvl = drawing ? useItem.getEnchantmentLevel(ModEnchantments.THOUSAND_WIND_FORCE.get()) : 0;

        if (lvl <= 0) {
            ParticleEffectManager.clearCharging(player.getUUID());
            return;
        }

        int chargeTicks = player.getTicksUsingItem();
        ParticleEffectManager.setCharging(player.getUUID(), chargeTicks);
        int need = ModConfig.COMMON.fxWindChargeTicks.get();
        double charge = Math.min(1.0, (double) chargeTicks / Math.max(1, need));
        double wall = ParticleEffectManager.windWallRadius(lvl, 0, false);
        ParticleEffectManager.spawnChargeArray(level, player, wall, charge);
    }

    // ══════════════════════════════════════════════════════════════════════
    //  星光之力：左键空气（客户端发包 → 服务端开演出）
    // ══════════════════════════════════════════════════════════════════════

    /**
     * 由 ClientModEvents 在「左键空气」时调用。
     *
     * 【为什么要绕一圈网络包】Forge 的 {@code PlayerInteractEvent.LeftClickEmpty}
     * 是**纯客户端**事件 —— 服务端根本收不到"玩家对着空气挥了一下"。
     * 而星光之力的触发就是这个动作，所以必须发包。
     */
    public static void requestStarlight() {
        cn.autoforged.rainbow_enchantment_mod.network.ModNetwork.CHANNEL
            .sendToServer(new cn.autoforged.rainbow_enchantment_mod.network.StarlightTriggerPacket());
    }

    private static void handleEntityJoinLevelRest(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide) return;

        // Super Nuke: 给刚被点燃的 TNT 打上「核弹等级」。
        //
        // 旧实现的判据是「点燃者是玩家 → 扫他的背包」。它有三个漏洞，正是维护者报的
        //「用普通 TNT 点燃超级核弹的 TNT 后，效果降级为普通 TNT」的直接原因：
        //   1. TntBlock.wasExploded（被别的爆炸点燃）用的是 explosion.getIndirectSourceEntity()，
        //      普通 TNT 爆炸时它是 null → 扫不了背包；红石点燃（onPlace/neighborChanged）同样传 null；
        //   2. 附魔挂在 TNT 「物品」上，方块本身不承载附魔数据，所以「这个方块是不是核弹 TNT」
        //      只能在放置那一刻记下来；
        //   3. 扫背包是「附近任意一枚 TNT」都能触发，误伤面大。
        // 现在改成：放置时把 (维度, 坐标) → 等级记进 SUPER_NUKE_TNT_BLOCKS，
        // 点燃时按 TNT 实体所在坐标查回来 —— 打火石 / 红石 / 普通 TNT 连锁 都拿得到等级。
        if (event.getEntity() instanceof PrimedTnt tnt) {
            CompoundTag nukeData = tnt.getPersistentData();
            int nukeLevel = nukeData.contains("super_nuke_level") ? nukeData.getInt("super_nuke_level") : 0;

            // (1) 玩家放置时登记过的坐标（首选，精确）
            if (nukeLevel <= 0 && event.getLevel() instanceof ServerLevel serverLevel) {
                BlockPos base = BlockPos.containing(tnt.getX(), tnt.getY(), tnt.getZ());
                for (BlockPos probe : new BlockPos[]{ base, base.above(), base.below() }) {
                    int lvl = takeSuperNukeBlockLevel(serverLevel, probe);
                    if (lvl > nukeLevel) nukeLevel = lvl;
                }
            }

            // (2) 兜底：保留旧的「扫描点燃者背包」判据
            if (nukeLevel <= 0 && tnt.getOwner() instanceof Player owner) {
                nukeLevel = bestSuperNukeLevel(owner);
            }

            if (nukeLevel > 0) {
                nukeData.putInt("super_nuke_level", nukeLevel);
            }
            return;
        }

        // Eternal Loyalty: track ItemEntity (dropped trident) for fire immunity
        if (event.getEntity() instanceof ItemEntity item) {
            ItemStack stack = item.getItem();
            if (stack.getItem() instanceof TridentItem
                && stack.getEnchantmentLevel(ModEnchantments.ETERNAL_LOYALTY.get()) > 0) {
                ETERNAL_LOYALTY_ITEM_ENTITIES.put(item.getUUID(), event.getLevel().dimension());
            }
            return;
        }

        if (!(event.getEntity() instanceof AbstractArrow arrow)) return;
        if (!(arrow.getOwner() instanceof Player player)) return;

        ItemStack bow = player.getMainHandItem();
        if (bow.isEmpty()) return;

        int quantumLevel = bow.getEnchantmentLevel(ModEnchantments.QUANTUM_ARROW.get());
        if (quantumLevel > 0) {
            arrow.setPierceLevel((byte) quantumLevel);
            arrow.setNoGravity(true);
            arrow.getPersistentData().putDouble("quantum_original_damage", arrow.getBaseDamage());
        }

        // 【千风之力不在这里打标记 —— 这是一个已修的 bug】
        // 旧代码在 EntityJoinLevelEvent 里无条件给「任何从千风弓射出的箭」写
        // thousand_wind_arrow，然后由 onProjectileImpact 在命中方块时放一圈固定 4 格 / 5 点伤害的 AOE。
        // 问题在于：EntityJoinLevelEvent 阶段箭已经生成完毕，**拿不到蓄力值**
        // （ArrowLooseEvent 的 getCharge() 是唯一可靠的来源，见 onArrowLoose），
        // 于是「未蓄力满的箭打地面也触发扩散」—— 这就是维护者报的
        // 「打在地面上会触发最低扩散」。
        // 现在千风特殊箭的身份只由 WindArrowMarker（rainbow_wind_arrow）标记，
        // 而它只在 ArrowLooseEvent 里、蓄力拉满时才写。
    }

    @SubscribeEvent
    public static void onMobFinalizeSpawn(MobSpawnEvent.FinalizeSpawn event) {
        Mob mob = event.getEntity();
        if (mob.level().isClientSide) return;
        if (mob.getPersistentData().contains(SIN_LEVEL_KEY)) return;

        int sinLevel = rollSinLevel(mob);
        if (sinLevel <= 0) return;

        mob.getPersistentData().putInt(SIN_LEVEL_KEY, sinLevel);
        applySinAttributeModifiers(mob, sinLevel);
        setSinfulCustomName(mob, sinLevel);
    }

    private static int rollSinLevel(Mob mob) {
        RandomSource random = mob.getRandom();
        EntityType<?> type = mob.getType();

        // ====== Special mobs with individual probability and level range ======

        var c = ModConfig.COMMON;

        // Ender Dragon: independent 22% → 12~20
        if (type == EntityType.ENDER_DRAGON) {
            if (random.nextDouble() < c.sinBossDragonChance.get()) {
                return rollWeightedSinLevel(random, c.sinBossDragonMinLevel.get(), c.sinBossDragonMaxLevel.get());
            }
            return 0;
        }

        // Wither: independent 22% → 12~20
        if (type == EntityType.WITHER) {
            if (random.nextDouble() < c.sinBossWitherChance.get()) {
                return rollWeightedSinLevel(random, c.sinBossWitherMinLevel.get(), c.sinBossWitherMaxLevel.get());
            }
            return 0;
        }

        // Warden: independent 15% → 10~20
        if (type == EntityType.WARDEN) {
            if (random.nextDouble() < c.sinBossWardenChance.get()) {
                return rollWeightedSinLevel(random, c.sinBossWardenMinLevel.get(), c.sinBossWardenMaxLevel.get());
            }
            return 0;
        }

        // Elder Guardian: independent 10% → 5~15
        if (type == EntityType.ELDER_GUARDIAN) {
            if (random.nextDouble() < c.sinBossElderGuardianChance.get()) {
                return rollWeightedSinLevel(random, c.sinBossElderGuardianMinLevel.get(), c.sinBossElderGuardianMaxLevel.get());
            }
            return 0;
        }

        // Enderman: independent 16% → 10~12
        if (type == EntityType.ENDERMAN) {
            if (random.nextDouble() < c.sinBossEndermanChance.get()) {
                return rollWeightedSinLevel(random, c.sinBossEndermanMinLevel.get(), c.sinBossEndermanMaxLevel.get());
            }
            return 0;
        }

        // Wither Skeleton: 5% → 15~20, else 10% → 10~15, else 20% → 1~10
        if (type == EntityType.WITHER_SKELETON) {
            if (random.nextDouble() < c.sinBossWitherSkeletonHighChance.get()) {
                return rollWeightedSinLevel(random, c.sinBossWitherSkeletonHighMin.get(), c.sinBossWitherSkeletonHighMax.get());
            }
            if (random.nextDouble() < c.sinBossWitherSkeletonMidChance.get()) {
                return rollWeightedSinLevel(random, c.sinBossWitherSkeletonMidMin.get(), c.sinBossWitherSkeletonMidMax.get());
            }
            if (random.nextDouble() < c.sinBossWitherSkeletonLowChance.get()) {
                return rollWeightedSinLevel(random, c.sinBossWitherSkeletonLowMin.get(), c.sinBossWitherSkeletonLowMax.get());
            }
            return 0;
        }

        // ====== Raid participants: difficulty-dependent probability and level cap ======
        if (mob.level() instanceof ServerLevel serverLevel) {
            Raid raid = serverLevel.getRaidAt(mob.blockPosition());
            if (raid != null && isRaidParticipant(mob, type)) {
                double raidChance;
                int raidMaxLevel;
                Difficulty difficulty = serverLevel.getDifficulty();
                if (serverLevel.getLevelData().isHardcore()) {
                    raidChance = c.sinRaidHardcoreChance.get();
                    raidMaxLevel = c.sinRaidHardcoreMaxLevel.get();
                } else {
                    switch (difficulty) {
                        case EASY -> {
                            raidChance = c.sinRaidEasyChance.get();
                            raidMaxLevel = c.sinRaidEasyMaxLevel.get();
                        }
                        case NORMAL -> {
                            raidChance = c.sinRaidNormalChance.get();
                            raidMaxLevel = c.sinRaidNormalMaxLevel.get();
                        }
                        case HARD -> {
                            raidChance = c.sinRaidHardChance.get();
                            raidMaxLevel = c.sinRaidHardMaxLevel.get();
                        }
                        default -> {
                            raidChance = 0.0;
                            raidMaxLevel = 1;
                        }
                    }
                }
                if (raidChance > 0 && random.nextDouble() < raidChance) {
                    return rollWeightedSinLevel(random, 1, raidMaxLevel);
                }
                return 0;
            }
        }

        // ====== Base system for all other mobs ======
        double baseChance = ModConfig.COMMON.sinSpawnChance.get();
        if (baseChance <= 0 || random.nextDouble() >= baseChance) return 0;

        ResourceLocation typeId = BuiltInRegistries.ENTITY_TYPE.getKey(type);
        String typeStr = typeId.toString();

        // Small mob whitelist/blacklist
        var monsterBlacklist = ModConfig.COMMON.sinMonsterBlacklist.get();
        boolean isBlacklistedFromSmall = monsterBlacklist.contains(typeStr);

        var monsterWhitelist = ModConfig.COMMON.sinMonsterWhitelist.get();
        if (!monsterWhitelist.isEmpty() && monsterWhitelist.contains(typeStr)) {
            int maxLv = ModConfig.COMMON.sinSmallMobMaxLevel.get();
            return rollWeightedSinLevel(random, 1, Math.min(maxLv, 6));
        }

        // Elite classification: min 5, max 15
        if (!isBlacklistedFromSmall && isEliteMob(mob, type, typeStr)) {
            int maxLv = ModConfig.COMMON.sinEliteMobMaxLevel.get();
            return rollWeightedSinLevel(random, 5, Math.min(maxLv, 15));
        }

        // Default small mob: min 1, max 6
        int maxLv = ModConfig.COMMON.sinSmallMobMaxLevel.get();
        return rollWeightedSinLevel(random, 1, Math.min(maxLv, 6));
    }

    /**
     * Weighted level selection with 42% decay per level.
     * Level 1 has base weight 1.0, level N has weight 0.42^(N-1).
     */
    private static int rollWeightedSinLevel(RandomSource random, int minLevel, int maxLevel) {
        if (minLevel >= maxLevel) return minLevel;

        int count = maxLevel - minLevel + 1;
        double[] weights = new double[count];
        double sum = 0;
        for (int i = 0; i < count; i++) {
            int level = minLevel + i;
            weights[i] = Math.pow(0.42, level - 1);
            sum += weights[i];
        }

        double r = random.nextDouble() * sum;
        for (int i = 0; i < count; i++) {
            r -= weights[i];
            if (r <= 0) {
                return minLevel + i;
            }
        }
        return maxLevel;
    }

    private static boolean isRaidParticipant(Mob mob, EntityType<?> type) {
        if (mob instanceof AbstractIllager) return true;
        return type == EntityType.RAVAGER || type == EntityType.WITCH;
    }

    private static boolean isEliteMob(LivingEntity entity, EntityType<?> type, String typeStr) {
        // Check elite blacklist first
        var eliteBlacklist = ModConfig.COMMON.sinEliteBlacklist.get();
        if (eliteBlacklist.contains(typeStr)) return false;

        // Check elite whitelist
        var eliteWhitelist = ModConfig.COMMON.sinEliteWhitelist.get();
        if (!eliteWhitelist.isEmpty()) {
            return eliteWhitelist.contains(typeStr);
        }

        return type == EntityType.VILLAGER || type == EntityType.IRON_GOLEM
            || type == EntityType.EVOKER || type == EntityType.VINDICATOR
            || type == EntityType.PILLAGER || type == EntityType.RAVAGER
            || type == EntityType.WITCH || type == EntityType.ILLUSIONER
            || type.getCategory() == MobCategory.MISC;
    }

    private static final UUID SIN_HP_UUID = UUID.fromString("d1e2f3a4-b5c6-7890-abcd-ef0123456701");
    private static final UUID SIN_SPEED_UUID = UUID.fromString("d1e2f3a4-b5c6-7890-abcd-ef0123456702");

    /** 罪孽/判定自定义护甲：每 1 点（护甲值 + 盔甲韧性）提供 0.001 减伤。 */
    private static final double SIN_ARMOR_REDUCTION_PER_POINT = 0.001;
    /** 自定义减伤上限，防止配置异常时把伤害压到 0 或负数。 */
    private static final double SIN_ARMOR_MAX_REDUCTION = 0.95;

    private static void applySinAttributeModifiers(Mob mob, int sinLevel) {
        int idx = Math.min(sinLevel - 1, SIN_LEVEL_DATA.length - 1);
        double hpBonus = SIN_LEVEL_DATA[idx].hpBonus;
        double speedBonus = SIN_LEVEL_DATA[idx].speedBonus;

        if (hpBonus > 0 && mob.getAttribute(Attributes.MAX_HEALTH) != null) {
            mob.getAttribute(Attributes.MAX_HEALTH).removeModifier(SIN_HP_UUID);
            mob.getAttribute(Attributes.MAX_HEALTH).addTransientModifier(
                new AttributeModifier(SIN_HP_UUID, "Sin HP bonus", hpBonus, AttributeModifier.Operation.MULTIPLY_BASE));
            mob.setHealth(mob.getMaxHealth());
        }

        if (speedBonus > 0 && mob.getAttribute(Attributes.MOVEMENT_SPEED) != null) {
            mob.getAttribute(Attributes.MOVEMENT_SPEED).removeModifier(SIN_SPEED_UUID);
            mob.getAttribute(Attributes.MOVEMENT_SPEED).addTransientModifier(
                new AttributeModifier(SIN_SPEED_UUID, "Sin speed bonus", speedBonus, AttributeModifier.Operation.MULTIPLY_BASE));
        }

        // defenseBonus 由 applySinPhysicalDamageReduction() 在受伤时按公式使用，不挂属性。

        // 罪孽防御力不在这里挂属性。
        //
        // 曾按「加成到护甲属性」实现过一版，但那会让防御力同时吃原版护甲公式，
        // 与维护者给的公式（每点 0.001 的自定义减伤）冲突，已改为纯计算实现：
        // 见 applySinPhysicalDamageReduction()。
        // 注意这里刻意**不动 Attributes.ARMOR**，以免污染原版护甲减免。
    }

    private static ChatFormatting getSinColor(int sinLevel) {
        if (sinLevel <= 5) return ChatFormatting.BLUE;
        if (sinLevel <= 8) return ChatFormatting.LIGHT_PURPLE;
        if (sinLevel <= 12) return ChatFormatting.RED;
        if (sinLevel <= 18) return ChatFormatting.DARK_PURPLE;
        if (sinLevel == 19) return ChatFormatting.BLACK;
        return ChatFormatting.DARK_RED;
    }

    private static void setSinfulCustomName(Mob mob, int sinLevel) {
        Component baseName = mob.getCustomName() != null ? mob.getCustomName() : mob.getName();
        String sinTag = "「罪孽深重" + sinLevel + "级」";
        ChatFormatting color = getSinColor(sinLevel);
        Component name = Component.literal("").append(baseName)
            .append(Component.literal(" ").withStyle(ChatFormatting.WHITE))
            .append(Component.literal(sinTag).withStyle(color));
        mob.setCustomName(name);
        mob.setCustomNameVisible(true);
    }

    private static final SinLevelEntry[] SIN_LEVEL_DATA = new SinLevelEntry[] {
        new SinLevelEntry(1, 0.05, 0.05, 0.00, 0.00, 0.00),
        new SinLevelEntry(2, 0.10, 0.10, 0.00, 0.00, 0.00),
        new SinLevelEntry(3, 0.15, 0.20, 0.00, 0.00, 0.00),
        new SinLevelEntry(4, 0.20, 0.25, 0.00, 0.00, 0.00),
        new SinLevelEntry(5, 0.25, 0.30, 0.00, 0.00, 0.00),
        new SinLevelEntry(6, 0.30, 0.35, 0.00, 0.00, 0.00),
        new SinLevelEntry(7, 0.35, 0.40, 0.00, 0.00, 0.00),
        new SinLevelEntry(8, 0.40, 0.45, 0.00, 0.00, 0.00),
        new SinLevelEntry(9, 0.45, 0.50, 0.00, 0.00, 0.00),
        new SinLevelEntry(10, 0.50, 1.00, 0.20, 0.00, 0.00),
        new SinLevelEntry(11, 0.55, 1.20, 0.25, 0.00, 0.00),
        new SinLevelEntry(12, 0.60, 1.40, 0.30, 0.00, 0.00),
        new SinLevelEntry(13, 0.60, 1.80, 0.40, 0.00, 0.00),
        new SinLevelEntry(14, 0.60, 2.00, 0.50, 0.00, 0.00),
        new SinLevelEntry(15, 0.60, 2.50, 0.70, 0.25, 0.00),
        new SinLevelEntry(16, 0.60, 3.00, 1.10, 0.40, 0.00),
        new SinLevelEntry(17, 0.60, 3.30, 1.50, 0.60, 0.00),
        new SinLevelEntry(18, 0.60, 3.60, 2.00, 0.80, 0.00),
        new SinLevelEntry(19, 0.60, 4.00, 3.00, 1.20, 0.00),
        new SinLevelEntry(20, 0.60, 4.20, 5.00, 4.00, 0.20),
    };

    private record SinLevelEntry(int sinLevel, double playerDmgReduction, double hpBonus,
                                  double enemyDmgBonus, double defenseBonus, double speedBonus) {}

    public static double getSinDropWeight(int sinLevel) {
        double base = ModConfig.COMMON.sinDropWeightBase.get();
        double max = ModConfig.COMMON.sinDropWeightMax.get();
        return base + (sinLevel - 1) * (max - base) / 19.0;
    }

    /**
     * 判决 vs 罪孽的伤害倍率（维护者口径，2026-10-10 定稿）。
     *
     * 规则：
     * <pre>
     *   基础倍率 = 1 + 罪孽等级 x 0.2%
     *   所需判决等级 req = 该罪孽等级在表格里对应的判决等级（动态查表）
     *     · 判决 >= req：每高 1 级 +1.5%
     *         → 倍率 = 基础倍率 x (1 + (判决 - req) x 0.015)
     *     · 判决 &lt;  req：按「罪孽深重的敌方加成」逐级降低伤害
     *         → 倍率 = 基础倍率 x (1 - 敌方加成 x (req - 判决))
     * </pre>
     * 维护者给的例子：罪孽 11 级需要 5 级判决才能打出正常伤害；
     * 低于 5 级按敌方加成降伤；6 级则比 5 级多 +1.5%。
     *
     * 「罪孽深重的敌方加成」= SIN_LEVEL_DATA[idx].enemyDmgBonus
     * （表格里 1~9 级为 0、10 级 20%、…、20 级 500%）。
     */
    public static double getSinPlayerDamageMultiplier(int judgmentLevel, int sinLevel) {
        if (sinLevel < 1 || sinLevel > 20) return 1.0;

        int idx = Math.min(sinLevel - 1, SIN_LEVEL_DATA.length - 1);
        SinLevelEntry entry = SIN_LEVEL_DATA[idx];

        // 基础倍率：罪孽等级本身带来的加成（罪孽越深、判决对它的伤害越高）
        // 系数 0.2%/级 已暴露为配置项 judgment_enchantment.sin_level_multiplier
        var jc = ModConfig.COMMON;
        double base = 1.0 + sinLevel * jc.judgmentSinLevelMultiplier.get();

        // 所需判决等级：动态查表，而不是拿判决的最高等级当基准
        int req = getSinRequiredJudgment(sinLevel);
        int diff = judgmentLevel - req;

        if (diff >= 0) {
            // 达到或超过所需等级：每高 1 级加成的比例可配置（默认 1.5%）
            return base * (1.0 + diff * jc.judgmentLevelDiffBonus.get());
        }

        // 低于所需等级：每低 1 级，按该等级「敌方加成」的比例降低伤害
        // （惩罚强度可配置，默认 1.0 = 原样使用表格里的敌方加成）
        double penaltyPerLevel = Math.max(0.0, entry.enemyDmgBonus) * jc.judgmentLevelDiffPenaltyScale.get();
        double multiplier = 1.0 - penaltyPerLevel * (-diff);
        return base * Math.max(0.0, multiplier);
    }

    /**
     * 该罪孽等级「需要」的判决等级（维基表格最后一列：1/1/1/1/2/2/3/3/4/5/5/6/7/8/9/12/15/20/22/30）。
     *
     * 说明：按维护者 2026-10-10 的更正，判决伤害只与「判决等级 - 罪孽等级」的差值挂钩
     * （每级 ±5%），因此这张表目前**不参与伤害计算**，仅作为设定参考保留，
     * 便于日后做「判决不足时无法破防」之类的机制。
     */
    private static int getSinRequiredJudgment(int sinLevel) {
        if (sinLevel <= 4) return 1;
        if (sinLevel <= 6) return 2;
        if (sinLevel <= 8) return 3;
        if (sinLevel == 9) return 4;
        if (sinLevel == 10 || sinLevel == 11) return 5;
        if (sinLevel == 12) return 6;
        if (sinLevel == 13) return 7;
        if (sinLevel == 14) return 8;
        if (sinLevel == 15) return 9;
        if (sinLevel == 16) return 12;
        if (sinLevel == 17) return 15;
        if (sinLevel == 18) return 20;
        if (sinLevel == 19) return 22;
        return 30;
    }

    @SubscribeEvent
    public static void onAnvilUpdate(AnvilUpdateEvent event) {
        ItemStack left = event.getLeft();
        ItemStack right = event.getRight();

        if (left.isEmpty() || right.isEmpty()) return;

        // ── 各锻造路线按「材料」分派，命中即停 ──────────────────────────────────
        //
        // 【原来为什么会「先锻造星光彩宝、再锻造樱花粉，星光彩宝就吃不动矿」】
        // 旧代码是一串 if + return：
        //     if (有星光之力 && 右边是下界之星) { ...; return; }
        //     if (有星光彩宝) { handleStarTreasureAnvil(...); return; }   // ← 无条件 return
        //     if (有樱花粉)   { handleCherryBlossomAnvil(...); return; }  // ← 无条件 return
        // 问题出在两个无条件 return：
        //   - 物品上同时有「星光彩宝」和「樱花粉」时，只要它有星光彩宝就先 return 掉，
        //     樱花粉那一支永远轮不到；
        //   - 反之，若某个 handler 因为材料不匹配而自己 return（没有 setOutput），
        //     外层也已经 return 了，于是这次锻造被整个吞掉。
        // 两种表现合起来，就是「后加的那个能用、先加的那个吃不动材料」。
        //
        // 现在每个 handler 都返回 boolean 表示「这次材料归我处理」，
        // 只有真的处理了才停；处理不了就继续往下交给别的路线。
        // 因为材料本身互斥（颜料不是矿物、樱花树苗/树叶也不是矿物），不会重复叠加。

        // 彩虹：吃颜料（任意有染料颜色的物品）
        if (left.getEnchantmentLevel(ModEnchantments.RAINBOW.get()) > 0) {
            DyeColor dyeColor = DyeColor.getColor(right);
            if (dyeColor != null && handleRainbowAnvil(event, left, right, dyeColor)) return;
        }

        // 星光彩宝：吃矿物 / 矿物方块 / 紫水晶（任意矿石标签命中的物品 + 相关材料）
        if (left.getEnchantmentLevel(ModEnchantments.STAR_TREASURE.get()) > 0) {
            if (handleStarTreasureAnvil(event, left, right)) return;
        }

        // 樱花粉：吃樱花树苗与樱花树叶
        if (left.getEnchantmentLevel(ModEnchantments.CHERRY_BLOSSOM.get()) > 0) {
            if (handleCherryBlossomAnvil(event, left, right)) return;
        }

        // 星光之力：吃下界之星（每次 +1 星，最多 20）
        if (left.getEnchantmentLevel(ModEnchantments.STARLIGHT_FORCE.get()) > 0
            && right.is(net.minecraft.world.item.Items.NETHER_STAR)) {
            if (handleStarlightAnvil(event, left)) return;
        }

        // 千风之力：吃下界之星（与星光之力各自独立计数）
        if (left.getEnchantmentLevel(ModEnchantments.THOUSAND_WIND_FORCE.get()) > 0
            && right.is(net.minecraft.world.item.Items.NETHER_STAR)) {
            if (handleThousandWindAnvil(event, left)) return;
        }
    }

    /** @return true 表示这次材料归彩虹处理（已设置输出） */
    private static boolean handleRainbowAnvil(AnvilUpdateEvent event, ItemStack left, ItemStack right, DyeColor dyeColor) {
        ItemStack output = left.copy();
        String newColor = dyeColor.getName();
        CompoundTag tag = output.getOrCreateTag();
        ListTag dyesList;
        if (tag.contains(RAINBOW_DYES_TAG, 9)) {
            dyesList = tag.getList(RAINBOW_DYES_TAG, 8);
        } else {
            dyesList = new ListTag();
        }

        int countOfColor = 0;
        for (int i = 0; i < dyesList.size(); i++) {
            if (dyesList.getString(i).equals(newColor)) countOfColor++;
        }
        if (countOfColor >= 5) return false;

        dyesList.add(StringTag.valueOf(newColor));
        tag.put(RAINBOW_DYES_TAG, dyesList);
        output.setTag(tag);

        event.setOutput(output);

        int totalDyes = dyesList.size();
        int[] counts = countDyes(output);
        int duplicate = counts[1];
        event.setCost(Math.min(30, 2 + totalDyes + duplicate));
        event.setMaterialCost(1);
        return true;
    }

    // ══════════════ 星光财宝：矿物识别与锻造 ══════════════
    //
    // 矿物清单与数值全部集中在 StarTreasureMinerals 这一张枚举表里，
    // 这里只负责「查表 → 次数上限 → 写 NBT → 定铁砧代价」。
    //
    // 识别顺序（维护者口径）：精确材料表优先，forge:ores 标签兜底。
    // 精确表命中后不再看标签，所以原版矿石方块不会被误判成「模组矿物」；
    // 只有非 minecraft 命名空间的 forge:ores 方块才归入 mod_ore（+0.01/个）。
    //
    // NBT 结构：star_treasure_data.{iron|diamond|redstone|...} = 已锻造次数。

    /** 一次锻造最多收多少级经验。次数上限高的矿物（铁 1400、模组矿物 1500）会把代价顶得很高。 */
    private static final int STAR_TREASURE_MAX_ANVIL_COST = 39;

    /** @return true 表示这次材料归星光财宝处理（已设置输出） */
    private static boolean handleStarTreasureAnvil(AnvilUpdateEvent event, ItemStack left, ItemStack right) {
        // ⚠ 绝对不能在 left 上调 getOrCreateTag()。
        //
        // 【这里原来有个「不锻造也生效」的 bug】
        // 旧代码第一行是 `var tag = left.getOrCreateTag();`，后面又往这个 tag 里 putInt。
        // 而 AnvilUpdateEvent 只是**预览**事件——它由 AnvilMenu.createResult() 触发，
        // 玩家每改一次铁砧输入就会跑一次，根本不是「完成锻造」。
        // 所以只要把武器和矿物摆上去，tag 就已经写进左边那把武器本身了：
        // 不点锻造、直接把武器从左槽拿走，矿物数照样 +1。
        //
        // 正确做法（彩虹那一支一直是对的）：先 copy 出 output，
        // 一切读写都发生在 output 的 tag 上，输入保持原样。
        StarTreasureMinerals mineral = StarTreasureMinerals.match(right);
        if (mineral == null) return false;      // 不是矿物 → 交给别的锻造路线

        int limit = mineral.getLimit();
        if (limit <= 0) return false;

        boolean blockForm = StarTreasureMinerals.isBlockForm(right);
        // 一次锻造消耗 1 个物品，但计入的「点数」不同：方块 10 点、材料 1 点。
        // 增幅按「每点」定义，所以方块锻造天然就是「锭的 10 倍」。
        int increment = blockForm ? StarTreasureMinerals.POINTS_PER_BLOCK_FORGE : 1;

        String mineralKey = mineral.getKey();
        CompoundTag tag = left.getTag();
        CompoundTag data = tag != null && tag.contains(StarTreasureEnchantment.STAR_TREASURE_DATA_TAG, 10)
            ? tag.getCompound(StarTreasureEnchantment.STAR_TREASURE_DATA_TAG)
            : new CompoundTag();
        int current = data.getInt(mineralKey);
        if (current >= limit) return false;

        int newCount = Math.min(limit, current + increment);

        ItemStack output = left.copy();
        CompoundTag outputTag = output.getOrCreateTag();
        CompoundTag outputData = outputTag.contains(StarTreasureEnchantment.STAR_TREASURE_DATA_TAG, 10)
            ? outputTag.getCompound(StarTreasureEnchantment.STAR_TREASURE_DATA_TAG)
            : new CompoundTag();
        outputData.putInt(mineralKey, newCount);
        outputTag.put(StarTreasureEnchantment.STAR_TREASURE_DATA_TAG, outputData);
        output.setTag(outputTag);

        event.setOutput(output);
        event.setCost(Math.min(STAR_TREASURE_MAX_ANVIL_COST, 1 + newCount / 10));
        event.setMaterialCost(1);
        return true;
    }

    /** @return true 表示这次材料归樱花粉处理（已设置输出） */
    private static boolean handleCherryBlossomAnvil(AnvilUpdateEvent event, ItemStack left, ItemStack right) {
        if (!right.is(net.minecraft.world.item.Items.CHERRY_SAPLING)
            && !right.is(net.minecraft.world.item.Items.CHERRY_LEAVES)) return false;

        // ⚠ 见 handleStarTreasureAnvil 的说明：绝不能对 left 调 getOrCreateTag()
        // （会在预览阶段就把 tag 写进输入物品，导致「不锻造也生效」）。
        // 这里只从 left 读，所有写入都落在 output 上。
        var leftTag = left.getTag();
        int current = leftTag == null ? 0 : leftTag.getInt(CherryBlossomEnchantment.CHERRY_BLOSSOM_COUNT_TAG);

        var item = left.getItem();
        var c = ModConfig.COMMON;
        int maxLimit;
        if (item instanceof net.minecraft.world.item.ArmorItem) maxLimit = c.cherryBlossomMaxArmor.get();
        else if (item.isEdible()) maxLimit = c.cherryBlossomMaxFood.get();
        else if (item instanceof net.minecraft.world.item.SwordItem) maxLimit = c.cherryBlossomMaxWeapon.get();
        else if (item instanceof net.minecraft.world.item.DiggerItem) maxLimit = c.cherryBlossomMaxTool.get();
        else return false;

        if (current >= maxLimit) return false;

        ItemStack output = left.copy();
        var outputTag = output.getOrCreateTag();
        outputTag.putInt(CherryBlossomEnchantment.CHERRY_BLOSSOM_COUNT_TAG, current + 1);
        output.setTag(outputTag);

        event.setOutput(output);
        event.setCost(2 + current / 10);
        event.setMaterialCost(1);
        return true;
    }

    /** @return true 表示已设置输出 */
    private static boolean handleStarlightAnvil(AnvilUpdateEvent event, ItemStack left) {
        // ⚠ 只读输入，写一律落在 output 上（原因见 handleStarTreasureAnvil）
        CompoundTag tag = left.getTag();
        int currentStars = tag == null ? 0 : tag.getInt(StarlightForceEnchantment.STARLIGHT_STARS_TAG);
        if (currentStars >= ModConfig.COMMON.netherStarForgeLimit.get()) return false;

        ItemStack output = left.copy();
        CompoundTag outputTag = output.getOrCreateTag();
        outputTag.putInt(StarlightForceEnchantment.STARLIGHT_STARS_TAG, currentStars + 1);
        output.setTag(outputTag);

        event.setOutput(output);
        event.setCost(3 + currentStars);
        event.setMaterialCost(1);
        return true;
    }

    /** @return true 表示已设置输出 */
    private static boolean handleThousandWindAnvil(AnvilUpdateEvent event, ItemStack left) {
        // ⚠ 只读输入，写一律落在 output 上（原因见 handleStarTreasureAnvil）
        CompoundTag tag = left.getTag();
        int currentStars = tag == null ? 0 : tag.getInt(ThousandWindForceEnchantment.THOUSAND_STARS_TAG);
        if (currentStars >= ModConfig.COMMON.netherStarForgeLimit.get()) return false;

        ItemStack output = left.copy();
        CompoundTag outputTag = output.getOrCreateTag();
        outputTag.putInt(ThousandWindForceEnchantment.THOUSAND_STARS_TAG, currentStars + 1);
        output.setTag(outputTag);

        event.setOutput(output);
        event.setCost(3 + currentStars);
        event.setMaterialCost(1);
        return true;
    }

    @SubscribeEvent
    public static void onAnvilRepair(AnvilRepairEvent event) {
        if (event.getEntity().level().isClientSide) return;
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        ItemStack left = event.getLeft();
        ItemStack output = event.getOutput();

        // colorful: first time adding dye
        if (output.getEnchantmentLevel(ModEnchantments.RAINBOW.get()) > 0) {
            int leftStars = left.getTag() != null && left.getTag().contains("rainbow_dyes", 9)
                ? left.getTag().getList("rainbow_dyes", 8).size() : 0;
            int outputStars = output.getTag() != null && output.getTag().contains("rainbow_dyes", 9)
                ? output.getTag().getList("rainbow_dyes", 8).size() : 0;
            if (leftStars == 0 && outputStars > 0) {
                grantAdvancement(player, "colorful");
            }
        }

        // starlight_sparkle: first nether star forge (starlight)
        if (output.getEnchantmentLevel(ModEnchantments.STARLIGHT_FORCE.get()) > 0) {
            int leftStars = left.getTag() != null ? left.getTag().getInt(StarlightForceEnchantment.STARLIGHT_STARS_TAG) : 0;
            int outputStars = output.getTag() != null ? output.getTag().getInt(StarlightForceEnchantment.STARLIGHT_STARS_TAG) : 0;
            if (leftStars == 0 && outputStars > 0) {
                grantAdvancement(player, "starlight_sparkle");
            }
        }

        // starlight_sparkle: first nether star forge (thousand wind)
        if (output.getEnchantmentLevel(ModEnchantments.THOUSAND_WIND_FORCE.get()) > 0) {
            int leftStars = left.getTag() != null ? left.getTag().getInt(ThousandWindForceEnchantment.THOUSAND_STARS_TAG) : 0;
            int outputStars = output.getTag() != null ? output.getTag().getInt(ThousandWindForceEnchantment.THOUSAND_STARS_TAG) : 0;
            if (leftStars == 0 && outputStars > 0) {
                grantAdvancement(player, "starlight_sparkle");
            }
        }

        // colorful_colors: all 16 dyes applied
        if (hasAllDyes(output)) {
            grantAdvancement(player, "colorful_colors");
        }

        // forge_5_stars: forge 5 nether stars on a single item
        if (output.getEnchantmentLevel(ModEnchantments.STARLIGHT_FORCE.get()) > 0) {
            int outputStars = output.getTag() != null ? output.getTag().getInt(StarlightForceEnchantment.STARLIGHT_STARS_TAG) : 0;
            if (outputStars >= 5) {
                grantAdvancement(player, "forge_5_stars");
            }
            if (outputStars >= 10) {
                grantAdvancement(player, "forge_10_stars");
            }
            if (outputStars >= 20) {
                grantAdvancement(player, "forge_20_stars");
            }
        }
        if (output.getEnchantmentLevel(ModEnchantments.THOUSAND_WIND_FORCE.get()) > 0) {
            int outputStars = output.getTag() != null ? output.getTag().getInt(ThousandWindForceEnchantment.THOUSAND_STARS_TAG) : 0;
            if (outputStars >= 5) {
                grantAdvancement(player, "forge_5_stars");
            }
            if (outputStars >= 10) {
                grantAdvancement(player, "forge_10_stars");
            }
            if (outputStars >= 20) {
                grantAdvancement(player, "forge_20_stars");
            }
        }

        // Eternal advancement: obtaining Eternal enchantment via anvil
        if (!player.getPersistentData().getBoolean("eternal_any_granted")) {
            int eternalLv = output.getEnchantmentLevel(ModEnchantments.ETERNAL.get());
            if (eternalLv > 0) {
                player.getPersistentData().putBoolean("eternal_any_granted", true);
                grantAdvancement(player, "eternal_any");
                if (eternalLv >= ModConfig.COMMON.eternalMaxLevel.get()) {
                    grantAdvancement(player, "eternal_max");
                }
            }
        }
    }

    @SubscribeEvent
    public static void onHarvestCheck(PlayerEvent.HarvestCheck event) {
        // 【不要在这里按客户端早退】
        // 事件的返回值同时被服务端的掉落判定（ServerPlayerGameMode.destroyBlock）
        // 和客户端的挖掘进度条使用：BlockBehaviour.getDestroyProgress 里
        // `isCorrectToolForDrops ? 30 : 100`（反编译 BlockBehaviour.java:445）。
        // 如果只在服务端回答 true，客户端会按「挖不动」的三倍慢速画进度条，
        // 出现「明明能挖，进度条却像卡住」的表现。这个 handler 是纯计算、无副作用，
        // TierSortingRegistry 的排序表两端都有，所以两端都跑。
        ItemStack tool = event.getEntity().getMainHandItem();
        int ubLevel = tool.getEnchantmentLevel(ModEnchantments.UNIVERSE_BREAKER.get());
        if (ubLevel <= 0) return;
        // 原版已经判定可以挖，就不用管
        if (event.canHarvest()) return;
        if (!(tool.getItem() instanceof DiggerItem digger)) return;

        // ── 寰宇破坏者：真正提高「有效工具等级」 ────────────────────────────────
        //
        // 维护者口径：「寰宇破坏者的提高工具等级，提高挖掘效率；加速和提高工具等级是同一个算法」。
        //
        // Forge 的工具等级由 TierSortingRegistry 的排序表决定：
        //   isCorrectTierForDrops(tier, state) 会检查「所有排在 tier 之上的等级」的方块标签，
        //   只要没有任何更高等级的标签命中该方块，就允许掉落。
        // 所以「把等级抬 N 档」= 拿排序表里 index + N 的那个等级去做同样的判定。
        //
        // 按「同一个算法」的指示，档位增量与挖掘加速共用同一表达式，两项都可配置。
        int boost = (int) (ModConfig.COMMON.universeBreakerTierBoostBase.get()
            + ModConfig.COMMON.universeBreakerTierBoostPerLevel.get() * ubLevel);
        Tier tier = digger.getTier();
        if (!TierSortingRegistry.isTierSorted(tier)) return;

        List<Tier> sorted = TierSortingRegistry.getSortedTiers();
        int index = sorted.indexOf(tier);
        if (index < 0) return;
        int effectiveIndex = Math.min(index + boost, sorted.size() - 1);
        Tier effective = sorted.get(effectiveIndex);

        BlockState state = event.getTargetBlock();

        // ★ 2026-10-12 修复：这里原本是
        //     if (ok && digger.isCorrectToolForDrops(tool, state)) event.setCanHarvest(true);
        //   而 DiggerItem#isCorrectToolForDrops 的实现是（反编译 DiggerItem.java:93-97）：
        //     return state.is(blocks) && TierSortingRegistry.isCorrectTierForDrops(getTier(), state);
        //   —— 它用的是工具【自己的】等级，也就是刚刚判定失败的那个条件本身。
        //   能走到这里的条件恰好是「vanilla 判定 canHarvest()==false」，对 DiggerItem 而言
        //   那个 false 就等于 `!(state.is(blocks) && isCorrectTierForDrops(ownTier, state))`，
        //   于是这个 gate 恒为 false，setCanHarvest(true) 从来没被执行过 ——
        //   寰宇破坏者的「提高挖掘等级」是一个完全的空操作，这正是「工具等级提升了，
        //   但方块不掉落」的根因。
        //   现在改成：用抬升后的 Tier 跑 Forge 官方判定 isCorrectTierForDrops(effective, state)；
        //   「工具类型是否适用」另用可挖掘标签判断（DiggerItem.blocks 是 private，没有 getter）。
        if (isToolApplicableTo(tool, state) && TierSortingRegistry.isCorrectTierForDrops(effective, state)) {
            event.setCanHarvest(true);
        }
    }

    /**
     * 工具类型是否适用于该方块材质 —— 只看「镐/斧/锹/锄 ↔ 可挖掘标签」，不看等级。
     *
     * <p>这些标签与 PickaxeItem / AxeItem / ShovelItem / HoeItem 构造时传入 {@code DiggerItem}
     * 的 {@code BlockTags.MINEABLE_WITH_*} 完全对应，因此在「不限等级」的意义上等价于
     * {@code state.is(digger.blocks)}。
     */
    private static boolean isToolApplicableTo(ItemStack tool, BlockState state) {
        var item = tool.getItem();
        if (item instanceof net.minecraft.world.item.PickaxeItem) {
            return state.is(net.minecraft.tags.BlockTags.MINEABLE_WITH_PICKAXE);
        }
        if (item instanceof net.minecraft.world.item.AxeItem) {
            return state.is(net.minecraft.tags.BlockTags.MINEABLE_WITH_AXE);
        }
        if (item instanceof net.minecraft.world.item.ShovelItem) {
            return state.is(net.minecraft.tags.BlockTags.MINEABLE_WITH_SHOVEL);
        }
        if (item instanceof net.minecraft.world.item.HoeItem) {
            return state.is(net.minecraft.tags.BlockTags.MINEABLE_WITH_HOE);
        }
        // 模组自定义 DiggerItem：退回「对该方块的挖掘速度是否真的被等级加成过」
        return tool.getDestroySpeed(state) > 1.0F;
    }

    @SubscribeEvent
    public static void onBreakSpeed(PlayerEvent.BreakSpeed event) {
        ItemStack tool = event.getEntity().getMainHandItem();
        int ubLevel = tool.getEnchantmentLevel(ModEnchantments.UNIVERSE_BREAKER.get());
        if (ubLevel > 0) {
            event.setNewSpeed(event.getNewSpeed()
                * (1.0f + ModConfig.COMMON.universeBreakerSpeedPerLevel.get().floatValue() * ubLevel));
        }
    }

    /**
     * 记录本次攻击的暴击倍率，供空间斩连斩取用。
     *
     * 【时序】Forge 的 CriticalHitEvent 在 Player.attack() 内、LivingHurtEvent **之前**触发
     * （ForgeHooks.getCriticalHit 在 LivingEntity.hurt 之前调用），
     * 所以 handleSpaceSlash 里读到的就是这个值，不会跨攻击串味。
     * 只有手持空间斩时才记录，把残留窗口压到最小。
     */
    /**
     * 药水抗性：降低「负面效果」的持续时间或效果等级。
     *
     * 维护者口径：「药水抗性的原效果是降低负面效果的药水时间 / 或者降低当前 debuff 的效果等级」。
     *
     * 【实现方式（2026-10-11 重写）】拦在 {@link MobEffectEvent.Added} 上，
     * <b>就地削弱</b>那个「即将被写进 activeEffects 的实例」，然后什么都不做。
     *
     * 【为什么不能 setCanceled(true) —— P0 崩溃根因】
     * Forge 1.20.1 里 {@code MobEffectEvent.Added} 只在类注释里写着
     * 「This event is not Cancelable」，它<b>没有</b> {@code @Cancelable} 注解
     * （对比同文件的 {@code MobEffectEvent.Remove} 才有 @Cancelable）。
     * {@code Event#setCanceled(boolean)} 对不可取消事件会直接抛
     * {@code UnsupportedOperationException: Attempted to call Event#setCanceled() on a non-cancelable event}。
     * 旧代码在 {@code ModEvents.java:1226} 调了它，于是：
     * 投掷药水命中 → 服务端 tick 药水实体 → addEffect → 事件回调 → 抛异常 → 服务端崩溃。
     *
     * 【为什么可以就地改】
     * 看 {@code LivingEntity#addEffect(MobEffectInstance, Entity)}（1.20.1 反编译源码约 971-988 行）：
     * <pre>
     *   if (!this.canBeAffected(pEffectInstance)) return false;
     *   MobEffectInstance mobeffectinstance = this.activeEffects.get(pEffectInstance.getEffect());
     *   MinecraftForge.EVENT_BUS.post(new MobEffectEvent.Added(this, mobeffectinstance, pEffectInstance, pEntity)); // ← 事件在这里
     *   if (mobeffectinstance == null) {
     *       this.activeEffects.put(pEffectInstance.getEffect(), pEffectInstance);   // ← 存的就是同一个对象
     *       this.onEffectAdded(pEffectInstance, pEntity);                          // ← 发的包也读这个对象
     * </pre>
     * 事件在「入 map」<b>之前</b>触发，而且 {@code getEffectInstance()} 返回的就是
     * 紧接着会被存进 map、并同步给客户端的那个引用。所以在这里改 duration/amplifier
     * 既不需要取消事件、也不需要重新 addEffect，更不存在重入与栈溢出。
     *
     * 【为什么要 AT】{@code duration} / {@code amplifier} 是 private 字段，
     * 已在 {@code META-INF/accesstransformer.cfg} 里放开为 public
     * （SRG 名 f_19503_ / f_19504_，来自 1.20.1 官方映射表，非猜测）。
     */
    @SubscribeEvent
    public static void onEffectAddedForPotionResistance(MobEffectEvent.Added event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide) return;
        if (!(entity instanceof Player player)) return;

        MobEffectInstance instance = event.getEffectInstance();
        if (instance == null) return;

        // 只削弱负面效果
        MobEffect effect = instance.getEffect();
        if (effect == null) return;
        if (effect.getCategory() != MobEffectCategory.HARMFUL) return;

        int totalLevel = 0;
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            if (slot.getType() != EquipmentSlot.Type.ARMOR) continue;
            totalLevel += player.getItemBySlot(slot).getEnchantmentLevel(ModEnchantments.POTION_RESISTANCE.get());
        }
        if (totalLevel <= 0) return;

        double perLevel = ModConfig.COMMON.potionResistancePerLevel.get();
        int steps = (int) (totalLevel * perLevel * 100.0 / 5.0);   // 每级 5%，换算成「5% 一步」
        if (steps <= 0) return;

        // 多少档位用于压效果等级、剩下的用于压时长 —— 由配置项 amplifier_share 控制
        double ampShare = ModConfig.COMMON.potionResistanceAmplifierShare.get();
        int ampSteps = (int) Math.round(steps * ampShare);
        int ampReduction = Math.min(ampSteps, instance.getAmplifier());
        int durationReduction = steps - ampReduction * 2;

        int oldAmplifier = instance.getAmplifier();
        int oldDuration = instance.getDuration();

        int newAmplifier = oldAmplifier - ampReduction;
        int newDuration = oldDuration;
        // 无限时长（-1）不能被乘算，否则会变成一个极短的 1 tick 效果
        if (durationReduction > 0 && !instance.isInfiniteDuration()) {
            newDuration = Math.max(1, (int) (oldDuration * (1.0 - durationReduction * 0.05)));
        }

        if (newAmplifier == oldAmplifier && newDuration == oldDuration) return;

        instance.amplifier = newAmplifier;
        instance.duration = newDuration;
    }

    @SubscribeEvent
    public static void onCriticalHit(net.minecraftforge.event.entity.player.CriticalHitEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (player.getMainHandItem().getEnchantmentLevel(ModEnchantments.SPACE_SLASH.get()) <= 0) return;
        if (event.getResult() == net.minecraftforge.eventbus.api.Event.Result.DENY) {
            CRIT_DAMAGE.remove(player.getUUID());
            return;
        }
        CRIT_DAMAGE.put(player.getUUID(), event.getDamageModifier());
    }

    @SubscribeEvent
    public static void onLivingHurt(LivingHurtEvent event) {
        if (event.getEntity().level().isClientSide) return;
        if (PROCESSING_HURT.get()) return;
        if (PROCESSING_SPACE_SLASH.get()) return;

        PROCESSING_HURT.set(true);
        try {
            // 罪孽 / 判定的自定义护甲减伤最先算（顺序：防御力 → 护甲值 → 减伤）
            applySinPhysicalDamageReduction(event);
            handleSinDamage(event);
            handleRainbowArmor(event);
            handleDeepSeaFireBoost(event);
            handleForestStrike(event);
            handleJudgmentDamage(event);
            handleEternalLoyaltyDamage(event);
            handleSpaceSlash(event);
            handleCherryBlossomHurt(event);
            handlePlunderDamage(event);
            handlePervertSteal(event);
            handleImmaculateDamageReduction(event);
            handleUndyingProtection(event);
        } finally {
            PROCESSING_HURT.set(false);
        }
    }

    @SubscribeEvent
    public static void onItemAttributeModifier(ItemAttributeModifierEvent event) {
        ItemStack stack = event.getItemStack();
        EquipmentSlot slotType = event.getSlotType();

        if (slotType == EquipmentSlot.MAINHAND && stack.getItem() instanceof SwordItem) {
            handleRainbowSwordAttribute(event, stack);
            handleStarTreasureAttribute(event, stack);
        }
    }

    private static void handleRainbowSwordAttribute(ItemAttributeModifierEvent event, ItemStack stack) {
        int rainbowLevel = stack.getEnchantmentLevel(ModEnchantments.RAINBOW.get());
        if (rainbowLevel <= 0) return;

        int[] counts = countDyes(stack);
        int unique = counts[0];
        int duplicate = counts[1];
        if (unique <= 0 && duplicate <= 0) return;

        double rawBonus = (unique + duplicate) * rainbowLevel;
        double bonus = rawBonus * ModConfig.COMMON.rainbowSwordDamageMultiplier.get();

        if (bonus > 0) {
            Attribute attribute = Attributes.ATTACK_DAMAGE;
            AttributeModifier modifier = new AttributeModifier(
                RAINBOW_DAMAGE_MODIFIER_UUID,
                "Rainbow dye bonus",
                bonus,
                AttributeModifier.Operation.ADDITION
            );
            event.addModifier(attribute, modifier);
        }
    }

    // ══════════════ 星光财宝：属性加成 ══════════════
    //
    // 三类加成各自一个固定 UUID（换装/重算时必须一致，否则修饰符会重复叠加或删除不掉）：
    //   ATTACK_DAMAGE -> 钻石 / 紫水晶 / 回响碎片 / 萤石 / 下界合金 / 青金石 / 下界石英 / 模组矿物
    //   ATTACK_SPEED  -> 红石（唯一的速度类）
    //   MAX_DAMAGE    -> 耐久类，见下面 MODE_A 的说明

    private static final UUID STAR_TREASURE_DAMAGE_UUID = UUID.nameUUIDFromBytes("star_treasure_damage".getBytes());
    private static final UUID STAR_TREASURE_SPEED_UUID = UUID.nameUUIDFromBytes("star_treasure_speed".getBytes());

    private static void handleStarTreasureAttribute(ItemAttributeModifierEvent event, ItemStack stack) {
        if (stack.getEnchantmentLevel(ModEnchantments.STAR_TREASURE.get()) <= 0) return;

        StarTreasureMinerals.Stats stats = StarTreasureMinerals.computeStats(stack.getTag());

        if (stats.damage() > 0) {
            event.addModifier(Attributes.ATTACK_DAMAGE, new AttributeModifier(
                STAR_TREASURE_DAMAGE_UUID, "Star Treasure damage",
                stats.damage(), AttributeModifier.Operation.ADDITION));
        }
        if (stats.speed() > 0) {
            event.addModifier(Attributes.ATTACK_SPEED, new AttributeModifier(
                STAR_TREASURE_SPEED_UUID, "Star Treasure speed",
                stats.speed(), AttributeModifier.Operation.ADDITION));
        }
        if (stats.durability() > 0) {
            // ── 耐久这一路为什么不加 AttributeModifier ──────────────────────────
            //
            // 「最大耐久 +N」现在由 StarTreasureMixin 注入 ItemStack#getMaxDamage 实现
            // （真正的最大耐久提升：耐久条更长、hurthAndBreak 的判据一并生效）。
            //
            // 属性系统这边刻意什么都不加：1.20.1 没有 MAX_DAMAGE 这个属性
            // （它是 MC 1.21 才加的），硬编一个只会让属性面板出现一个不起作用的条目。
            // 耐久数值的可见性由 ClientModEvents 的 tooltip「耐久合计 +N」负责。
            //
            // 是否生效由 durability_mode 决定：NONE / RESTORE_ON_BREAK 时 mixin 会跳过。
        }
    }

    @SubscribeEvent
    public static void onLivingHeal(LivingHealEvent event) {
        LivingEntity entity = event.getEntity();
        var effect = entity.getEffect(ModEffects.RUIN_WITHER.get());
        if (effect == null) return;

        int level = effect.getAmplifier() + 1;
        float limitPerLevel = ModConfig.COMMON.ruinWitherHealLimitPerLevel.get().floatValue();
        float maxLimit = ModConfig.COMMON.ruinWitherHealLimitMax.get().floatValue();
        float reduction = Math.min(maxLimit, limitPerLevel * level);
        event.setAmount(event.getAmount() * (1.0f - reduction));
    }

    @SubscribeEvent
    public static void onEquipmentChange(LivingEquipmentChangeEvent event) {
        if (event.getEntity().level().isClientSide) return;
        if (!(event.getEntity() instanceof net.minecraft.world.entity.player.Player player)) return;

        // Cherry Blossom armor HP bonus: recalc on ANY equipment slot change
        handleCherryBlossomArmor(player);

        if (event.getSlot().getType() != EquipmentSlot.Type.ARMOR) return;

        recalculateImmaculateBonuses(player);
    }

    /**
     * 重算「无暇」的四项属性加成。
     *
     * 之所以要单独抽出来：属性修饰符用的是 addTransientModifier，它**不会**跟着玩家
     * 重生 / 换维度复制过去，只在装备变化时重算的话，死亡重生后加成会凭空消失。
     * 因此 PlayerEvent.Clone 里也要调一次。
     */
    private static void recalculateImmaculateBonuses(Player player) {
        player.getAttribute(Attributes.MAX_HEALTH).removeModifier(IMMACULATE_HP_PCT_UUID);
        player.getAttribute(Attributes.MAX_HEALTH).removeModifier(IMMACULATE_HP_FLAT_UUID);
        player.getAttribute(Attributes.ATTACK_DAMAGE).removeModifier(IMMACULATE_ATK_PCT_UUID);
        player.getAttribute(Attributes.ATTACK_DAMAGE).removeModifier(IMMACULATE_ATK_FLAT_UUID);

        int totalLevel = 0;
        int piecesCount = 0;
        int maxLevel = 0;
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            if (slot.getType() != EquipmentSlot.Type.ARMOR) continue;
            int lvl = player.getItemBySlot(slot).getEnchantmentLevel(ModEnchantments.IMMACULATE.get());
            if (lvl > 0) {
                piecesCount++;
                totalLevel += lvl;
                if (lvl > maxLevel) maxLevel = lvl;
            }
        }
        if (maxLevel <= 0) return;

        // ── 无暇：按设定实现 ────────────────────────────────────────────────────
        //
        // 设定（原文）：
        //   提升数值：  2 + (((11 x 2) x 5%) + (附魔等级 x 2) x 2.55) + 10
        //   攻击力提升：1 + (((12 x 2) x 15%) + (附魔等级 x 2) x 1.55) + 5
        //   攻击力最大提升 520，生命值最大提升为当前生命值的 150%
        //   生命值到 1520 时减伤 1%，此后每多 15% 生命额外减伤 0.5%，最大到 11520 生命
        //
        // 「附魔等级」取四件的等级之和 totalLevel（四件满级 = 40）。
        //
        // 【关于「每多穿一件」】
        // 维护者明确：无暇按「圣遗物 / 仪器」标准设计，**每件只生效 1/4**——
        // 穿 1 件 = 1/4、2 件 = 2/4、3 件 = 3/4、4 件 = 完整生效。
        // 上面两条公式算出来的就是「4 件的完整值」，因此最后统一乘以 (件数 / 4)。
        // （原实现是「* (1 + (件数-1)*5%)」的递增式，与 1/4 模型不符，已改。）
        //
        // 公式里的所有常量都已暴露为配置项（flawless_enchantment 分组），整合包作者可直接调。
        var fc = ModConfig.COMMON;
        double fullHpBonus = fc.immaculateHpBase.get()
            + ((fc.immaculateHpHealthFactor.get() * 2.0) * fc.immaculateHpHealthPercent.get()
               + (totalLevel * fc.immaculateHpLevelFactor.get()) * fc.immaculateHpLevelMultiplier.get())
            + fc.immaculateHpFlat.get();
        double fullAtkBonus = fc.immaculateAtkBase.get()
            + ((fc.immaculateAtkAttackFactor.get() * 2.0) * fc.immaculateAtkAttackPercent.get()
               + (totalLevel * fc.immaculateAtkLevelFactor.get()) * fc.immaculateAtkLevelMultiplier.get())
            + fc.immaculateAtkFlat.get();

        double pieceRatio = Math.min(1.0, piecesCount / 4.0);
        double hpBonus = fullHpBonus * pieceRatio;
        double atkBonus = fullAtkBonus * pieceRatio;

        // 生命上限：最大提升为「基础生命值的 N 倍」（配置项 hp_cap_ratio）。
        // 用 getBaseValue() 而不是 getValue()：后者包含本方法刚挂上去的修饰符，
        // 会造成每次重算都按「已经加过的值」再算一遍，数值来回漂。
        var maxHealthAttr = player.getAttribute(Attributes.MAX_HEALTH);
        if (maxHealthAttr != null) {
            double baseMaxHealth = maxHealthAttr.getBaseValue();
            hpBonus = Math.min(hpBonus, baseMaxHealth * fc.immaculateHpCapRatio.get());
            maxHealthAttr.addTransientModifier(
                new AttributeModifier(IMMACULATE_HP_FLAT_UUID, "Immaculate HP bonus", hpBonus, AttributeModifier.Operation.ADDITION));
        }

        // 攻击力：硬上限（配置项 attack_cap）
        var attackAttr = player.getAttribute(Attributes.ATTACK_DAMAGE);
        if (attackAttr != null) {
            atkBonus = Math.min(atkBonus, fc.immaculateAttackCap.get());
            attackAttr.addTransientModifier(
                new AttributeModifier(IMMACULATE_ATK_FLAT_UUID, "Immaculate ATK bonus", atkBonus, AttributeModifier.Operation.ADDITION));
        }
        // 百分比修饰符在新设定里没有对应项，不再挂载（UUID 仍在上方 removeModifier，确保旧存档不残留）
        // cute_girl_heart: full set of Immaculate enchanted equipment
        if (piecesCount == 4) {
            ServerPlayer sp = (ServerPlayer) player;
            if (!sp.getPersistentData().getBoolean("cute_girl_heart_granted")) {
                sp.getPersistentData().putBoolean("cute_girl_heart_granted", true);
                grantAdvancement(sp, "cute_girl_heart");
            }
        }
    }

    private static final UUID CHERRY_BLOSSOM_HP_UUID = UUID.nameUUIDFromBytes("cherry_blossom_hp".getBytes());

    // ── 无暇：数值上限与减伤门槛 ──────────────────────────────────────────────
    // 这些数值原先写死在这里，现已全部暴露为配置项（flawless_enchantment 分组）：
    //   hp_cap_ratio / attack_cap / damage_reduction_start_health /
    //   damage_reduction_step_ratio / damage_reduction_base /
    //   damage_reduction_step_bonus / damage_reduction_max_health / damage_reduction_cap

    /**
     * 无暇减伤：生命值到 1520 减伤 1%，此后每多 15% 生命额外减伤 0.5%。
     *
     * 设定原文把这档减伤绑在「生命值」上，而生命值上限靠无暇自己堆到 1520 是不现实的
     * （4 件满级约 284），所以这套减伤实际只在生命上限被其它来源堆高时生效，
     * 这是设定阶梯本身决定的。
     */
    private static void handleImmaculateDamageReduction(LivingHurtEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (player.level().isClientSide) return;

        double maxHealth = player.getMaxHealth();
        var dc = ModConfig.COMMON;
        if (maxHealth < dc.immaculateDrStartHealth.get()) return;

        int pieces = 0;
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            if (slot.getType() != EquipmentSlot.Type.ARMOR) continue;
            if (player.getItemBySlot(slot).getEnchantmentLevel(ModEnchantments.IMMACULATE.get()) > 0) pieces++;
        }
        if (pieces <= 0) return;

        double startHealth = dc.immaculateDrStartHealth.get();
        double maxHealthCap = dc.immaculateDrMaxHealth.get();
        double stepSize = startHealth * dc.immaculateDrStepRatio.get();
        int steps = (int) Math.floor((Math.min(maxHealth, maxHealthCap) - startHealth) / stepSize);
        steps = Math.max(0, steps);

        double reduction = dc.immaculateDrBase.get() + steps * dc.immaculateDrStepBonus.get();
        reduction = Math.min(reduction, dc.immaculateDrCap.get());
        // 件数按比例生效：1 件算 1/4
        reduction *= pieces / 4.0;

        event.setAmount((float) (event.getAmount() * (1.0 - reduction)));
    }

    /**
     * 重生 / 换维度后重挂属性加成。
     *
     * 【为什么需要这个处理器】
     * 「无暇」和「樱花」的加成都是 addTransientModifier 挂上去的临时修饰符。
     * 玩家死亡重生或跨维度时实体对象会被替换，临时修饰符不会带过去，
     * 而原来的代码只在 LivingEquipmentChangeEvent 里重算——
     * 重生后如果没换装备，这个事件不会触发，加成就会一直缺失。
     */
    @SubscribeEvent
    public static void onPlayerClone(net.minecraftforge.event.entity.player.PlayerEvent.Clone event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (player.level().isClientSide) return;

        handleCherryBlossomArmor(player);
        recalculateImmaculateBonuses(player);
    }

    private static void handleCherryBlossomArmor(Player player) {
        int totalCount = 0;
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            if (slot.getType() != EquipmentSlot.Type.ARMOR) continue;
            ItemStack armor = player.getItemBySlot(slot);
            int cbLevel = armor.getEnchantmentLevel(ModEnchantments.CHERRY_BLOSSOM.get());
            if (cbLevel <= 0) continue;
            var tag = armor.getTag();
            if (tag != null) {
                totalCount += tag.getInt(CherryBlossomEnchantment.CHERRY_BLOSSOM_COUNT_TAG);
            }
        }

        var hpAttr = player.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH);
        if (hpAttr == null) return;
        hpAttr.removeModifier(CHERRY_BLOSSOM_HP_UUID);

        if (totalCount > 0) {
            hpAttr.addTransientModifier(
                new AttributeModifier(CHERRY_BLOSSOM_HP_UUID, "Cherry Blossom HP bonus",
                    totalCount, AttributeModifier.Operation.ADDITION));
        }
    }

    @SubscribeEvent
    public static void onEnderTeleport(EntityTeleportEvent.EnderEntity event) {
        if (event.getEntity() instanceof LivingEntity living && living.hasEffect(ModEffects.ENDER_SHACKLE.get())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onItemUseFinish(LivingEntityUseItemEvent.Finish event) {
        if (event.getEntity().level().isClientSide) return;
        ItemStack stack = event.getItem();

        // Cherry Blossom food: boost saturation and hunger
        if (stack.isEdible()) {
            int cbLevel = stack.getEnchantmentLevel(ModEnchantments.CHERRY_BLOSSOM.get());
            if (cbLevel > 0 && event.getEntity() instanceof Player player) {
                var tag = stack.getTag();
                if (tag != null && tag.contains(CherryBlossomEnchantment.CHERRY_BLOSSOM_COUNT_TAG)) {
                    int count = tag.getInt(CherryBlossomEnchantment.CHERRY_BLOSSOM_COUNT_TAG);
                    if (count > 0) {
                        player.getFoodData().eat(count, count);
                    }
                }
            }
        }

        int eternalLevel = stack.getEnchantmentLevel(ModEnchantments.ETERNAL.get());
        if (eternalLevel <= 0) return;

        if (event.getEntity() instanceof ServerPlayer sp) {
            if (!sp.getPersistentData().getBoolean("eternal_any_granted")) {
                sp.getPersistentData().putBoolean("eternal_any_granted", true);
                grantAdvancement(sp, "eternal_any");
                if (eternalLevel >= ModConfig.COMMON.eternalMaxLevel.get()) {
                    grantAdvancement(sp, "eternal_max");
                }
            }
        }

        int remaining = EternalEnchantment.getRemainingUses(stack);
        if (remaining <= 0) return;

        CompoundTag tag = stack.getOrCreateTag();
        if (remaining > 1) {
            tag.putInt(EternalEnchantment.ETERNAL_USES_TAG, remaining - 1);
            stack.setTag(tag);
            event.setResultStack(stack.copy());
        } else {
            tag.remove(EternalEnchantment.ETERNAL_USES_TAG);
            stack.setTag(tag);
        }
    }



    @SubscribeEvent
    public static void onLivingUseTotem(LivingUseTotemEvent event) {
        if (event.isCanceled()) return;
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (player.level().isClientSide) return;

        ItemStack totem = event.getTotem();
        int count = player.getPersistentData().getInt("totem_uses") + 1;
        player.getPersistentData().putInt("totem_uses", count);
        if (count >= 10) {
            grantAdvancement(player, "totem_10");
        }
        if (count >= 100) {
            grantAdvancement(player, "totem_100");
        }

        int eternalLevel = totem.getEnchantmentLevel(ModEnchantments.ETERNAL.get());
        if (eternalLevel > 0) {
            int remaining = EternalEnchantment.getRemainingUses(totem);
            if (remaining > 0) {
                // 【原来的 bug：图腾根本没被消耗】
                // 旧代码只把 eternal_uses 减 1，然后 totem.copy() 原样放回背包 ——
                // 复制品的 count 一个都没少，所以「次数」成了摆设：
                // 一组 8 个带永恒的不死图腾可以无限次复活，图腾一个都不掉。
                //
                // 对照生效的金苹果/药水那条路径（onItemUseFinish）：
                // 它是用 event.setResultStack(...) 承担「消耗一个」的语义；
                // LivingUseTotemEvent 没有等价的 result stack，原版是靠自己
                // shrink(1) 消耗图腾的，所以这里必须由我们显式扣掉一个。
                ItemStack replacement = totem.copyWithCount(totem.getCount() - 1);
                if (!replacement.isEmpty()) {
                    var tag = replacement.getOrCreateTag();
                    if (remaining > 1) {
                        tag.putInt(EternalEnchantment.ETERNAL_USES_TAG, remaining - 1);
                    } else {
                        // 次数用尽：清掉标记，这一件退回普通图腾
                        tag.remove(EternalEnchantment.ETERNAL_USES_TAG);
                    }
                    replacement.setTag(tag);

                    InteractionHand hand = event.getHandHolding();
                    player.getServer().executeIfPossible(() -> {
                        if (!player.isAlive()) return;
                        if (hand == InteractionHand.OFF_HAND && player.getOffhandItem().isEmpty()) {
                            player.setItemSlot(EquipmentSlot.OFFHAND, replacement);
                        } else if (hand == InteractionHand.MAIN_HAND && player.getMainHandItem().isEmpty()) {
                            player.setItemSlot(EquipmentSlot.MAINHAND, replacement);
                        } else if (!player.addItem(replacement)) {
                            player.drop(replacement, false);
                        }
                    });
                }

                if (!player.getPersistentData().getBoolean("eternal_any_granted")) {
                    player.getPersistentData().putBoolean("eternal_any_granted", true);
                    grantAdvancement(player, "eternal_any");
                    if (eternalLevel >= ModConfig.COMMON.eternalMaxLevel.get()) {
                        grantAdvancement(player, "eternal_max");
                    }
                }
            }
        }
    }
    private static final Map<UUID, Long> OXYGEN_LAST_REGEN = new HashMap<>();

    private static final java.util.Map<java.util.UUID, Long> ETERNAL_MENDING_COOLDOWN = new java.util.HashMap<>();

    @SubscribeEvent
    public static void onLivingTick(LivingEvent.LivingTickEvent event) {
        if (!(event.getEntity() instanceof net.minecraft.world.entity.player.Player player)) return;
        if (player.level().isClientSide) return;

        // Oxygen: restore underwater air
        if (player.isUnderWater()) {
            int oxygenLevel = player.getItemBySlot(EquipmentSlot.HEAD)
                .getEnchantmentLevel(ModEnchantments.OXYGEN.get());
            if (oxygenLevel > 0) {
                long now = player.level().getGameTime();
                long lastRegen = OXYGEN_LAST_REGEN.getOrDefault(player.getUUID(), 0L);
                int interval = ModConfig.COMMON.oxygenIntervalTicks.get();
                int respirationLevel = player.getItemBySlot(EquipmentSlot.HEAD)
                    .getEnchantmentLevel(net.minecraft.world.item.enchantment.Enchantments.RESPIRATION);
                if (respirationLevel > 0) {
                    interval -= respirationLevel * ModConfig.COMMON.oxygenIntervalReductionPerRespirationLevel.get();
                    interval = Math.max(10, interval);
                }
                if (now - lastRegen >= interval) {
                    int air = player.getAirSupply();
                    int maxAir = player.getMaxAirSupply();
                    if (air < maxAir) {
                        player.setAirSupply(Math.min(maxAir, air + 1));
                    }
                    OXYGEN_LAST_REGEN.put(player.getUUID(), now);
                }
            }
        }


        // Eternal + Mending auto-restore
        if (ModConfig.COMMON.eternalMendingRepair.get()) {
        long gameTime = player.level().getGameTime();
        Long lastMending = ETERNAL_MENDING_COOLDOWN.get(player.getUUID());
        if (lastMending == null || (gameTime - lastMending) >= 20) {
            for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
                ItemStack invStack = player.getInventory().getItem(i);
                if (invStack.isEmpty()) continue;
                int eternalLevel = invStack.getEnchantmentLevel(ModEnchantments.ETERNAL.get());
                if (eternalLevel <= 0) continue;
                if (invStack.getEnchantmentLevel(net.minecraft.world.item.enchantment.Enchantments.MENDING) <= 0) continue;

                int remaining = EternalEnchantment.getRemainingUses(invStack);
                int maxUses = EternalEnchantment.getMaxUses(eternalLevel);
                if (remaining >= maxUses) continue;
                if (player.experienceLevel <= 0) continue;

                player.giveExperienceLevels(-1);
                var tag = invStack.getOrCreateTag();
                tag.putInt(EternalEnchantment.ETERNAL_USES_TAG, remaining + 1);
                invStack.setTag(tag);

                ETERNAL_MENDING_COOLDOWN.put(player.getUUID(), gameTime);
                break;
            }
        }
        }

        // Frost advancement: check if any frozen entity has been cold for 200+ ticks
        long now = player.level().getGameTime();
        var playerUuid = player.getUUID();
        for (var it = COLD_APPLY_TIMES.entrySet().iterator(); it.hasNext();) {
            var entry = it.next();
            UUID targetId = entry.getKey();
            long applyTime = entry.getValue();
            UUID attackerId = COLD_APPLY_ATTACKER.get(targetId);
            if (attackerId == null) {
                it.remove();
                continue;
            }
            if (!attackerId.equals(playerUuid)) continue;
            if (now - applyTime < 200) continue;
            Entity e = ((ServerLevel) player.level()).getEntity(targetId);
            if (e instanceof LivingEntity le && le.isAlive() && le.hasEffect(ModEffects.COLD.get())) {
                grantAdvancement((ServerPlayer) player, "frost_freezer");
            }
            it.remove();
            COLD_APPLY_ATTACKER.remove(targetId);
        }

        // Thousand Wind Force — wind wall during bow charging
        if (player.isUsingItem() && player.getUseItem().getItem() instanceof BowItem) {
            int twfLevel = player.getUseItem().getEnchantmentLevel(ModEnchantments.THOUSAND_WIND_FORCE.get());
            if (twfLevel > 0) {
                ThousandWindForceEnchantment.applyWindWall(player, twfLevel);
            }
        }
    }

    /**
     * 氧气附魔：让佩戴者在水中不再流失氧气。
     *
     * 【为什么必须挂在这个事件上】
     * 原版每 tick 的空气结算在 LivingEntity.baseTick() 里：
     * <pre>
     *   if (this.isEyeInFluid(FluidTags.WATER) && !(眼睛所在方块是气泡柱)) {
     *       if (!canBreatheUnderwater() &amp;&amp; !hasWaterBreathing() &amp;&amp; !(玩家且 invulnerable))
     *           setAirSupply(decreaseAirSupply(getAirSupply()));   // 每 tick -1
     *   }
     * </pre>
     * Forge 把这段逻辑接管到 ForgeHooks.onLivingBreathe()，并抛出 LivingBreatheEvent。
     * 也就是说「水下每 tick -1」是在这个事件里决定的，任何 tick 之后再补空气都补不回来。
     *
     * 【原来的写法为什么无效】
     * 旧代码只挂在 LivingEvent.LivingTickEvent 里 setAirSupply(air + 1)，间隔还是
     * 配置里的 oxygen_interval_ticks（默认 100 tick）：
     *   空气变化 = -1/tick（原版扣） + 1/100tick（模组补） ≈ -0.99/tick
     * 净效果依然是快速溺水，所以「水下无法恢复氧气」。
     *
     * 【现在的做法】
     * 在 LivingBreatheEvent 里直接 setConsumeAirAmount(0)，把原版那 -1 归零；
     * 真正的「缓慢回气」仍由 onLivingTick() 里按 oxygen_interval_ticks 的节奏执行。
     * 这样配置里的间隔 / 水下呼吸减间隔 / 每级收益都保持原语义。
     */
    @SubscribeEvent
    public static void onLivingBreathe(net.minecraftforge.event.entity.living.LivingBreatheEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (player.level().isClientSide) return;
        if (player.getAbilities().invulnerable) return;
        // 只有在「眼睛进水」时才是原版扣空气的场景；眼睛没进水时原版本来就会回气，不必插手。
        if (!player.isEyeInFluid(net.minecraft.tags.FluidTags.WATER)) return;

        int oxygenLevel = player.getItemBySlot(EquipmentSlot.HEAD)
            .getEnchantmentLevel(ModEnchantments.OXYGEN.get());
        if (oxygenLevel <= 0) return;

        event.setConsumeAirAmount(0);
    }
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onProjectileImpact(ProjectileImpactEvent event) {
        if (!(event.getEntity() instanceof AbstractArrow arrow)) return;
        if (arrow.level().isClientSide) return;

        CompoundTag data = arrow.getPersistentData();

        // Quantum Arrow damage reduction per pierce
        if (event.getRayTraceResult() instanceof net.minecraft.world.phys.EntityHitResult) {
            int pierceCount = data.getInt("quantum_pierce_count");
            if (arrow.getPierceLevel() > 0) {
                double originalDamage = data.getDouble("quantum_original_damage");
                if (originalDamage <= 0) originalDamage = arrow.getBaseDamage();
                double lossPerPierce = ModConfig.COMMON.quantumArrowPenetrationDamageLoss.get();
                double reduction = 1.0 - pierceCount * lossPerPierce;
                if (reduction < 0.05) reduction = 0.05;
                arrow.setBaseDamage(originalDamage * reduction);
                data.putInt("quantum_pierce_count", pierceCount + 1);
            }
        }

        // Thousand Wind Force 的旧「落地 AOE」已整块删除。
        //
        // 旧实现：只要 persistentData 里有 thousand_wind_arrow（= 任何从千风弓射出的箭，
        // 见 handleEntityJoinLevelRest 的历史注释），命中方块就无条件在 4 格半径内
        // 造成 5 点魔法伤害。它既没有蓄力判定，也和新的特殊箭演出路径重复触发。
        // 现在「打地面 → 最低级扩散 / 打怪物 → 最高级扩散」全部由
        // onWindArrowImpact → ParticleEffectManager.triggerWind 负责，
        // 而那条路径只有蓄力拉满射出的特殊箭才走得到。
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (event.getEntity().level().isClientSide) return;

        // Quantum Arrow advancement: kill 2 enemies with single arrow pierce
        if (event.getSource().getDirectEntity() instanceof AbstractArrow arrow) {
            if (arrow.getPierceLevel() > 0 && event.getSource().getEntity() instanceof ServerPlayer sp) {
                int kills = arrow.getPersistentData().getInt("quantum_kill_count") + 1;
                arrow.getPersistentData().putInt("quantum_kill_count", kills);
                if (kills >= 2) {
                    grantAdvancement(sp, "time_and_pierce");
                }
                if (kills >= 6) {
                    grantAdvancement(sp, "you_are_really_amazing");
                }
            }
        }

        // Starlight advancement: kill enemy with starlight magic
        if (event.getSource().getEntity() instanceof ServerPlayer sp) {
            if (sp.getMainHandItem().getEnchantmentLevel(ModEnchantments.STARLIGHT_FORCE.get()) > 0) {
                if (event.getSource().is(DamageTypes.MAGIC) || event.getSource().is(DamageTypes.INDIRECT_MAGIC)) {
                    grantAdvancement(sp, "brilliant_starlight");
                    int stKills = sp.getPersistentData().getInt("starlight_kills") + 1;
                    sp.getPersistentData().putInt("starlight_kills", stKills);
                    if (stKills >= 500) grantAdvancement(sp, "starlight_500");
                    if (stKills >= 1500) grantAdvancement(sp, "starlight_1500");
                    if (stKills >= 10000) grantAdvancement(sp, "starlight_10000");
                }
            }
        }

        // Advancement tracking: Night Walker / Eternal Flame / Ruin Force kill counts
        if (event.getSource().getEntity() instanceof ServerPlayer sp) {
            LivingEntity dead = event.getEntity();
            ItemStack weapon = sp.getMainHandItem();
            boolean isMonster = dead.getType().getCategory() == MobCategory.MONSTER;

            if (isMonster && weapon.getEnchantmentLevel(ModEnchantments.NIGHT_WALKER.get()) > 0 && sp.level().isNight()) {
                int nwKills = sp.getPersistentData().getInt("nw_kills") + 1;
                sp.getPersistentData().putInt("nw_kills", nwKills);
                if (nwKills >= 10) grantAdvancement(sp, "night_walker_executioner");
                if (nwKills >= 50) grantAdvancement(sp, "close_eyes_when_night_falls");
                if (nwKills >= 100) grantAdvancement(sp, "tonight_look_at_the_moon");
            }
            if (isMonster && weapon.getEnchantmentLevel(ModEnchantments.ETERNAL_FLAME.get()) > 0) {
                int efKills = sp.getPersistentData().getInt("ef_kills") + 1;
                sp.getPersistentData().putInt("ef_kills", efKills);
                if (efKills >= 335) grantAdvancement(sp, "i_will_bear_it");
            }
            if (isMonster && weapon.getEnchantmentLevel(ModEnchantments.RUIN_FORCE.get()) > 0) {
                int rfKills = sp.getPersistentData().getInt("rf_kills") + 1;
                sp.getPersistentData().putInt("rf_kills", rfKills);
                if (rfKills >= 1500) grantAdvancement(sp, "this_world_is_never_beautiful");
                if (rfKills >= 1000) grantAdvancement(sp, "why_me");
                if (rfKills >= 880) grantAdvancement(sp, "last_lesson");
                if (rfKills >= 600) grantAdvancement(sp, "strongest_valkyrie");
                if (rfKills >= 300) grantAdvancement(sp, "welcome_to_ruin_academy");
            }
            if (isMonster && weapon.getEnchantmentLevel(ModEnchantments.BREAK.get()) > 0) {
                int bkKills = sp.getPersistentData().getInt("bk_kills") + 1;
                sp.getPersistentData().putInt("bk_kills", bkKills);
                if (bkKills >= 100) grantAdvancement(sp, "break_100");
                if (bkKills >= 500) grantAdvancement(sp, "break_500");
                if (bkKills >= 1000) grantAdvancement(sp, "break_1000");
                if (bkKills >= 5000) grantAdvancement(sp, "break_5000");
            }
            if (isMonster && weapon.getEnchantmentLevel(ModEnchantments.THOUSAND_WIND_FORCE.get()) > 0) {
                int twfKills = sp.getPersistentData().getInt("twf_kills") + 1;
                sp.getPersistentData().putInt("twf_kills", twfKills);
                if (twfKills >= 1) grantAdvancement(sp, "wind_force_1");
                if (twfKills >= 100) grantAdvancement(sp, "wind_force_100");
                if (twfKills >= 500) grantAdvancement(sp, "wind_force_500");
                if (twfKills >= 1500) grantAdvancement(sp, "wind_force_1500");
                if (twfKills >= 10000) grantAdvancement(sp, "wind_force_10000");
            }
        }

        // #24: Star Sea Duel — kill skeleton from 150m+ with projectile
        if (event.getSource().getDirectEntity() instanceof net.minecraft.world.entity.projectile.Projectile
            && event.getSource().getEntity() instanceof ServerPlayer sp2
            && event.getEntity() instanceof Skeleton) {
            Vec3 playerPos = sp2.position();
            Vec3 skeletonPos = event.getEntity().position();
            double horizontalDist = Math.sqrt(
                Math.pow(playerPos.x - skeletonPos.x, 2) + Math.pow(playerPos.z - skeletonPos.z, 2)
            );
            if (horizontalDist >= 150.0) {
                grantAdvancement(sp2, "star_sea_duel");
            }
        }

        Entity source = event.getSource().getEntity();
        if (!(source instanceof net.minecraft.world.entity.player.Player player)) return;
        if (player.level().isClientSide) return;

        LivingEntity dead = event.getEntity();

        // 罪孽值：玩家对友善生物行恶就累积（维基：「对友善生物行恶会增加罪孽值」）。
        // 这里刻意不加「手上有判决附魔」的前置条件——罪孽是玩家自身的行为记录，
        // 与当时手上拿什么无关；之前那个前置条件让空手杀村民不长罪孽。
        boolean friendlyCreature = dead.getType().getCategory() == net.minecraft.world.entity.MobCategory.CREATURE;
        if (friendlyCreature || dead instanceof AbstractVillager) {
            JudgmentEnchantment.recordSin(player.getUUID());
        }

        // 判决专属计数与成就：击杀村民 / 灾厄村民（需要有判决附魔，因为它统计的是判决的击杀）
        if (player.getMainHandItem().getEnchantmentLevel(ModEnchantments.JUDGMENT.get()) <= 0) return;

        if (dead instanceof AbstractVillager || dead instanceof AbstractIllager) {
            UUID uuid = player.getUUID();
            int kills = JudgmentEnchantment.JUDGMENT_KILLS.getOrDefault(uuid, 0) + 1;
            JudgmentEnchantment.JUDGMENT_KILLS.put(uuid, kills);

            // Persistent tracking and advancement grants for judgment villager/illager kills
            ServerPlayer jp = (ServerPlayer) player;
            int jvKills = jp.getPersistentData().getInt("judgment_villager_kills") + 1;
            jp.getPersistentData().putInt("judgment_villager_kills", jvKills);
            if (jvKills >= 10) grantAdvancement(jp, "judgment_10");
            if (jvKills >= 50) grantAdvancement(jp, "judgment_50");
            if (jvKills >= 150) grantAdvancement(jp, "judgment_150");
            if (jvKills >= 500) grantAdvancement(jp, "judgment_500");
            if (jvKills >= 1000) grantAdvancement(jp, "judgment_1000");
            if (jvKills >= 1200) {
                grantAdvancement(jp, "judgment_1200");
            }
            if (jvKills >= 5000) {
                grantAdvancement(jp, "judgment_1200_challenge");
            }
        }
    }

    private static int getSinLevel(LivingEntity entity) {
        CompoundTag data = entity.getPersistentData();
        if (data.contains(SIN_LEVEL_KEY)) {
            return data.getInt(SIN_LEVEL_KEY);
        }
        return 0;
    }

    private static void handleSinDamage(LivingHurtEvent event) {
        LivingEntity victim = event.getEntity();
        DamageSource source = event.getSource();
        Entity directSource = source.getEntity();

        // Case 1: Player attacks a sinful mob
        if (directSource instanceof net.minecraft.world.entity.player.Player player) {
            int sinLevel = getSinLevel(victim);
            if (sinLevel > 0 && !player.level().isClientSide) {
                int judgmentLevel = player.getMainHandItem().getEnchantmentLevel(ModEnchantments.JUDGMENT.get());
                double multiplier = getSinPlayerDamageMultiplier(judgmentLevel, sinLevel);
                event.setAmount((float) (event.getAmount() * multiplier));
            }
        }

        // Case 2: Sinful mob attacks a player (or any entity) —— 敌方加成
        if (source.getEntity() instanceof LivingEntity attacker) {
            int attackerSinLevel = getSinLevel(attacker);
            if (attackerSinLevel > 0) {
                int idx = Math.min(attackerSinLevel - 1, SIN_LEVEL_DATA.length - 1);
                double dmgBonus = SIN_LEVEL_DATA[idx].enemyDmgBonus;
                if (dmgBonus > 0) {
                    event.setAmount((float) (event.getAmount() * (1.0 + dmgBonus)));
                }
            }
        }

        // ⚠ 罪孽等级的「防御力」不在这里直接扣伤害。
        //
        // 维护者给出的完整机制（2026-10-10 二次更正）：
        //   1) 结界顺序：先算防御力 → 再算护甲值 → 最后算减伤；
        //   2) 「护甲值」= 原版 ARMOR 属性，每点 0.001 减伤；
        //      「盔甲值」= 原版 ARMOR_TOUGHNESS（盔甲韧性），同样每点 0.001 减伤；
        //   3) 维基表格的防御力百分比，加在**怪物原版盔甲值**上：
        //        最终盔甲值 = 原版盔甲值 x (1 + 百分比)
        //      因此原版盔甲值为 0 的怪物仍然是 0 —— 对应「自身没有护甲值则不生效」；
        //   4) 这套减免只作用于**物理伤害**，魔法伤害不吃。
        //
        // 因为要求「自定义减伤先于原版护甲」，所以放在 applySinPhysicalDamageReduction() 里，
        // 由 onLivingHurt 在其它结算之前调用（LivingHurtEvent 仍然早于原版护甲结算）。
    }

    /**
     * 罪孽 / 判定的「自定义护甲减伤」。
     *
     * 公式（维护者给定）：
     * <pre>
     *   罪孽倍率   = 1 + 该等级的防御力百分比          （例：25% → 1.25）
     *   最终盔甲值 = 原版盔甲值(ARMOR) x 罪孽倍率      （原版为 0 则仍为 0，即不生效）
     *   总点数     = 最终盔甲值 + 盔甲韧性(ARMOR_TOUGHNESS)
     *   减伤       = 总点数 x 0.001                    （每点 0.1%）
     *   伤害      *= (1 - 减伤)
     * </pre>
     * 校验：总点数 1.5 → 10 点伤害变成 10 x (1 - 0.0015) = 9.985，与维护者给的例子一致。
     *
     * 只对物理伤害生效：魔法（MAGIC / INDIRECT_MAGIC）、火焰、虚空、以及出界伤害都不减免。
     */
    private static void applySinPhysicalDamageReduction(LivingHurtEvent event) {
        if (isExcludedDamageType(event.getSource())) return;

        LivingEntity victim = event.getEntity();
        int sinLevel = getSinLevel(victim);
        if (sinLevel <= 0) return;

        // 1) 先算防御力：原版盔甲值 x (1 + 百分比)
        double baseArmor = victim.getAttributeValue(Attributes.ARMOR);
        if (baseArmor <= 0.0) return;                    // 自身无护甲 → 不生效

        int idx = Math.min(sinLevel - 1, SIN_LEVEL_DATA.length - 1);
        double sinArmorMultiplier = 1.0 + SIN_LEVEL_DATA[idx].defenseBonus;
        double sinArmorValue = baseArmor * sinArmorMultiplier;

        // 2) 再算护甲值：叠加盔甲韧性
        double toughness = victim.getAttributeValue(Attributes.ARMOR_TOUGHNESS);
        double totalPoints = sinArmorValue + toughness;

        // 3) 最后算减伤：每点 0.001
        double reduction = totalPoints * SIN_ARMOR_REDUCTION_PER_POINT;
        if (reduction <= 0.0) return;
        if (reduction > SIN_ARMOR_MAX_REDUCTION) reduction = SIN_ARMOR_MAX_REDUCTION;

        event.setAmount((float) (event.getAmount() * (1.0 - reduction)));
    }

    @SubscribeEvent
    public static void onLivingDrops(LivingDropsEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide) return;

        int sinLevel = getSinLevel(entity);
        if (sinLevel <= 0) return;
        if (!event.isRecentlyHit()) return;

        double weight = getSinDropWeight(sinLevel);

        if (entity.getRandom().nextDouble() >= weight) return;

        List<? extends String> whitelist = ModConfig.COMMON.sinDropWhitelist.get();
        List<? extends String> blacklist = ModConfig.COMMON.sinDropBlacklist.get();
        if (whitelist.isEmpty()) return;

        // Filter out blacklisted items from whitelist
        java.util.List<String> available = new java.util.ArrayList<>();
        for (String id : whitelist) {
            if (!blacklist.contains(id)) available.add(id);
        }
        if (available.isEmpty()) return;

        String chosenItemId = available.get(entity.getRandom().nextInt(available.size()));
        Item item = BuiltInRegistries.ITEM.get(new ResourceLocation(chosenItemId));
        if (item == null || item == Items.AIR) return;

        ItemStack bonusDrop = new ItemStack(item);
        event.getDrops().add(new ItemEntity(
            entity.level(), entity.getX(), entity.getY(), entity.getZ(), bonusDrop));
    }

    private static void handleRainbowArmor(LivingHurtEvent event) {
        LivingEntity victim = event.getEntity();

        // ⚠ 免疫判定必须放在**最前面**，尤其是要排在「反弹伤害」之前。
        //
        // 【放错位置会无限递归 → StackOverflowError】
        // 这个方法最后会把伤害反弹给攻击者：
        //     attacker.hurt(attacker.damageSources().magic(), ...);
        // 而这次反弹同样会抛出 LivingHurtEvent、再次进入本方法。
        // 原先的写法是先算完减伤、走到末尾才碰 isExcludedDamageType，
        // 于是两个都穿彩虹甲的人互相攻击时会这样滚下去：
        //     A 被 B 打 → A 反弹 MAGIC 给 B → B 的减伤算完 → B 反弹给 A → A 再反弹给 B → …
        // 每层都要算 countDyes + 建 HashSet，很快就 StackOverflowError。
        //
        // 而 isExcludedDamageType 本来就把 MAGIC / INDIRECT_MAGIC 列为「不吃彩虹减伤」，
        // 反弹用的正是 magic —— 也就是说：**只要把判定提前，反弹伤害进来就会立刻返回，
        // 链自然断掉**。这正是原版作者写那个排除项的本意，只是位置放错了。
        if (isExcludedDamageType(event.getSource())) return;

        int totalUnique = 0;
        int totalDuplicate = 0;
        int maxLevel = 0;

        for (EquipmentSlot slot : EquipmentSlot.values()) {
            if (slot.getType() != EquipmentSlot.Type.ARMOR) continue;
            ItemStack armor = victim.getItemBySlot(slot);
            int level = armor.getEnchantmentLevel(ModEnchantments.RAINBOW.get());
            if (level <= 0) continue;

            maxLevel = Math.max(maxLevel, level);
            int[] counts = countDyes(armor);
            totalUnique += counts[0];
            totalDuplicate += counts[1];
        }

        if (maxLevel <= 0) return;

        // ── 减伤加成: from rainbow dyes ──
        double reductionBonus = totalUnique * ModConfig.COMMON.rainbowArmorReductionPerColor.get() * maxLevel;

        // 装备双抗: armor + toughness, each point = 0.1%
        double totalArmor = victim.getAttributeValue(Attributes.ARMOR);
        double totalToughness = victim.getAttributeValue(Attributes.ARMOR_TOUGHNESS);
        double dualResistance = totalArmor + totalToughness;
        double dualResistanceReduction = dualResistance * ModConfig.COMMON.rainbowArmorToughnessFactor.get();

        // 最终减伤率 = 减伤加成 + 装备双抗
        double finalReductionRate = reductionBonus + dualResistanceReduction;

        // 实际减免 = min(最终减伤率 × 乘数, 最大减免上限)
        double maxReduction = ModConfig.COMMON.rainbowArmorMaxReduction.get();
        double reductionAmount = Math.min(finalReductionRate * ModConfig.COMMON.rainbowReductionMultiplier.get(), maxReduction);

        // Boss: formula effectiveness reduced by bossReductionFactor
        if (isBossEntity(event.getSource().getEntity())) {
            double bossFactor = ModConfig.COMMON.rainbowArmorBossReductionFactor.get();
            reductionAmount *= (1.0 - bossFactor);
        }

        float originalAmount = event.getAmount();
        float newAmount = originalAmount * (float) (1.0 - reductionAmount);
        event.setAmount(newAmount);

        // Reflect damage (unchanged - only triggered by duplicate dyes)
        if (totalDuplicate > 0 && event.getSource().getDirectEntity() instanceof LivingEntity attacker) {
            long now = victim.level().getGameTime();
            int maxCooldown = ModConfig.COMMON.rainbowArmorReflectCooldownMaxTicks.get();
            int minCooldown = ModConfig.COMMON.rainbowArmorReflectCooldownMinTicks.get();
            int cooldownTicks = maxCooldown - (maxLevel - 1) * (maxCooldown - minCooldown) / 4;

            Long lastReflect = RAINBOW_REFLECT_COOLDOWN.get(victim.getUUID());
            if (lastReflect != null && (now - lastReflect) < cooldownTicks) return;

            RAINBOW_REFLECT_COOLDOWN.put(victim.getUUID(), now);

            float reflectMultiplier = ModConfig.COMMON.rainbowArmorReflectMultiplier.get().floatValue();
            int basePerDup = ModConfig.COMMON.rainbowArmorExtraDamageOnDuplicate.get() * maxLevel;
            float damagePerDup = basePerDup * reflectMultiplier;
            attacker.hurt(attacker.damageSources().magic(), totalDuplicate * damagePerDup);
        }
    }

    /**
     * 过期条目清理：把「冷却类」静态 Map 里已经不可能再被用到的键摘掉。
     *
     * <h2>为什么必须做</h2>
     * 这些表都以实体 UUID 为键、在「被打 / 打人」时写入，但**从来没清理过**。
     * 最典型的是 {@link #RAINBOW_REFLECT_COOLDOWN}：
     * <pre>
     *     RAINBOW_REFLECT_COOLDOWN.put(victim.getUUID(), now);
     * </pre>
     * 每次一个怪打到穿彩虹甲（带重复染料）的玩家，那个怪的 UUID 就永久留在表里。
     * 玩家打得越多、表越大，**一个条目都不会释放** —— 这就是「打到怪会触发」的那类无界增长。
     *
     * <h2>为什么是安全的</h2>
     * 判断「过期」用的 TTL 一律取该功能**自己的冷却上限**：
     * 过了这个时间，原逻辑本来就只会走「冷却已过」分支、把值覆盖掉，
     * 因此摘掉它与保留它在语义上完全等价，不会改变任何行为。
     *
     * <p>由 {@code onLevelTick} 每 600 tick（30 秒）调用一次，走的是 entrySet 的 remove，
     * 没有并发问题（服务端 tick 线程单线程执行）。
     */
    private static void pruneStaleCooldowns(long now) {
        // 彩虹护甲反弹：TTL 取配置里的最大冷却
        long reflectTtl = Math.max(1, ModConfig.COMMON.rainbowArmorReflectCooldownMaxTicks.get());
        RAINBOW_REFLECT_COOLDOWN.entrySet().removeIf(e -> now - e.getValue() > reflectTtl);

        // 冥界花：值本身就是到期时刻，过了就该摘
        UndyingGuard.prune(now);

        // 星光之力：TTL 取一个明确宽裕的值（该附魔冷却实际由攻击速度决定，最短 5 tick，
        // 这里给 20 秒；过了这么久还没被再触发，说明那条记录已经没有意义了）
        StarlightForceEnchantment.pruneCooldowns(now, 400L);

        // 冰霜附加：这两个表是一对，过期的一起摘，避免只清一半导致 ATTACKER 表泄漏
        long coldTtl = Math.max(200, ModConfig.COMMON.frostEffectDuration.get().longValue() + 200L);
        COLD_APPLY_TIMES.entrySet().removeIf(e -> now - e.getValue() > coldTtl);
        COLD_APPLY_ATTACKER.keySet().removeIf(k -> {
            Long t = COLD_APPLY_TIMES.get(k);
            return t == null;   // TIMES 里没了，ATTACKER 就是孤儿
        });
    }

    private static boolean isExcludedDamageType(DamageSource source) {
        // Mod's own custom damage types are always reducible
        if (source.is(ModDamageTypes.OVERLOAD_DAMAGE) || source.is(ModDamageTypes.RUIN_FORCE)) {
            return false;
        }
        // Exclude magic, fire, void
        return source.is(DamageTypes.MAGIC) || source.is(DamageTypes.INDIRECT_MAGIC)
            || source.is(DamageTypeTags.IS_FIRE)
            || source.is(DamageTypes.FELL_OUT_OF_WORLD);
    }

    private static boolean isBossEntity(Entity entity) {
        if (entity == null) return false;
        EntityType<?> type = entity.getType();
        return type == EntityType.ENDER_DRAGON || type == EntityType.WITHER
            || type == EntityType.ELDER_GUARDIAN || type == EntityType.WARDEN;
    }

    private static void handleDeepSeaFireBoost(LivingHurtEvent event) {
        LivingEntity entity = event.getEntity();
        if (!entity.hasEffect(ModEffects.DEEP_SEA.get())) return;
        if (entity.isInWaterOrRain()) return;

        if (event.getSource().is(DamageTypes.ON_FIRE) || event.getSource().is(DamageTypes.IN_FIRE)
            || event.getSource().is(DamageTypes.LAVA) || event.getSource().is(DamageTypes.FIREBALL)
            || event.getSource().is(DamageTypes.UNATTRIBUTED_FIREBALL)) {
            float mult = ModConfig.COMMON.oceanLandDamageMultiplier.get().floatValue();
            event.setAmount(event.getAmount() * mult);
        }
    }

    private static void handleForestStrike(LivingHurtEvent event) {
        if (event.getSource().is(DamageTypes.FELL_OUT_OF_WORLD)) return;

        LivingEntity victim = event.getEntity();
        int maxLevel = 0;
        int piecesCount = 0;
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            if (slot.getType() != EquipmentSlot.Type.ARMOR) continue;
            int level = victim.getItemBySlot(slot).getEnchantmentLevel(ModEnchantments.FOREST_STRIKE.get());
            if (level <= 0) continue;
            piecesCount++;
            if (level > maxLevel) maxLevel = level;
        }
        if (maxLevel <= 0) return;

        int divisor = ModConfig.COMMON.forestArmorPieceDivisor.get();
        float fraction = piecesCount / (float) divisor;
        float healPercent = (float) (ModConfig.COMMON.forestHealPercentPerLevel.get() * maxLevel);
        float healAmount = event.getAmount() * healPercent * fraction;
        victim.heal(healAmount);

        if (victim instanceof ServerPlayer sp) {
            // Don't count healing if the totem of undying would save the player instead
            float healthAfter = victim.getHealth() + healAmount - event.getAmount();
            boolean wouldDie = healthAfter <= 0.0f;
            boolean hasTotem = victim.getMainHandItem().is(Items.TOTEM_OF_UNDYING)
                || victim.getOffhandItem().is(Items.TOTEM_OF_UNDYING);
            if (wouldDie && hasTotem) return;

            double totalHealed = sp.getPersistentData().getDouble("forest_healed") + healAmount;
            sp.getPersistentData().putDouble("forest_healed", totalHealed);
            if (totalHealed >= 600.0) {
                grantAdvancement(sp, "forest_600");
            }
        }
    }

    private static void handleJudgmentDamage(LivingHurtEvent event) {
        if (!(event.getSource().getEntity() instanceof LivingEntity attacker)) return;
        if (attacker.level().isClientSide) return;

        ItemStack weapon = attacker.getMainHandItem();
        int judgmentLevel = weapon.getEnchantmentLevel(ModEnchantments.JUDGMENT.get());
        if (judgmentLevel <= 0) return;

        Entity target = event.getEntity();
        MobType mobType;
        if (target instanceof LivingEntity le) {
            mobType = le.getMobType();
        } else {
            return;
        }

        // 判决只负责「按敌人类型」的加成与「每 10 击杀」的基础伤害加成。
        //
        // 【罪孽相关的那段为什么删掉了】
        // 这里原来也算了一遍罪孽倍率：
        //     sinMultiplier = JudgmentEnchantment.getSinMultiplier(uuid);   // 1 + 罪孽值(≤2.2%)
        //     levelAdjust   = 1.0 + (judgmentLevel - maxLevel) * 0.05;      // 满级时 =1.0
        //     totalMultiplier = mobMultiplier * sinMultiplier;
        // 但 onLivingHurt 里 handleSinDamage() 已经先按维基表格算过一次罪孽倍率
        // （判决高 1 级 +5%、低 1 级 -5%、同级正常 + 罪孽等级的防御加成）。
        // 两处叠乘属于重复计算，而且 maxLevel 作为基准点与维基的「判决等级 vs 罪孽等级」不符。
        // 现在统一由 handleSinDamage() 独占罪孽机制，这里只保留类型加成与击杀加成。
        float mobMultiplier = JudgmentEnchantment.getDamageMultiplier(mobType);
        event.setAmount(event.getAmount() * mobMultiplier);

        int killBonus = JudgmentEnchantment.getKillDamageBonus(attacker.getUUID());
        if (killBonus > 0) {
            event.setAmount(event.getAmount() + killBonus);
        }
    }

    public static int[] countDyes(ItemStack stack) {
        Set<String> uniqueColors = new HashSet<>();
        int totalEntries = 0;

        CompoundTag tag = stack.getTag();
        if (tag != null && tag.contains(RAINBOW_DYES_TAG, 9)) {
            ListTag list = tag.getList(RAINBOW_DYES_TAG, 8);
            totalEntries = list.size();
            for (int i = 0; i < list.size(); i++) {
                uniqueColors.add(list.getString(i));
            }
        }

        int unique = uniqueColors.size();
        int duplicate = totalEntries - unique;
        return new int[]{unique, duplicate};
    }

    private static boolean hasAllDyes(ItemStack stack) {
        if (stack.getEnchantmentLevel(ModEnchantments.RAINBOW.get()) <= 0) return false;
        CompoundTag tag = stack.getTag();
        if (tag == null || !tag.contains("rainbow_dyes", 9)) return false;
        ListTag list = tag.getList("rainbow_dyes", 8);
        Set<String> applied = new HashSet<>();
        for (int i = 0; i < list.size(); i++) {
            applied.add(list.getString(i));
        }
        for (DyeColor dc : DyeColor.values()) {
            if (!applied.contains(dc.getName())) return false;
        }
        return true;
    }

    @SubscribeEvent
    public static void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;

        // Apply Cherry Blossom armor HP bonus on login
        handleCherryBlossomArmor(player);

        String key = "rainbow_root_granted";
        if (!player.getPersistentData().getBoolean(key)) {
            grantAdvancement(player, "root");
            player.getPersistentData().putBoolean(key, true);
        }

        // cute_girl_heart: check if player already wears full Immaculate set
        if (!player.getPersistentData().getBoolean("cute_girl_heart_granted")) {
            boolean hasFullSet = true;
            for (EquipmentSlot slot : EquipmentSlot.values()) {
                if (slot.getType() != EquipmentSlot.Type.ARMOR) continue;
                if (player.getItemBySlot(slot).getEnchantmentLevel(ModEnchantments.IMMACULATE.get()) <= 0) {
                    hasFullSet = false;
                    break;
                }
            }
            if (hasFullSet) {
                grantAdvancement(player, "cute_girl_heart");
                player.getPersistentData().putBoolean("cute_girl_heart_granted", true);
            }
        }

        // Eternal enchantment check
        if (!player.getPersistentData().getBoolean("eternal_any_granted")) {
            boolean hasEternal = false;
            int maxLevel = 0;
            for (ItemStack stack : player.getInventory().items) {
                if (stack.isEmpty()) continue;
                int level = stack.getEnchantmentLevel(ModEnchantments.ETERNAL.get());
                if (level > 0) {
                    hasEternal = true;
                    maxLevel = Math.max(maxLevel, level);
                }
            }
            for (EquipmentSlot slot : EquipmentSlot.values()) {
                ItemStack stack = player.getItemBySlot(slot);
                if (stack.isEmpty()) continue;
                int level = stack.getEnchantmentLevel(ModEnchantments.ETERNAL.get());
                if (level > 0) {
                    hasEternal = true;
                    maxLevel = Math.max(maxLevel, level);
                }
            }
            if (hasEternal) {
                player.getPersistentData().putBoolean("eternal_any_granted", true);
                grantAdvancement(player, "eternal_any");
                if (maxLevel >= ModConfig.COMMON.eternalMaxLevel.get()) {
                    grantAdvancement(player, "eternal_max");
                }
            }
        }
    }

    private static void handleSpaceSlash(LivingHurtEvent event) {
        if (!(event.getSource().getEntity() instanceof ServerPlayer player)) return;
        if (PROCESSING_SPACE_SLASH.get()) return;
        ItemStack weapon = player.getMainHandItem();
        int ssLevel = weapon.getEnchantmentLevel(ModEnchantments.SPACE_SLASH.get());
        if (ssLevel <= 0) return;

        long now = player.level().getGameTime();
        Long lastSlash = SPACE_SLASH_COOLDOWN.get(player.getUUID());
        var c = ModConfig.COMMON;
        int cooldownTicks = c.spaceSlashCooldownLevel1.get()
            - (ssLevel - 1) * (c.spaceSlashCooldownLevel1.get() - c.spaceSlashCooldownMaxLevel.get()) / 4;
        if (lastSlash != null && (now - lastSlash) < cooldownTicks) return;

        // ── 空间斩：三段连斩 ────────────────────────────────────────────────────
        //
        // 维护者口径：
        //   ·「空间斩的伤害是每一段递减的，不过这个递减是动态的」→ 第 n 段 = 玩家那一刀 × 0.85^n
        //     （第1段 85%、第2段 72.25%、第3段 61.41%），而不是三段都打 85%。
        //   ·「空间斩吃的跳劈伤害是三段都可以吃暴击伤害，
        //      但不跳劈或是暴击他是不会使用暴击伤害的数值的」→ 跳劈时三段都吃暴击倍率，
        //      没跳劈就三段都不吃。暴击倍率来自 CriticalHitEvent（见 onCriticalHit）。
        float baseDamage = event.getAmount();
        float critMultiplier = CRIT_DAMAGE.getOrDefault(player.getUUID(), 1.0f);
        // 消费掉，避免残留到下一次攻击
        CRIT_DAMAGE.remove(player.getUUID());

        // 连斩递减参数来自配置（space_slash_enchantment 分组）
        float slashDamage = (float) (baseDamage * segmentDecayFactor(1));   // 第 1 段
        if (critMultiplier > 1.0f) {
            slashDamage *= critMultiplier;
        }

        // Slash 1: apply immediately
        event.setAmount(slashDamage);
        // 攻击冷却归零交给原版。
        //
        // 【为什么这里不能自己调 resetAttackStrengthTicker()】
        // 本方法由 LivingHurtEvent 触发，也就是运行在 Player.attack() 内部；
        // 而原版在同一次 attack() 的结尾还会再调一次 resetAttackStrengthTicker()
        // （Player.java 里那行带 "FORGE: Moved from beginning of attack()" 注释的调用），
        // 所以在这里再调一遍是 no-op，没有意义。
        // 原版战斗更新本来就会在每次挥击后把 attackStrengthTicker 归零，
        // 「攻击冷却归零」是原版行为，不需要附魔额外干预。
        // 原先每个 tick 消费待结算连斩时还会再归零一次，那会持续压制冷却条，已一并移除。

        // 排入待结算的第 2/3 段：递减与暴击倍率都记进去，保证三段口径一致
        Entity target = event.getEntity();
        PENDING_SPACE_SLASHES.put(player.getUUID(),
            new int[]{2, target.getId(), Float.floatToIntBits(baseDamage), Float.floatToIntBits(critMultiplier)});
        SPACE_SLASH_COOLDOWN.put(player.getUUID(), now);
    }

    /**
     * 空间斩第 n 段的伤害系数：`(1 - 线性递减) × 指数递减^(n-1)`。
     *
     * 第 1 段 n=1 → (1-0.15) = 0.85；第 2 段 → 0.85² = 0.7225；第 3 段 → 0.85³ ≈ 0.6141。
     * 两个参数都可在配置里调（space_slash_enchantment 分组）。
     */
    private static double segmentDecayFactor(int segment) {
        var c = ModConfig.COMMON;
        return (1.0 - c.spaceSlashSegmentDecayLinear.get())
            * Math.pow(c.spaceSlashSegmentDecayExponential.get(), segment - 1);
    }

    private static void handleCherryBlossomHurt(LivingHurtEvent event) {
        if (!(event.getSource().getEntity() instanceof Player player)) return;
        if (player.level().isClientSide) return;
        ItemStack weapon = player.getMainHandItem();
        int cbLevel = weapon.getEnchantmentLevel(ModEnchantments.CHERRY_BLOSSOM.get());
        if (cbLevel <= 0) return;

        var tag = weapon.getTag();
        if (tag == null) return;
        int count = tag.getInt(CherryBlossomEnchantment.CHERRY_BLOSSOM_COUNT_TAG);
        if (count <= 0) return;

        event.setAmount(event.getAmount() + count);
    }

    private static void handlePlunderDamage(LivingHurtEvent event) {
        if (!(event.getSource().getEntity() instanceof net.minecraft.world.entity.player.Player player)) return;
        ItemStack weapon = player.getMainHandItem();
        if (weapon.getEnchantmentLevel(ModEnchantments.PLUNDER.get()) <= 0) return;
        event.setAmount(1.0f);
    }

    private static void handlePervertSteal(LivingHurtEvent event) {
        if (!(event.getSource().getEntity() instanceof Player player)) return;
        ItemStack weapon = player.getMainHandItem();
        int level = weapon.getEnchantmentLevel(ModEnchantments.PERVERT.get());
        if (level <= 0) return;

        LivingEntity target = event.getEntity();
        List<EquipmentSlot> slots = new java.util.ArrayList<>();
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            if (slot.getType() == EquipmentSlot.Type.HAND || slot.getType() == EquipmentSlot.Type.ARMOR) {
                if (!target.getItemBySlot(slot).isEmpty()) {
                    slots.add(slot);
                }
            }
        }
        if (slots.isEmpty()) return;

        double chance = ModConfig.COMMON.pervertLevel1Chance.get()
            + (level - 1) * (ModConfig.COMMON.pervertMaxChance.get() - ModConfig.COMMON.pervertLevel1Chance.get()) / 4.0;
        if (player.getRandom().nextDouble() >= chance) return;

        EquipmentSlot picked = slots.get(player.getRandom().nextInt(slots.size()));
        ItemStack stolen = target.getItemBySlot(picked).copy();
        target.setItemSlot(picked, ItemStack.EMPTY);

        if (!target.level().isClientSide) {
            target.level().addFreshEntity(new ItemEntity(
                target.level(), target.getX(), target.getY() + 0.5, target.getZ(), stolen));
        }
    }

    private static void handleEternalLoyaltyDamage(LivingHurtEvent event) {
        if (!(event.getSource().getEntity() instanceof net.minecraft.world.entity.player.Player player)) return;
        ItemStack weapon = player.getMainHandItem();
        if (!(weapon.getItem() instanceof net.minecraft.world.item.TridentItem)) return;
        int elLevel = weapon.getEnchantmentLevel(ModEnchantments.ETERNAL_LOYALTY.get());
        if (elLevel <= 0) return;

        var enchants = net.minecraft.world.item.enchantment.EnchantmentHelper.getEnchantments(weapon);
        int totalLevels = 0;
        for (int lvl : enchants.values()) {
            totalLevels += lvl;
        }

        float multiplier = (float) ((1.0 + 0.05 * totalLevels) * Math.pow(1.2, elLevel));
        event.setAmount(event.getAmount() * multiplier);
    }

    private static void handleUndyingProtection(LivingHurtEvent event) {
        if (!(event.getEntity() instanceof net.minecraft.world.entity.player.Player player)) return;
        if (player.level().isClientSide) return;

        // 冥界花保护：效果生效期间挡住致死伤害
        Float guarded = netherFlowerGuardedDamage(player, event.getAmount());
        if (guarded != null) {
            event.setAmount(guarded);
        }
        // 【不死附魔的实际触发不在这里】
        // 旧代码在这里判断 `player.getHealth() > 1.0f → return`，要求「挨打前已经只剩 1 滴血」
        // 才放行，于是从 2 血以上被一拳打死时永远 return —— 这就是「不死触发不了」。
        // 现在整个触发搬到 onLivingDamage(LivingDamageEvent)，原因见那边的注释。
    }

    /**
     * 不死附魔：真正的致死拦截点。
     *
     * <p><b>为什么必须挂在 {@code LivingDamageEvent} 而不是 {@code LivingHurtEvent}</b>
     * （1.20.1 反编译源码 {@code LivingEntity.java}）：
     * <pre>
     * 1708 protected void actuallyHurt(DamageSource src, float amount) {
     * 1710    amount = ForgeHooks.onLivingHurt(this, src, amount);     // ← LivingHurtEvent（护甲前）
     * 1712    amount = this.getDamageAfterArmorAbsorb(src, amount);   // 护甲
     * 1713    amount = this.getDamageAfterMagicAbsorb(src, amount);   // 附魔 / 抗性
     * 1714    ... 吸收（伤害吸收）...
     * 1725    f1 = ForgeHooks.onLivingDamage(this, src, f1);           // ← LivingDamageEvent（最终值）
     * 1726    if (f1 != 0.0F) {
     * 1728       this.setHealth(this.getHealth() - f1);
     * </pre>
     * 即 {@code LivingHurtEvent} 里的 amount 是「护甲前的上界」，只有 {@code LivingDamageEvent}
     * 拿到的才是真正会扣掉的血量；而两者都在 {@code setHealth} <b>之前</b>，
     * 所以在这里 {@code setAmount(0)} 完全来得及（{@code ForgeHooks.onLivingDamage} 返回 0，
     * 1726 行的判断不成立，1728 直接跳过）。
     *
     * <p>原来的判据 {@code if (player.getHealth() > 1.0f) return;} 写反了方向：
     * 它要求挨打前就只剩 1 滴血。对照本文件空间斩那条 {@code guardPendingSlashDamage}：
     * {@code if (player.getHealth() > 1.0f && player.getHealth() - damage <= 0.0f)} ——
     * 「血量高于 1 且这一下会致死」才是正确语义。两个条件恰好互补，
     * 所以不死与空间斩保护至多只有一条能生效，直接说明 1 血那句是残留的错误条件。
     */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onLivingDamage(LivingDamageEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer sp)) return;
        if (sp.level().isClientSide) return;
        if (event.isCanceled()) return;

        float amount = event.getAmount();                 // 护甲 / 附魔 / 吸收之后，真正会扣的血
        if (amount <= 0.0f) return;
        if (sp.getHealth() - amount > 0.0f) return;       // 打不死，不触发

        // 冥界花优先
        Float guarded = netherFlowerGuardedDamage(sp, amount);
        if (guarded != null) {
            event.setAmount(guarded);
            return;
        }

        // 冷却判定、扣级、回血、冥界花、开保护窗口，全部收归 UndyingGuard（唯一入口，幂等）。
        // 只有它真的保住了（这次扣掉一级，或已经处在保护窗口内），才把这次伤害清零 ——
        // 救不了（冷却中 / 扣不到等级）就让它照常打死，避免「没附魔也免死」。
        if (!UndyingGuard.tryGuard(sp)) return;
        event.setAmount(0.0f);
    }

    /**
     * 不死附魔的实际触发：<b>扣掉 1 级不死附魔等级</b>、回血、挂上冥界花、记冷却。
     *
     * <p>单独抽出来是因为它有两条调用路径：正常的 {@code onLivingDamage}，
     * 以及空间斩连斩绕过早退分支的那条（{@code guardPendingSlashDamage}）。
     *
     * <p>【2026-10-12 口径变更 —— 维护者选 B】语言文件的设定是
     * 「<b>濒死时</b>扣除1级不死等级…最高等级：VIII」（措辞同日由「1滴血时」订正为「濒死时」，
     * 与下面「只要这一下会致死就触发」的判据一致）。旧实现扣的却是一个存在玩家
     * {@code persistentData} 里的计数器，而且那个计数器写的是
     * <pre>
     *   int remaining = sp.getPersistentData().getInt("undying_remaining");
     *   if (remaining <= 0) remaining = maxLevel;      // ← 耗尽后自己填回
     * </pre>
     * 也就是 VIII 级时 8 次一循环、<b>永远用不完</b>，与描述不符。
     *
     * <p>现在改成真的把附魔等级 −1：
     * <ul>
     *   <li>取<b>等级最高</b>的那一件护甲扣（并列时按 {@link EquipmentSlot} 的枚举顺序，
     *       即 脚 → 腿 → 胸 → 头）；</li>
     *   <li>等级降到 0 时把该附魔从物品上整个移除
     *       （{@code EnchantmentHelper#setEnchantments} 在集合为空时会自动
     *       {@code removeTagKey("Enchantments")}，不会留下空的 Enchantments 列表）；</li>
     *   <li>找不到可扣的等级就<b>不触发</b>并返回 {@code false}，
     *       调用方据此<b>不能</b>把伤害清零 —— 否则会出现「没附魔也免死」。</li>
     * </ul>
     *
     * <p>推论：可触发次数 = 身上 4 件护甲的不死等级<b>之和</b>
     * （四件都 VIII 就是 32 次；只穿一件就是那件的等级次）。
     * 冷却仍由 {@code undying_cooldown_ticks}（默认 600 tick = 30 秒）控制，
     * 与描述里「提升等级不降低冷却」一致。
     *
     * @return true 表示本次真的触发（已扣掉一级），调用方应把伤害清零
     */
    private static boolean runUndyingTrigger(ServerPlayer sp) {
        // 实现已整体收归 UndyingGuard（唯一入口、幂等、带异常兜底）：
        // 冷却判定 → 扣 1 级 → 回血 → 挂冥界花 → 开保护窗口 → 清死亡痕迹。
        // 这里保留一个薄转发，是为了让「空间斩连斩」那条旁路继续用同一口径。
        return UndyingGuard.tryGuard(sp);
    }

    /**
     * 冥界花存活期间的致死伤害拦截。
     *
     * 把原逻辑从 handleUndyingProtection() 里抽出来做成纯数值函数，是为了让
     * 「空间斩连斩的第 2/3 段伤害」也能复用它——那条路径会绕过整套 onLivingHurt 逻辑
     * （见 handleSpaceSlash / onUndyingTick 里的 PROCESSING_SPACE_SLASH）。
     *
     * @return 修正后的伤害值；返回 null 表示玩家身上没有冥界花，调用方继续走原有逻辑
     */
    private static Float netherFlowerGuardedDamage(Player player, float damage) {
        // 判据已从「身上有没有冥界花效果」改成 UndyingGuard 里我们自己的保护窗口记录：
        // 效果可以被别人清掉，但改不到我们内存里那个到期时刻。
        return UndyingGuard.damageAfterGuard(player, damage);
    }

    /**
     * 空间斩待结算伤害（第 2/3 段）触发的 hurt() 会命中 onLivingHurt 的 PROCESSING_SPACE_SLASH
     * 早退分支，因此这里单独重放一次「致死保护」：
     * 先让冥界花生效，再在会致死时按不死附魔把目标压到留 1 点血。
     */
    private static float guardPendingSlashDamage(ServerPlayer player, float damage) {
        Float guarded = netherFlowerGuardedDamage(player, damage);
        if (guarded != null) return guarded;

        // 与 onLivingDamage 的判据保持一致：只要这一下会致死就触发，
        // 不再额外要求「血量必须大于 1」（那样 1 血时反而会漏掉）。
        if (player.getHealth() - damage <= 0.0f && runUndyingTrigger(player)) {
            return 0.0f;
        }
        return damage;
    }

    @SubscribeEvent
    public static void onBlockBreak(net.minecraftforge.event.level.BlockEvent.BreakEvent event) {
        if (event.isCanceled()) return;
        if (!(event.getLevel() instanceof net.minecraft.server.level.ServerLevel serverLevel)) return;
        if (!(event.getPlayer() instanceof ServerPlayer player)) return;

        ItemStack tool = player.getMainHandItem();
        var pos = event.getPos();
        var state = event.getState();

        int doubleLevel = tool.getEnchantmentLevel(ModEnchantments.DOUBLE.get());
        int harvestLevel = tool.getEnchantmentLevel(ModEnchantments.HARVEST.get());

        if (doubleLevel <= 0 && harvestLevel <= 0) return;

        // ★ 2026-10-12：双倍/丰收不应该「凭空变出」玩家本来挖不出来的方块掉落。
        //
        // BreakEvent 是在 ServerPlayerGameMode.destroyBlock 里、**掉落判定 flag1 之前**
        // 发布的（反编译 ServerPlayerGameMode.java:243 vs :263），所以这条路径天然绕过了
        // 「工具等级对不对」的检查：拿木镐挖黑曜石，方块不掉东西，双倍却会 pop 一份出来。
        // 这里补一次与原版同源的判定。Player#hasCorrectToolForDrops 会同步触发
        // PlayerEvent.HarvestCheck，所以修复后的寰宇破坏者会被正确认到 —— UB + 双倍可以正常叠加。
        // 对本来就不要求正确工具的方块（泥土、沙子等）它一律返回 true，双倍照常生效。
        if (!player.hasCorrectToolForDrops(state)) return;

        // 传入真实的 BlockEntity（原来是 null）：箱子一类需要读取方块实体才能算对掉落。
        var drops = net.minecraft.world.level.block.Block.getDrops(state, serverLevel, pos,
            serverLevel.getBlockEntity(pos), player, tool);

        if (doubleLevel > 0) {
            double chance = ModConfig.COMMON.doubleLevel1Chance.get()
                + (doubleLevel - 1) * (ModConfig.COMMON.doubleMaxChance.get() - ModConfig.COMMON.doubleLevel1Chance.get()) / 2.0;
            if (serverLevel.random.nextDouble() < chance) {
                for (var stack : drops) {
                    if (!stack.isEmpty()) {
                        net.minecraft.world.level.block.Block.popResource(serverLevel, pos, stack.copy());
                    }
                }
            }
        }

        if (harvestLevel > 0) {
            double chance = ModConfig.COMMON.harvestLevel1Chance.get()
                + (harvestLevel - 1) * (ModConfig.COMMON.harvestMaxChance.get() - ModConfig.COMMON.harvestLevel1Chance.get()) / 4.0;
            if (serverLevel.random.nextDouble() < chance) {
                for (var stack : drops) {
                    if (!stack.isEmpty()) {
                        net.minecraft.world.level.block.Block.popResource(serverLevel, pos, stack.copy());
                    }
                }
            }
        }
    }

    @SubscribeEvent
    public static void onItemFished(net.minecraftforge.event.entity.player.ItemFishedEvent event) {
        if (event.getEntity().level().isClientSide) return;
        if (!(event.getEntity() instanceof ServerPlayer player)) return;

        int luckyLevel = player.getMainHandItem().getEnchantmentLevel(ModEnchantments.SUPER_LUCKY.get());
        if (luckyLevel <= 0) {
            luckyLevel = player.getOffhandItem().getEnchantmentLevel(ModEnchantments.SUPER_LUCKY.get());
        }
        if (luckyLevel <= 0) {
            for (EquipmentSlot slot : EquipmentSlot.values()) {
                if (slot.getType() != EquipmentSlot.Type.ARMOR) continue;
                int lvl = player.getItemBySlot(slot).getEnchantmentLevel(ModEnchantments.SUPER_LUCKY.get());
                if (lvl > luckyLevel) luckyLevel = lvl;
            }
        }
        if (luckyLevel <= 0) return;

        var c = ModConfig.COMMON;
        double doubleChance = c.luckyDoubleChanceLevel1.get()
            + (luckyLevel - 1) * (c.luckyDoubleChanceMax.get() - c.luckyDoubleChanceLevel1.get()) / 4.0;

        if (player.level().random.nextDouble() < doubleChance) {
            dropExtraFishingLoot(player, event, 1.0, "super_lucky");
        }

        // ── 超级幸运：高品质物品 ────────────────────────────────────────────────
        //
        // 维护者口径：
        //   ·「开箱好东西是根据战利品来的，他只看战利品获取最低的，比如原版的附魔金苹果、
        //      钓鱼时的超级附魔书」
        //   ·「超级幸运是可以和幸运叠加在一起的，那个双倍概率是独立的概率，
        //      既吃物品稀有度，也是吃战利品列表」
        //
        // 所以这里做成**独立的一次判定**（与上面的双倍概率互不影响）：
        // 命中时，从原版钓鱼宝藏表 minecraft:gameplay/fishing/treasure 里再抽一件，
        // 额外发给玩家。该表里正是附魔书、命名牌、弓、鞍、睡莲这类「好东西」，
        // 也就是维护者说的「战利品获取最低（最稀有）」的那一档。
        //
        // 配置项 luckyGoodLootChanceLevel1（1级12%）/ luckyGoodLootChanceMax（满级20%）
        // 之前定义了但从未被读取，这里补上实现。
        double goodLootChance = c.luckyGoodLootChanceLevel1.get()
            + (luckyLevel - 1) * (c.luckyGoodLootChanceMax.get() - c.luckyGoodLootChanceLevel1.get()) / 4.0;
        if (player.level().random.nextDouble() < goodLootChance) {
            dropFishingTreasure(player, event);
        }

        // Treasure Gathering: chance to replace fish with minerals
        int tgLevel = player.getMainHandItem().getEnchantmentLevel(ModEnchantments.TREASURE_GATHERING.get());
        if (tgLevel <= 0) {
            tgLevel = player.getOffhandItem().getEnchantmentLevel(ModEnchantments.TREASURE_GATHERING.get());
        }
        if (tgLevel > 0) {
            double tgChance = c.treasureGatheringLevel1Chance.get()
                + (tgLevel - 1) * (c.treasureGatheringMaxChance.get() - c.treasureGatheringLevel1Chance.get()) / 4.0;
            if (player.level().random.nextDouble() < tgChance) {
                var minerals = c.treasureGatheringMineralList.get();
                if (!minerals.isEmpty()) {
                    String chosen = minerals.get(player.level().random.nextInt(minerals.size()));
                    Item mineralItem = BuiltInRegistries.ITEM.get(new ResourceLocation(chosen));
                    if (mineralItem != null && mineralItem != Items.AIR) {
                        // 注意：这里是「额外追加矿物」而不是「替换鱼获」。
                        // 原因同 dropExtraFishingLoot 的说明——ItemFishedEvent 无法移除原版鱼获。
                        // 要做成真正的「替换」，必须改用 Global Loot Modifier / 自定义 LootCondition
                        // 去改 minecraft:gameplay:fishing 战利品表（工作量大，本次未做）。
                        dropFishingLootStack(player, event,
                            new ItemStack(mineralItem, 1 + player.level().random.nextInt(3)));
                    }
                }
            }
        }

    }

    /**
     * 给这次钓鱼额外补发一份掉落。
     *
     * 【为什么不能直接改 event.getDrops()】
     * `ItemFishedEvent#getDrops()` 返回的是**事件自己的一份副本**，无法用来改变玩家实际拿到的鱼获。
     * 1.20.1 的 Forge 源码里写得很直白（ItemFishedEvent.java）：
     * <pre>
     *   private final NonNullList&lt;ItemStack&gt; stacks = NonNullList.create();
     *   public ItemFishedEvent(List&lt;ItemStack&gt; stacks, int rodDamage, FishingHook hook) {
     *       this.stacks.addAll(stacks);        // ← addAll：复制，不是持有引用
     *   }
     *   /** ... You cannot use this to modify the drops the player will get. ... *&#47;
     *   public NonNullList&lt;ItemStack&gt; getDrops() { return stacks; }
     * </pre>
     * 而真正发鱼的地方 FishingHook.retrieve() 里，事件 post 完之后：
     * <pre>
     *   List&lt;ItemStack&gt; list = loottable.getRandomItems(lootparams);
     *   event = new ItemFishedEvent(list, ...);
     *   MinecraftForge.EVENT_BUS.post(event);
     *   if (event.isCanceled()) { this.discard(); return event.getRodDamage(); }
     *   for (ItemStack itemstack : list) { ... addFreshEntity(new ItemEntity(...)) }   // ← 遍历的是 list，不是 event.getDrops()
     * </pre>
     * 所以往 getDrops() 里 add 只是往一个没人读的副本里塞数据：
     * 概率判定照常、没有报错、**就是不翻倍**。这就是「超级幸运无法触发双倍物资」的根因。
     *
     * 正确做法就是这里做的：读副本没问题，然后**自己补发**一份。
     *
     * @param multiplier 发几份（1.0 表示每样再补一份）
     */
    private static void dropExtraFishingLoot(ServerPlayer player, net.minecraftforge.event.entity.player.ItemFishedEvent event,
                                             double multiplier, String reason) {
        for (ItemStack stack : event.getDrops()) {
            if (stack.isEmpty()) continue;
            int copies = (int) Math.floor(multiplier);
            for (int i = 0; i < copies; i++) {
                dropFishingLootStack(player, event, stack.copy());
            }
        }
    }

    /** 在浮标位置补发一份掉落（拿不到浮标时退回玩家脚下）。 */
    private static void dropFishingLootStack(ServerPlayer player, net.minecraftforge.event.entity.player.ItemFishedEvent event,
                                             ItemStack stack) {
        if (stack.isEmpty()) return;
        var hook = event.getHookEntity();
        if (hook != null) {
            ItemEntity drop = new ItemEntity(player.level(), hook.getX(), hook.getY(), hook.getZ(), stack);
            player.level().addFreshEntity(drop);
        } else {
            player.drop(stack, false);
        }
    }

    /**
     * 超级幸运「高品质物品」：从原版钓鱼宝藏表额外抽一件发给玩家。
     *
     * 用 minecraft:gameplay/fishing/treasure —— 这正是「战利品获取最低（最稀有）」的那一档，
     * 内容为附魔书、命名牌、弓、鞍、睡莲等，对应维护者说的「钓鱼时的超级附魔书」。
     */
    private static void dropFishingTreasure(ServerPlayer player, net.minecraftforge.event.entity.player.ItemFishedEvent event) {
        if (!(player.level() instanceof ServerLevel level)) return;
        var hook = event.getHookEntity();
        double x = hook != null ? hook.getX() : player.getX();
        double y = hook != null ? hook.getY() : player.getY();
        double z = hook != null ? hook.getZ() : player.getZ();

        var lootTable = level.getServer().getLootData()
            .getLootTable(net.minecraft.world.level.storage.loot.BuiltInLootTables.FISHING_TREASURE);

        // LootParams 是一次性的（getRandomItems 会消耗它），所以这里的参数只为本表构建
        var params = new net.minecraft.world.level.storage.loot.LootParams.Builder(level)
            .withParameter(net.minecraft.world.level.storage.loot.parameters.LootContextParams.ORIGIN,
                new Vec3(x, y, z))
            .withParameter(net.minecraft.world.level.storage.loot.parameters.LootContextParams.TOOL,
                player.getMainHandItem())
            .withParameter(net.minecraft.world.level.storage.loot.parameters.LootContextParams.KILLER_ENTITY,
                player)
            .withLuck(player.getLuck())
            .create(net.minecraft.world.level.storage.loot.parameters.LootContextParamSets.FISHING);

        for (ItemStack stack : lootTable.getRandomItems(params)) {
            if (stack.isEmpty()) continue;
            level.addFreshEntity(new ItemEntity(level, x, y, z, stack));
        }
    }

    private static final UUID LAVA_WALKER_SPEED_UUID = UUID.fromString("a1b2c3d4-0001-0001-0001-000000000001");
    private static final UUID GREAT_FORTUNE_SPEED_UUID = UUID.fromString("a1b2c3d4-0001-0001-0001-000000000002");
    private static final UUID SEA_GOD_SPEED_UUID = UUID.fromString("a1b2c3d4-0001-0001-0001-000000000003");

    // For Plunder ranged drops via projectiles:
    @SubscribeEvent
    public static void onPlunderProjectileImpact(ProjectileImpactEvent event) {
        if (event.getEntity().level().isClientSide) return;
        if (!(event.getRayTraceResult() instanceof net.minecraft.world.phys.EntityHitResult entityHit)) return;
        if (!(entityHit.getEntity() instanceof LivingEntity target)) return;

        if (!(((Projectile)event.getEntity()).getOwner() instanceof net.minecraft.world.entity.player.Player player)) return;

        ItemStack weapon = player.getMainHandItem();
        int plunderLevel = weapon.getEnchantmentLevel(ModEnchantments.PLUNDER.get());

        // Also check bow/crossbow in offhand or use item
        if (plunderLevel <= 0) {
            weapon = player.getOffhandItem();
            plunderLevel = weapon.getEnchantmentLevel(ModEnchantments.PLUNDER.get());
        }

        if (plunderLevel <= 0) return;

        if (player.level().random.nextDouble() >= ModConfig.COMMON.plunderChance.get()) return;

        boolean isVillagerTarget = target instanceof AbstractVillager
            || target instanceof AbstractIllager
            || target instanceof net.minecraft.world.entity.npc.WanderingTrader;
        boolean isPiglinTarget = target instanceof net.minecraft.world.entity.monster.piglin.AbstractPiglin;

        var serverLevel = (ServerLevel) player.level();
        if (isVillagerTarget) {
            serverLevel.addFreshEntity(new net.minecraft.world.entity.item.ItemEntity(
                serverLevel, target.getX(), target.getY() + 0.5, target.getZ(),
                new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.EMERALD)));
        }
        if (isPiglinTarget) {
            serverLevel.addFreshEntity(new net.minecraft.world.entity.item.ItemEntity(
                serverLevel, target.getX(), target.getY() + 0.5, target.getZ(),
                new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.GOLD_INGOT)));
        }
    }

    // ====== Cherry Blossom / Star Treasure: durability bonus (prevent break, consume count) ======
    @SubscribeEvent
    public static void onPlayerDestroyItem(net.minecraftforge.event.entity.player.PlayerDestroyItemEvent event) {
        ItemStack original = event.getOriginal();
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (player.level().isClientSide) return;

        // Cherry Blossom tool durability
        if (original.getEnchantmentLevel(ModEnchantments.CHERRY_BLOSSOM.get()) > 0) {
            var tag = original.getTag();
            if (tag != null) {
                int count = tag.getInt(CherryBlossomEnchantment.CHERRY_BLOSSOM_COUNT_TAG);
                if (count > 0) {
                    ItemStack restored = original.copy();
                    restored.setDamageValue(0);
                    var restoredTag = restored.getOrCreateTag();
                    restoredTag.putInt(CherryBlossomEnchantment.CHERRY_BLOSSOM_COUNT_TAG, count - 1);
                    restored.setTag(restoredTag);

                    if (!player.addItem(restored)) {
                        player.drop(restored, false);
                    }
                    return;
                }
            }
        }

        // Star Treasure durability pool
        handleStarTreasureBreakRecovery(player, original);
    }

    /**
     * 耐久耗尽时消耗 1 点耐久类矿物、把武器救回来 —— 星光财宝耐久加成的唯一实现点。
     *
     * <p><b>为什么只能挂在这里</b>：Forge 1.20.1 无法真正改大物品的最大耐久
     * （属性系统的 MAX_DAMAGE 是 1.21 才加的；{@code ItemStack#getMaxDamage()} 是 final
     * 且没有对应事件），所以「耐久 +N」只能落成「额外的、按次消耗的耐久池」。
     *
     * <p>顺带说明两种模式的差别：
     * <ul>
     *   <li>{@code MAX_DAMAGE} 与 {@code BOTH}：耐久耗尽时先扣池子把武器救回，
     *       因此只要池里还有点，武器就永远不会碎 —— 表现为「更耐用」；</li>
     *   <li>{@code RESTORE_ON_BREAK}：同样是耗尽时扣池子修复，只是语义上更强调
     *       「事后补救」而不是「提前挡住」。</li>
     * </ul>
     * 要走真正的「最大耐久 +N」，需要给本仓库启用 Mixin 并注入
     * {@code ItemStack#getMaxDamage}；build.gradle 里的 Mixin 目前是注释掉的，故未引入。
     *
     * <p>优先级由 {@link StarTreasureMinerals#pickDurabilityMineral} 决定：
     * 铁 → 绿宝石 → 铜 → 金 → 黑曜石 → 末地石 → 黑石 → 石头。
     */
    private static void handleStarTreasureBreakRecovery(ServerPlayer player, ItemStack original) {
        if (original.getEnchantmentLevel(ModEnchantments.STAR_TREASURE.get()) <= 0) return;
        if (!StarTreasureMinerals.durabilityMode().usesRestoreOnBreak()) return;

        CompoundTag tag = original.getTag();
        if (tag == null) return;

        StarTreasureMinerals mineral = StarTreasureMinerals.pickDurabilityMineral(tag);
        if (mineral == null) return;

        CompoundTag data = tag.getCompound(StarTreasureEnchantment.STAR_TREASURE_DATA_TAG);
        int remaining = data.getInt(mineral.getKey());
        if (remaining <= 0) return;

        ItemStack restored = original.copy();
        restored.setDamageValue(0);
        CompoundTag restoredTag = restored.getOrCreateTag();
        CompoundTag restoredData = restoredTag.contains(StarTreasureEnchantment.STAR_TREASURE_DATA_TAG, 10)
            ? restoredTag.getCompound(StarTreasureEnchantment.STAR_TREASURE_DATA_TAG)
            : new CompoundTag();
        restoredData.putInt(mineral.getKey(), remaining - 1);
        restoredTag.put(StarTreasureEnchantment.STAR_TREASURE_DATA_TAG, restoredData);
        restored.setTag(restoredTag);

        if (!player.addItem(restored)) {
            player.drop(restored, false);
        }
    }

    // ====== Butcher: double drops from farm animals ======
    @SubscribeEvent
    public static void onButcherDrops(LivingDropsEvent event) {
        if (event.getEntity().level().isClientSide) return;
        if (!(event.getSource().getEntity() instanceof ServerPlayer player)) return;

        ItemStack weapon = player.getMainHandItem();
        int butcherLevel = weapon.getEnchantmentLevel(ModEnchantments.BUTCHER.get());
        if (butcherLevel <= 0) return;

        Entity dead = event.getEntity();
        ResourceLocation typeId = BuiltInRegistries.ENTITY_TYPE.getKey(dead.getType());
        String typeStr = typeId.toString();

        var whitelist = ModConfig.COMMON.butcherWhitelist.get();
        var blacklist = ModConfig.COMMON.butcherBlacklist.get();
        if (!whitelist.contains(typeStr)) return;
        if (blacklist.contains(typeStr)) return;

        double chance = ModConfig.COMMON.butcherLevel1Chance.get()
            + (butcherLevel - 1) * (ModConfig.COMMON.butcherMaxChance.get() - ModConfig.COMMON.butcherLevel1Chance.get()) / 2.0;
        if (player.level().random.nextDouble() >= chance) return;

        var drops = new java.util.ArrayList<ItemEntity>(event.getDrops());
        for (ItemEntity ie : drops) {
            if (!ie.getItem().isEmpty()) {
                ItemStack copy = ie.getItem().copy();
                event.getDrops().add(new ItemEntity(
                    ie.level(), ie.getX(), ie.getY(), ie.getZ(), copy));
            }
        }
    }

    // ══════════════════ 超级核弹：按设定实现 ══════════════════
    //
    // 设定（原文）：
    //   破坏等级 = 1 + ((((附魔等级 x2) + 爆炸威力 x 25.5%) - 方块硬度) + 10) x 1.25
    //   衰减：每过 5 格，破坏威力削减 8.65%
    //   爆炸伤害 = 1 + ((((附魔等级 x3) + 爆炸威力 x 50%) + 运算等级) / 15) x 2
    //   运算等级：1级 = 2^5，2级 = 2^8，以此类推
    //   破坏方块时，保留硬度 > 5 的方块掉落物；硬度 < 5 的方块掉落物会被清除
    //   爆炸不会清除：箱子、末影箱
    //   爆炸会保留掉落物：矿石、矿石方块
    //   方块爆炸范围取决于爆炸威力
    //
    // 实现说明：
    //   - 原实现只是「取消原版爆炸 -> 用更大的 power 再炸一次」，
    //     既没有破坏等级/衰减，也没有掉落物与保护方块规则，所以这里改成自己遍历破坏。
    //   - 每个方块只处理「暴露在空气/液体中」的面，避免整块球体全量遍历导致卡顿。
    //   - 实体伤害走原版 explode()，但用 ExplosionInteraction.NONE 表示不改方块，
    //     这样伤害/击退公式保持与原版一致，同时不会再触发一次方块破坏。
    private static final double SUPER_NUKE_DECAY_PER_5_BLOCKS = 0.0865;
    /** 高于该硬度的方块在爆炸时保留掉落物。 */
    private static final float SUPER_NUKE_DROP_KEEP_HARDNESS = 5.0f;
    /** 爆炸范围内要写的方块数量上限，防止配置被改大后一次炸出几十万个方块更新。 */
    private static final int SUPER_NUKE_MAX_BLOCKS = 40000;
    /** 单次爆炸最多连锁点燃的 TNT 数量（防止连锁把主线程拖死）。 */
    private static final int SUPER_NUKE_MAX_CHAIN = 256;
    /** 连锁 TNT 的基础引信（tick）。 */
    private static final int SUPER_NUKE_CHAIN_FUSE = 10;
    /** 连锁 TNT 引信的随机抖动（tick），把批量结算摊到多个 tick。 */
    private static final int SUPER_NUKE_CHAIN_FUSE_JITTER = 20;
    /** 实体伤害上限，防止「运算等级」把伤害算成天文数字。 */
    private static final float SUPER_NUKE_MAX_DAMAGE = 1000.0f;
    /** 破坏/伤害半径硬上限。默认配置（5 + 等级×2，满级 17）远低于此，只是防配置被改爆。 */
    private static final double SUPER_NUKE_MAX_RADIUS = 64.0;

    /**
     * 玩家放置的「超级核弹 TNT 方块」：(维度, 坐标) → 附魔等级。
     *
     * 为什么需要这张表：附魔挂在 TNT <b>物品</b> 上，方块本身不承载附魔数据。
     * 而 {@code TntBlock.wasExploded}（被别的爆炸点燃）用 {@code explosion.getIndirectSourceEntity()}、
     * {@code onPlace / neighborChanged}（红石点燃）直接传 {@code null}，
     * 两者都拿不到「点燃者」，于是「点燃时扫玩家背包」的旧判据失效 ——
     * 这正是维护者报的「用普通 TNT 点燃超级核弹的 TNT 后，效果降级为普通 TNT」。
     * 现在在<b>放置那一刻</b>就把等级记下来，任何点燃源都能查回。
     */
    private static final Map<String, Integer> SUPER_NUKE_TNT_BLOCKS = new HashMap<>();

    private static String superNukeBlockKey(net.minecraft.resources.ResourceKey<Level> dim, BlockPos pos) {
        return dim.location() + "@" + pos.asLong();
    }

    /** 玩家背包（含副手）里最高的超级核弹附魔等级。 */
    private static int bestSuperNukeLevel(Player player) {
        int best = player.getOffhandItem().getEnchantmentLevel(ModEnchantments.SUPER_NUKE.get());
        for (ItemStack stack : player.getInventory().items) {
            int lvl = stack.getEnchantmentLevel(ModEnchantments.SUPER_NUKE.get());
            if (lvl > best) best = lvl;
        }
        return best;
    }

    /** 查询并消费某个坐标上的「超级核弹 TNT 方块」记录。 */
    private static int takeSuperNukeBlockLevel(ServerLevel level, BlockPos pos) {
        String key = superNukeBlockKey(level.dimension(), pos);
        Integer lvl = SUPER_NUKE_TNT_BLOCKS.get(key);
        if (lvl == null) return 0;

        // ⚠ 这里**不能**只认「方块还是 TNT」。
        // Forge 的 IForgeBlock#onBlockExploded 默认实现是（IForgeBlock.java:716-720）：
        //     level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
        //     self().wasExploded(level, pos, explosion);
        // 也就是「把方块设成空气」在前、创建 PrimedTnt 的 wasExploded 在后
        // （Explosion.java:274 调用它）。所以被别的爆炸点燃时，
        // 新 TNT 实体触发 EntityJoinLevelEvent 的那一刻，原位方块<b>已经是空气</b>。
        // 只认 TNT 会把这条记录当过期删掉 —— 那正好就是维护者报的
        // 「用普通 TNT 点燃超级核弹的 TNT 后降级为普通 TNT」。
        // 因此「TNT 或空气」都算命中；换成别的方块才认为记录过期。
        BlockState state = level.getBlockState(pos);
        if (!state.is(net.minecraft.world.level.block.Blocks.TNT) && !state.isAir()) {
            SUPER_NUKE_TNT_BLOCKS.remove(key);
            return 0;
        }
        SUPER_NUKE_TNT_BLOCKS.remove(key);
        return lvl;
    }

    /**
     * 玩家放下 TNT 时登记其超级核弹等级。
     * 这样红石点燃、普通 TNT 连锁点燃都能认出「这是一枚核弹 TNT」。
     */
    @SubscribeEvent
    public static void onSuperNukeTntPlaced(net.minecraftforge.event.level.BlockEvent.EntityPlaceEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        // 客户端也会跑 BlockItem.place（预测放置），必须挡掉
        if (player.level().isClientSide) return;
        if (!event.getPlacedBlock().is(net.minecraft.world.level.block.Blocks.TNT)) return;

        // 放置事件触发时物品可能已经从手上扣掉了，所以「手 → 背包」两级兜底
        int level = Math.max(
            player.getMainHandItem().getEnchantmentLevel(ModEnchantments.SUPER_NUKE.get()),
            player.getOffhandItem().getEnchantmentLevel(ModEnchantments.SUPER_NUKE.get()));
        if (level <= 0) level = bestSuperNukeLevel(player);

        String key = superNukeBlockKey(player.level().dimension(), event.getPos());
        if (level <= 0) {
            SUPER_NUKE_TNT_BLOCKS.remove(key);
            return;
        }
        if (SUPER_NUKE_TNT_BLOCKS.size() > 8192) SUPER_NUKE_TNT_BLOCKS.clear();   // 防呆：异常增长时清空
        SUPER_NUKE_TNT_BLOCKS.put(key, level);
    }

    @SubscribeEvent
    public static void onExplosionStart(net.minecraftforge.event.level.ExplosionEvent.Start event) {
        if (event.getLevel().isClientSide) return;
        if (PROCESSING_SUPER_NUKE.get()) return;

        var explosion = event.getExplosion();
        if (!(explosion.getExploder() instanceof PrimedTnt tnt)) return;

        var data = tnt.getPersistentData();
        if (!data.contains("super_nuke_level")) return;

        int nukeLevel = data.getInt("super_nuke_level");
        if (nukeLevel <= 0) return;

        if (!(event.getLevel() instanceof ServerLevel serverLevel)) return;

        event.setCanceled(true);

        PROCESSING_SUPER_NUKE.set(true);
        try {
            // 爆炸威力 = 基础 + 每级增量（配置项）
            float power = ModConfig.COMMON.superNukeBasePower.get().floatValue()
                + nukeLevel * ModConfig.COMMON.superNukePowerPerLevel.get().floatValue();

            // 运算等级：1级=2^5, 2级=2^8, 3级=2^11, ... 即 2^(5 + 3*(level-1))
            double computeLevel = Math.pow(2.0, 5.0 + 3.0 * (nukeLevel - 1));

            double cx = tnt.getX(), cy = tnt.getY(), cz = tnt.getZ();
            // ★ 破坏半径 = 爆炸威力。方块破坏与实体伤害共用这一个半径，
            //   满足维护者要求「伤害范围 = 破坏范围」。
            double radius = Math.max(1.0, Math.min(power, SUPER_NUKE_MAX_RADIUS));
            int ir = (int) Math.ceil(radius);
            var center = BlockPos.containing(cx, cy, cz);

            // ---- 连锁引爆 ----
            // 必须先做：下面那段破坏循环会把范围内的 TNT 方块一并挖掉。
            chainDetonateSuperNuke(serverLevel, center, ir, cx, cy, cz, radius, nukeLevel,
                tnt.getOwner());

            // ---- 破坏方块 ----
            int placed = 0;
            for (BlockPos pos : BlockPos.betweenClosed(
                    center.offset(-ir, -ir, -ir),
                    center.offset(ir, ir, ir))) {

                if (placed >= SUPER_NUKE_MAX_BLOCKS) break;

                // ★ 距离判定放最前面：绝大多数格子在这里就被便宜地筛掉
                double dx = (pos.getX() + 0.5) - cx;
                double dy = (pos.getY() + 0.5) - cy;
                double dz = (pos.getZ() + 0.5) - cz;
                double distSqr = dx * dx + dy * dy + dz * dz;
                if (distSqr > radius * radius) continue;
                double dist = Math.sqrt(distSqr);

                BlockState state = serverLevel.getBlockState(pos);
                if (state.isAir()) continue;
                float hardness = state.getDestroySpeed(serverLevel, pos);
                if (hardness < 0.0f) continue;   // 基岩等不可破坏方块

                // 只处理暴露面，避免对球体内部做无用计算
                if (!isExposedToAir(serverLevel, pos)) continue;

                // 衰减：每过 5 格，破坏威力削减 8.65%
                double decay = Math.pow(1.0 - SUPER_NUKE_DECAY_PER_5_BLOCKS, dist / 5.0);

                // 破坏等级 = 1 + ((((附魔等级 x2) + 爆炸威力 x 25.5%) - 方块硬度) + 10) x 1.25
                double destructionLevel =
                    1.0 + ((((nukeLevel * 2.0) + (power * 0.255) - hardness) + 10.0) * 1.25);
                double effective = destructionLevel * decay;

                if (effective <= hardness) continue;   // 炸不动

                if (isSuperNukeProtected(serverLevel, pos, state)) continue;   // 箱子 / 末影箱：整个不动

                boolean keepDrops = hardness > SUPER_NUKE_DROP_KEEP_HARDNESS
                    || isSuperNukeDropPreserved(serverLevel, pos, state);

                if (!keepDrops) {
                    serverLevel.removeBlock(pos, false);
                } else {
                    // 掉落物按「精准采集」的方式取本体，避免岩石变成圆石这种降级
                    var drops = Block.getDrops(state, serverLevel, pos,
                        serverLevel.getBlockEntity(pos),
                        null,
                        new ItemStack(net.minecraft.world.item.Items.DIAMOND_PICKAXE));
                    serverLevel.removeBlock(pos, false);
                    for (ItemStack drop : drops) {
                        if (!drop.isEmpty()) {
                            Block.popResource(serverLevel, pos, drop);
                        }
                    }
                }
                placed++;
            }

            // ---- 伤害实体：与上面方块使用同一个 radius ----
            damageSuperNukeEntities(serverLevel, tnt, cx, cy, cz, radius, nukeLevel, power, computeLevel);

            // ---- 表现 ----
            // 原版 explode() 已经不走了，音效与粒子得自己补，否则核弹爆炸静悄悄。
            serverLevel.playSound(null, cx, cy, cz,
                net.minecraft.sounds.SoundEvents.GENERIC_EXPLODE,
                net.minecraft.sounds.SoundSource.BLOCKS, 4.0F,
                (1.0F + (serverLevel.random.nextFloat() - serverLevel.random.nextFloat()) * 0.2F) * 0.7F);
            serverLevel.sendParticles(net.minecraft.core.particles.ParticleTypes.EXPLOSION_EMITTER,
                cx, cy, cz, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        } finally {
            PROCESSING_SUPER_NUKE.set(false);
        }
    }

    /**
     * 超级核弹的实体伤害。
     *
     * <p><b>维护者口径（2026-10-12 确认）</b>：超级核弹的爆炸伤害<b>不属于玩家</b> ——
     * 击杀不算玩家的、不给经验、不触发玩家的击杀类效果。所以这里<b>故意</b>不把点燃者
     * 设成伤害归属。
     *
     * <p>维护者的另外两条要求：「伤害范围 = 破坏范围」＋「性能」。
     *
     * <p><b>旧实现为什么范围与性能都错</b>：旧代码把「爆炸伤害」这个<b>数值</b>当成
     * {@code Level#explode} 的 <b>radius</b> 参数传进去
     * （{@code (float) Math.min(explosionDamage, 1000.0)}，见 git 里的 3140-3143 行）。于是：
     * <ul>
     *   <li>伤害半径成了 1000 格，而破坏半径只有 {@code 5 + 等级×2} 格 → 范围对不上；</li>
     *   <li>原版 {@code Explosion#explode()} 会对 16×16×16 条射线各步进 0.3 格
     *       （{@code Explosion.java:133-173}），radius=1000 时约一千五百万次方块查询，
     *       外加边长 2000 格的实体 AABB 查询、每只实体一次体素射线（{@code getSeenPercent}）
     *       → <b>主线程直接卡死，这就是「每点一次卡死」</b>。</li>
     * </ul>
     *
     * <p>所以这里不再调用原版 explosion，而是自己在<b>同一个 radius</b> 内结算伤害。
     */
    private static void damageSuperNukeEntities(ServerLevel level, PrimedTnt tnt,
                                                double cx, double cy, double cz,
                                                double radius, int nukeLevel, float power,
                                                double computeLevel) {
        // ★ 伤害归属：**刻意不传给玩家**。
        //   DamageSources#explosion(Entity, Entity) 的形参顺序是 (directEntity, causingEntity)，
        //   第二个参数才会成为 DamageSource#getEntity()（也就是「算谁击杀」）。
        //   这里第二项传 null ⇒ 类型退回 DamageTypes.EXPLOSION、
        //   getEntity() 为 null ⇒ 击杀/经验/统计都不归玩家，符合维护者口径。
        //   （第一项传 TNT 本体，保持「伤害来自这枚 TNT」这一事实，
        //     与原版 TNT 爆炸的 directEntity 语义一致。）
        DamageSource source = level.damageSources().explosion(tnt, null);

        // 设定：爆炸伤害 = 1 + ((((附魔等级x3) + 爆炸威力x50%) + 运算等级) / 15) x 2
        double baseDamage = 1.0 + ((((nukeLevel * 3.0) + (power * 0.50)) + computeLevel) / 15.0) * 2.0;
        baseDamage = Math.min(baseDamage, SUPER_NUKE_MAX_DAMAGE);

        Vec3 center = new Vec3(cx, cy, cz);
        AABB box = new AABB(cx - radius, cy - radius, cz - radius,
                            cx + radius, cy + radius, cz + radius);

        for (Entity target : level.getEntities(tnt, box)) {
            if (target == tnt || target.isRemoved()) continue;
            if (target.ignoreExplosion()) continue;
            if (target instanceof PrimedTnt) continue;   // 连锁 TNT 互不伤害

            double dist = Math.sqrt(target.distanceToSqr(center));
            if (dist > radius) continue;                 // ← 与破坏半径完全一致

            // 距离衰减 × 视线遮挡（沿用原版 getSeenPercent，墙后能挡爆炸）
            double falloff = (1.0 - dist / radius)
                * net.minecraft.world.level.Explosion.getSeenPercent(center, target);
            if (falloff <= 0.0) continue;

            float damage = (float) (baseDamage * falloff);
            if (damage <= 0.0f) continue;

            target.hurt(source, damage);

            // 击退：与原版同向、同量级（原版公式也用 (1 - d/r) 作为强度）
            double kx = target.getX() - cx;
            double ky = target.getEyeY() - cy;
            double kz = target.getZ() - cz;
            double len = Math.sqrt(kx * kx + ky * ky + kz * kz);
            if (len > 1.0E-4) {
                target.push(kx / len * falloff, ky / len * falloff, kz / len * falloff);
                target.hurtMarked = true;
            }
        }
    }

    /**
     * 连锁引爆：把破坏半径内的 TNT 方块换成「同等级」的 PrimedTnt。
     *
     * <p><b>为什么原版连锁不会发生</b>：原版靠
     * {@code Explosion#finalizeExplosion} → {@code BlockState#onBlockExploded}
     * → {@code TntBlock#wasExploded}（{@code TntBlock.java:73-80}）来点燃邻接 TNT。
     * 而我们用 {@code ExplosionInteraction.NONE}（= {@code BlockInteraction.KEEP}）时
     * {@code Explosion#interactsWithBlocks()} 为 false（{@code Explosion.java:294-296}），
     * {@code finalizeExplosion} 里那段整个被跳过 → <b>「超级核弹无法连锁触发」</b>。
     *
     * <p>这里给连锁 TNT 一个 10~30 tick 的引信而不是立刻递归爆炸：既保证真连锁，
     * 又把工作量摊到多个 tick，避免一次点爆就把主线程卡死。
     *
     * <p>关于 {@code igniter}：原版 {@code TntBlock#wasExploded} 也是用
     * {@code explosion.getIndirectSourceEntity()}（对 PrimedTnt 而言就是 {@code getOwner()}）
     * 作为新 TNT 的 owner，所以这里照抄以保持与原版一致。
     * 但<b>它不参与伤害归属</b>：{@code damageSuperNukeEntities} 构造 DamageSource 时
     * 第二项固定传 {@code null}，所以连锁出来的核弹一样不会把击杀算给玩家。
     */
    private static void chainDetonateSuperNuke(ServerLevel level, BlockPos center, int ir,
                                               double cx, double cy, double cz,
                                               double radius, int nukeLevel,
                                               @javax.annotation.Nullable LivingEntity igniter) {
        int primed = 0;
        for (BlockPos pos : BlockPos.betweenClosed(
                center.offset(-ir, -ir, -ir), center.offset(ir, ir, ir))) {
            if (primed >= SUPER_NUKE_MAX_CHAIN) break;

            double dx = (pos.getX() + 0.5) - cx;
            double dy = (pos.getY() + 0.5) - cy;
            double dz = (pos.getZ() + 0.5) - cz;
            if (dx * dx + dy * dy + dz * dz > radius * radius) continue;

            if (!level.getBlockState(pos).is(net.minecraft.world.level.block.Blocks.TNT)) continue;

            BlockPos immutable = pos.immutable();
            level.removeBlock(immutable, false);

            PrimedTnt chain = new PrimedTnt(level,
                immutable.getX() + 0.5D, immutable.getY(), immutable.getZ() + 0.5D, igniter);
            // ★ 关键：把核弹等级原样传下去，否则连锁出来的就是普通 TNT（降级）
            chain.getPersistentData().putInt("super_nuke_level", nukeLevel);
            chain.setFuse(SUPER_NUKE_CHAIN_FUSE
                + level.random.nextInt(SUPER_NUKE_CHAIN_FUSE_JITTER + 1));
            level.addFreshEntity(chain);
            primed++;
        }
    }

    /** 该方块是否至少有一个面暴露在空气或液体中（用于跳过球体内部）。 */
    private static boolean isExposedToAir(ServerLevel level, BlockPos pos) {
        for (net.minecraft.core.Direction dir : net.minecraft.core.Direction.values()) {
            BlockState neighbour = level.getBlockState(pos.relative(dir));
            if (neighbour.isAir() || !neighbour.getFluidState().isEmpty()) return true;
        }
        return false;
    }

    /**
     * 爆炸完全不动的方块：箱子、末影箱（按设定）。
     */
    private static boolean isSuperNukeProtected(ServerLevel level, BlockPos pos, BlockState state) {
        var block = state.getBlock();
        return block instanceof net.minecraft.world.level.block.ChestBlock
            || block == net.minecraft.world.level.block.Blocks.ENDER_CHEST
            || block == net.minecraft.world.level.block.Blocks.TRAPPED_CHEST;
    }

    /**
     * 爆炸保留掉落物的方块：矿石与矿石方块（按设定）。
     *
     * 判据用原版矿石标签，而不是硬编码方块清单：
     * 这样模组/数据包加进来的矿石也会被一并保护。
     */
    private static boolean isSuperNukeDropPreserved(ServerLevel level, BlockPos pos, BlockState state) {
        return state.is(net.minecraft.tags.BlockTags.COAL_ORES)
            || state.is(net.minecraft.tags.BlockTags.IRON_ORES)
            || state.is(net.minecraft.tags.BlockTags.COPPER_ORES)
            || state.is(net.minecraft.tags.BlockTags.GOLD_ORES)
            || state.is(net.minecraft.tags.BlockTags.REDSTONE_ORES)
            || state.is(net.minecraft.tags.BlockTags.EMERALD_ORES)
            || state.is(net.minecraft.tags.BlockTags.LAPIS_ORES)
            || state.is(net.minecraft.tags.BlockTags.DIAMOND_ORES)
            || state.getBlock() instanceof net.minecraft.world.level.block.DropExperienceBlock;
    }

    // ====== Ender Gaze: suppress enderman anger ======
    @SubscribeEvent
    public static void onEnderManAnger(net.minecraftforge.event.entity.living.EnderManAngerEvent event) {
        Player player = event.getPlayer();
        if (player.getItemBySlot(EquipmentSlot.HEAD)
            .getEnchantmentLevel(ModEnchantments.ENDER_GAZE.get()) > 0) {
            event.setCanceled(true);
        }
    }

    // ====== Huff: creepers and phantoms flee ======
    @SubscribeEvent
    public static void onHuffTick(LivingEvent.LivingTickEvent event) {
        if (event.getEntity().level().isClientSide) return;
        if (!(event.getEntity() instanceof net.minecraft.world.entity.monster.Creeper
            || event.getEntity() instanceof net.minecraft.world.entity.monster.Phantom)) return;
        if (!(event.getEntity() instanceof Mob mob)) return;

        // Find nearest player with Huff helmet within range
        Player nearest = null;
        double nearestDist = Double.MAX_VALUE;
        for (Player p : event.getEntity().level().players()) {
            if (!(p instanceof ServerPlayer)) continue;
            int huffLevel = p.getItemBySlot(EquipmentSlot.HEAD)
                .getEnchantmentLevel(ModEnchantments.HUFF.get());
            if (huffLevel <= 0) continue;
            double dist = p.distanceToSqr(mob);
            // 范围按设定：1 + (附魔等级 + 2)
            // 旧实现是 huffBaseRange(默认4.0) + 等级，与设定不符。
            // huffBaseRange 这个配置项因此不再参与计算（字段保留，避免破坏已有配置文件的解析）。
            double range = ModConfig.COMMON.huffBaseRange.get()
            + huffLevel * ModConfig.COMMON.huffRangePerLevel.get()
            + ModConfig.COMMON.huffRangeOffset.get();
            if (dist < range * range && dist < nearestDist) {
                nearest = p;
                nearestDist = dist;
            }
        }

        if (nearest != null) {
            mob.setTarget(null);
            mob.setLastHurtByMob(null);
            if (mob.getNavigation().isDone() || mob.getTarget() == nearest) {
                Vec3 away = mob.position().subtract(nearest.position()).normalize();
                mob.getNavigation().moveTo(
                    mob.getX() + away.x * 10,
                    mob.getY(),
                    mob.getZ() + away.z * 10,
                    1.3);
            }
        }
    }

    @SubscribeEvent
    public static void onLivingChangeTarget(LivingChangeTargetEvent event) {
        if (event.isCanceled()) return;
        if (event.getEntity().level().isClientSide) return;

        // Barbarian Vanguard: Piglin Brute won't attack players wearing the enchanted helmet
        if (event.getEntity() instanceof PiglinBrute
            && event.getNewTarget() instanceof Player player
            && player.getItemBySlot(EquipmentSlot.HEAD)
                .getEnchantmentLevel(ModEnchantments.BARBARIAN_VANGUARD.get()) > 0) {
            event.setCanceled(true);
        }

        // 星光财宝原有的「手持金锭锻造的武器 → 猪灵不攻击」已按新规格删除：
        // 金在这一版里是纯粹的耐久材料（每点 +0.1），不再附带仇恨豁免。
    }

    @SubscribeEvent
    public static void onUndyingTick(LivingEvent.LivingTickEvent event) {
        if (!(event.getEntity() instanceof net.minecraft.world.entity.player.Player player)) return;
        if (player.level().isClientSide) return;

        // 冥界花到期结算（不死附魔的「后遗症」伤害）。
        //
        // 【原来的写法为什么不可靠】
        // 旧代码判据是 player.getEffect(NETHER_FLOWER) == null，也就是「效果对象消失了」才算到期。
        // 但 MobEffectInstance 是可以被别的模组 / 指令 / 牛奶清除的，而且刚 addEffect 的那一 tick
        // 就可能在别的 tick 处理器里读到 null，于是出现两种错误表现：
        //   - 效果被提前清掉时，后遗症伤害会提前、重复地打出来；
        //   - 效果被延长或未同步时，后遗症永远等不到。
        // 另外旧代码依赖 onPlayerTick 兜底，而 onPlayerTick 与这里存在重复判定。
        //
        // 【现在的做法】
        // 施加效果时记下绝对到期游戏刻，到这里只比时间；到期即结算一次并移除记录。
        // 这段状态与结算逻辑已收归 UndyingGuard：它同时也是「保护窗口」的权威来源，
        // 并负责窗口内的效果维持与「窗口结束就彻底放手」。
        if (player instanceof ServerPlayer undyingPlayer) {
            UndyingGuard.serverTick(undyingPlayer);
        }

        // Lava Walker: transform lava to obsidian when walking on it
        var boots = player.getItemBySlot(EquipmentSlot.FEET);
        int lavaWalkerLevel = boots.getEnchantmentLevel(ModEnchantments.LAVA_WALKER.get());

        if (lavaWalkerLevel > 0 && player.onGround() && !player.isShiftKeyDown()) {
            var blockPos = player.blockPosition();
            var level = player.level();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    var pos = blockPos.offset(dx, -1, dz);
                    var state = level.getBlockState(pos);
                    if (state.is(net.minecraft.world.level.block.Blocks.LAVA)) {
                        level.setBlock(pos, net.minecraft.world.level.block.Blocks.OBSIDIAN.defaultBlockState(),
                            net.minecraft.world.level.block.Block.UPDATE_ALL_IMMEDIATE);
                    }
                }
            }
        }

        // ── 大运：按设定实现 ────────────────────────────────────────────────────
        //
        // 设定（原文）：
        //   速度 = 1 + ((等级 x 1.25) + (速度buff x 0.5%) + 基础速度 x 5%) / 2.2
        //   冰霜行者：每级额外 15% 移速
        //   伤害 = 1 + (计算速度 + 玩家伤害 x 15%) x 1.55
        //   坐船时，船继承 15% 速度并拥有 120% 撞击伤害
        //   击飞距离 = 1 + (造成的伤害 - 击飞抗性)
        //
        // 「速度buff」取移动速度效果的实际加成（每级 +20%，即 0.2 x 等级）；
        // 「基础速度」取移动速度属性的 baseValue（玩家默认 0.1）。
        // 该乘数乘在 baseValue 上（MULTIPLY_BASE）：它本身是个倍率，
        // 若当 ADDITION 平加，会让基础速度不同的实体收益失真，与设定的乘除结构不符。
        int gfLevel = boots.getEnchantmentLevel(ModEnchantments.GREAT_FORTUNE.get());
        var speedAttr = player.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED);

        if (gfLevel > 0 && speedAttr != null) {
            var blockBelow = player.level().getBlockState(player.blockPosition().below());
            boolean onIce = blockBelow.is(net.minecraft.world.level.block.Blocks.ICE)
                || blockBelow.is(net.minecraft.world.level.block.Blocks.PACKED_ICE)
                || blockBelow.is(net.minecraft.world.level.block.Blocks.BLUE_ICE)
                || blockBelow.is(net.minecraft.world.level.block.Blocks.FROSTED_ICE);

            if (onIce) {
                var speedEffect = player.getEffect(net.minecraft.world.effect.MobEffects.MOVEMENT_SPEED);
                double speedBuffValue = 0.0;
                if (speedEffect != null) {
                    speedBuffValue = (speedEffect.getAmplifier() + 1) * 0.2;
                }
                double baseSpeed = speedAttr.getBaseValue();

                // 速度 = 1 + ((等级 x 等级乘数) + (速度buff x buff乘数) + 基础速度 x 基础乘数) / 除数
                // 公式里的四个系数都可在配置里调（great_fortune_enchantment 分组）
                var gfc = ModConfig.COMMON;
                double speedMultiplier =
                    1.0 + ((gfLevel * gfc.greatFortuneSpeedLevelMultiplier.get())
                           + (speedBuffValue * gfc.greatFortuneSpeedBuffMultiplier.get())
                           + (baseSpeed * gfc.greatFortuneBaseSpeedMultiplier.get()))
                          / gfc.greatFortuneSpeedDivisor.get();

                // 冰霜行者联动：每级额外移速（配置项 frost_walker_speed_per_level，默认 15%）
                int frostWalkerLevel = boots.getEnchantmentLevel(
                    net.minecraft.world.item.enchantment.Enchantments.FROST_WALKER);
                if (frostWalkerLevel > 0) {
                    speedMultiplier += gfc.greatFortuneFrostWalkerSpeedPerLevel.get() * frostWalkerLevel;
                }

                speedAttr.removeModifier(GREAT_FORTUNE_SPEED_UUID);
                speedAttr.addTransientModifier(new net.minecraft.world.entity.ai.attributes.AttributeModifier(
                    GREAT_FORTUNE_SPEED_UUID, "Great Fortune ice speed",
                    speedMultiplier - 1.0,
                    net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.MULTIPLY_BASE));

                double playerSpeed = speedAttr.getValue();
                var attackAttr2 = player.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE);
                double playerAttackDmg = attackAttr2 != null ? attackAttr2.getValue() : 0.0;

                // ── 伤害：攻击力 × (1% ~ 10%)，百分比随速度提升 ──────────────────
                //
                // 维护者口径：「大运的伤害上限是吃自身攻击力的 1%，
                //              最高可以吃到 10% 的攻击力（速度越快，吃到的攻击力越高）」。
                // 所以伤害 = 玩家攻击力 × 百分比，百分比 f 从下限线性涨到上限，
                // f 的滑块用**属性速度**（不是瞬时位移速度）：属性速度是稳定量，
                // 不会因为撞墙、被卡住而抖成 0。
                // 四个参数（下限 / 上限 / 速度基准 / 速度跨度）都可在配置里调。
                double fMin = gfc.greatFortuneDamageMinPercent.get();
                double fMax = gfc.greatFortuneDamageMaxPercent.get();
                double speedRef = gfc.greatFortuneDamageSpeedReference.get();
                double speedRange = gfc.greatFortuneDamageSpeedRange.get();
                double attrs = Math.max(playerSpeed, 1.0E-4);
                double f = fMin + (attrs - speedRef) * ((fMax - fMin) / speedRange);
                f = Math.max(Math.min(fMin, fMax), Math.min(f, Math.max(fMin, fMax)));
                double greatFortuneDamage = Math.max(1.0, playerAttackDmg * f);

                var aabb = player.getBoundingBox().inflate(0.5);
                for (var le : player.level().getEntitiesOfClass(LivingEntity.class, aabb,
                        e -> e != player && e.isAlive())) {
                    // 击飞距离 = 1 + (造成的伤害 - 击飞抗性)
                    var kbResAttr = le.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE);
                    double knockbackRes = kbResAttr != null ? kbResAttr.getValue() : 0.0;
                    double knockbackDistance = 1.0 + (greatFortuneDamage - knockbackRes);

                    le.hurt(le.damageSources().playerAttack(player), (float) greatFortuneDamage);
                    le.knockback(Math.max(0.1, Math.min(knockbackDistance, 50.0)),
                        player.getX() - le.getX(), player.getZ() - le.getZ());
                }
            } else {
                speedAttr.removeModifier(GREAT_FORTUNE_SPEED_UUID);
            }

            // 坐船：船继承一部分玩家速度，并拥有撞击伤害倍率（两项都可在配置里调）
            if (player.isPassenger() && player.getVehicle() instanceof net.minecraft.world.entity.vehicle.Boat boat) {
                // 【为什么不用属性修饰符】
                // 1.20.1 的船没有任何属性承载速度：Boat.controlBoat() 里推进量是硬编码的
                //     "if (this.inputUp) f += 0.04F;"，Entity 也没有通用的属性表可挂。
                // 因此「继承速度」只能通过直接缩放船的水平速度实现。
                double boatShare = ModConfig.COMMON.greatFortuneBoatSpeedShare.get();
                double inheritedSpeed = speedAttr.getValue() * boatShare;
                // 玩家基础速度 0.1 → 继承 0.015；船的推进基准与之同量级，换算成 10% 的加速
                double speedFactor = 1.0 + Math.max(0.0, Math.min(inheritedSpeed, 0.5)) / 0.15 * 0.10;
                var boatVel = boat.getDeltaMovement();
                boat.setDeltaMovement(boatVel.x * speedFactor, boatVel.y, boatVel.z * speedFactor);

                var attackAttr3 = player.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE);
                double playerAttackDmg3 = attackAttr3 != null ? attackAttr3.getValue() : 0.0;
                // 撞击伤害 = 基础 1 + 玩家伤害 x 倍率
                float boatDamage = (float) (1.0 + playerAttackDmg3
                    * ModConfig.COMMON.greatFortuneBoatImpactMultiplier.get());

                var boatAabb = boat.getBoundingBox().inflate(0.2);
                for (var le : player.level().getEntitiesOfClass(LivingEntity.class, boatAabb,
                        e -> e != player && e.isAlive() && !e.isPassengerOfSameVehicle(boat))) {
                    var kbResAttr = le.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE);
                    double knockbackRes = kbResAttr != null ? kbResAttr.getValue() : 0.0;
                    double knockbackDistance = 1.0 + (boatDamage - knockbackRes);

                    le.hurt(le.damageSources().playerAttack(player), boatDamage);
                    le.knockback(Math.max(0.1, Math.min(knockbackDistance, 50.0)),
                        boat.getX() - le.getX(), boat.getZ() - le.getZ());
                }
            }
        } else if (speedAttr != null) {
            speedAttr.removeModifier(GREAT_FORTUNE_SPEED_UUID);
        }

        // Process pending space slash sub-hits (slashes 2 and 3)
        int[] ssPending = PENDING_SPACE_SLASHES.get(player.getUUID());
        if (ssPending != null) {
            int remaining = ssPending[0];
            int targetId = ssPending[1];
            float baseDamage = Float.intBitsToFloat(ssPending[2]);
            float critMultiplier = ssPending.length > 3 ? Float.intBitsToFloat(ssPending[3]) : 1.0f;

            // 本段是第几段：remaining=2 时打的是第 2 段，remaining=1 时是第 3 段。
            // 递减是动态的：第 n 段 = 玩家那一刀 × (1 - 线性) × 指数^n（两个参数都可配置）。
            int segmentIndex = 3 - remaining;                 // 2 → 第 2 段, 1 → 第 3 段
            float dmg = (float) (baseDamage * segmentDecayFactor(segmentIndex));
            if (critMultiplier > 1.0f) {
                dmg *= critMultiplier;                        // 跳劈时三段都吃暴击
            }

            Entity target = player.level().getEntity(targetId);
            if (target instanceof LivingEntity living && living.isAlive()) {
                living.invulnerableTime = 0;
                PROCESSING_SPACE_SLASH.set(true);
                try {
                    // 补挂不死保护。
                    //
                    // 【为什么这里必须单独处理】
                    // onLivingHurt() 开头有 "if (PROCESSING_SPACE_SLASH.get()) return;"，
                    // 目的是防止连斩二次伤害再次触发整套附魔逻辑（否则会递归）。
                    // 但那条早退把 handleUndyingProtection() 也一起跳过了：
                    // 连斩的第 2/3 段伤害因此可以越过「不死」直接打死玩家。
                    // 这里在调用 hurt() 之前把不死判定单独跑一次，保持既防递归又不漏保护。
                    if (living instanceof ServerPlayer sp) {
                        dmg = guardPendingSlashDamage(sp, dmg);
                    }
                    living.hurt(player.damageSources().playerAttack(player), dmg);
                } finally {
                    PROCESSING_SPACE_SLASH.set(false);
                }
            }

            remaining--;
            if (remaining <= 0) {
                PENDING_SPACE_SLASHES.remove(player.getUUID());
            } else {
                ssPending[0] = remaining;
            }
            // 这里原来还有一次 player.resetAttackStrengthTicker()：
            // 它会在待结算连斩的每个 tick 都把冷却条清零，等于持续压制玩家攻击冷却，
            // 与「攻击冷却归零（同原版战斗更新）」的意图相反，故移除。
        }

        // Sea God Explorer: faster underwater movement
        int sgeLevel = boots.getEnchantmentLevel(ModEnchantments.SEA_GOD_EXPLORER.get());
        if (sgeLevel > 0 && speedAttr != null && player.isInWater()) {
            double speedBonus = sgeLevel * ModConfig.COMMON.seaGodSpeedPerLevel.get();
            var modifier = new net.minecraft.world.entity.ai.attributes.AttributeModifier(
                SEA_GOD_SPEED_UUID, "Sea God Explorer water speed", speedBonus,
                net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.MULTIPLY_BASE);
            if (!speedAttr.hasModifier(modifier)) {
                speedAttr.removeModifier(SEA_GOD_SPEED_UUID);
                speedAttr.addTransientModifier(modifier);
            }
        } else if (speedAttr != null) {
            speedAttr.removeModifier(SEA_GOD_SPEED_UUID);
        }

    }

    @SubscribeEvent
    public static void onEternalLoyaltyEntityJoin(EntityJoinLevelEvent event) {
        if (!(event.getEntity() instanceof ThrownTrident trident)) return;
        if (event.getLevel().isClientSide) return;

        if (trident.getPickupItem().getEnchantmentLevel(ModEnchantments.ETERNAL_LOYALTY.get()) <= 0) return;

        trident.getPersistentData().putBoolean("eternal_loyalty_arrow", true);
        trident.setRemainingFireTicks(0);
        trident.clearFire();
    }

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.level.isClientSide) return;
        if (event.phase == TickEvent.Phase.START) return;

        ServerLevel level = (ServerLevel) event.level;

        // 量子利刃：把到期的「生命上限扣除」修饰符摘掉，让上限恢复
        cn.autoforged.rainbow_enchantment_mod.enchantment.QuantumBladeEnchantment
            .tickMaxHpModifiers(level);

        // Process Eternal Loyalty ItemEntities (fire immunity like Netherite)
        if (!ETERNAL_LOYALTY_ITEM_ENTITIES.isEmpty()) {
            var dim = level.dimension();
            ETERNAL_LOYALTY_ITEM_ENTITIES.entrySet().removeIf(e -> {
                if (!e.getValue().equals(dim)) return false;
                Entity entity = level.getEntity(e.getKey());
                if (entity == null || !entity.isAlive()) return true;
                if (!(entity instanceof ItemEntity item)) return true;

                if (item.getItem().getEnchantmentLevel(ModEnchantments.ETERNAL_LOYALTY.get()) <= 0) return true;

                item.setRemainingFireTicks(0);
                item.clearFire();
                if (item.health < 5) {
                    item.health = 5;
                }
                // 永恒忠诚的物品还要「不掉落消失」。
                //
                // 【漏掉这一步会怎样】
                // ItemEntity.tick() 里有：
                //     if (!this.level().isClientSide && this.age >= lifespan) this.discard();
                // 默认 lifespan = 6000 tick（5 分钟）。原代码只处理了火焰免疫和 health，
                // 没管 age，所以带永恒忠诚的物品掉在地上 5 分钟后照样消失，
                // 表现为「永恒忠诚没有真正保住物品」。
                //
                // ItemEntity.setUnlimitedLifetime() 是原版公开 API，把 age 置为 -32768；
                // 而 tick() 里是 "if (this.age != -32768) ++this.age;"，于是年龄永远不再增长，
                // 也就永远不会触发消失判定。比自己反射改 age 更干净。
                item.setUnlimitedLifetime();
                return false;
            });
        }

        // Process Eternal Loyalty thrown tridents (every 20 ticks)
        if (level.getGameTime() % 20 == 0) {
            for (Entity entity : level.getEntities().getAll()) {
                if (!(entity instanceof ThrownTrident trident)) continue;
                if (!trident.getPersistentData().getBoolean("eternal_loyalty_arrow")) continue;

                trident.setRemainingFireTicks(0);
                trident.clearFire();

                if (trident.getY() < -64.0 && trident.getOwner() instanceof Player owner) {
                    trident.setPos(owner.getX(), owner.getY() + 2, owner.getZ());
                    trident.setDeltaMovement(Vec3.ZERO);
                    trident.setNoPhysics(true);
                }
            }
        }

        // 星光之力 / 千风之力 的演出推进：每 tick 发粒子 + 按"环扫到"结算伤害
        ParticleEffectManager.tick(level);

        // 冷却类静态表的过期清理（每 30 秒一次）。
        // 这些表以实体 UUID 为键、战斗时写入，不清理会随「打过的怪」无限增长。
        if (level.getGameTime() % 600 == 0) {
            pruneStaleCooldowns(level.getGameTime());
        }
    }

    private static void grantAdvancement(ServerPlayer player, String path) {
        Advancement advancement = player.server.getAdvancements()
            .getAdvancement(new ResourceLocation(RainbowEnchantmentMod.MOD_ID, path));
        if (advancement != null) {
            player.getAdvancements().award(advancement, "impossible");
        }
    }
}
