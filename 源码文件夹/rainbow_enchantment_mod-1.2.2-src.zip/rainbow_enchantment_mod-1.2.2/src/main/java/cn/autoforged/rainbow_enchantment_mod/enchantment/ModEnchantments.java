package cn.autoforged.rainbow_enchantment_mod.enchantment;

import cn.autoforged.rainbow_enchantment_mod.RainbowEnchantmentMod;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEnchantments {
    public static final DeferredRegister<Enchantment> ENCHANTMENTS =
        DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, RainbowEnchantmentMod.MOD_ID);

    public static final RegistryObject<Enchantment> FROST = ENCHANTMENTS.register("frost",
        () -> new FrostEnchantment(
            Enchantment.Rarity.RARE,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> RAINBOW = ENCHANTMENTS.register("rainbow",
        () -> new RainbowEnchantment(
            Enchantment.Rarity.VERY_RARE,
            EquipmentSlot.MAINHAND,
            EquipmentSlot.HEAD,
            EquipmentSlot.CHEST,
            EquipmentSlot.LEGS,
            EquipmentSlot.FEET
        ));

    public static final RegistryObject<Enchantment> BREAK = ENCHANTMENTS.register("break",
        () -> new BreakEnchantment(
            Enchantment.Rarity.RARE,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> NIGHT_WALKER = ENCHANTMENTS.register("night_walker",
        () -> new NightWalkerEnchantment(
            Enchantment.Rarity.VERY_RARE,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> OCEAN_STRIKE = ENCHANTMENTS.register("ocean_strike",
        () -> new OceanStrikeEnchantment(
            Enchantment.Rarity.RARE,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> FOREST_STRIKE = ENCHANTMENTS.register("forest_strike",
        () -> new ForestStrikeEnchantment(
            Enchantment.Rarity.RARE,
            EquipmentSlot.MAINHAND,
            EquipmentSlot.HEAD,
            EquipmentSlot.CHEST,
            EquipmentSlot.LEGS,
            EquipmentSlot.FEET
        ));

    public static final RegistryObject<Enchantment> ETERNAL_FLAME = ENCHANTMENTS.register("eternal_flame",
        () -> new EternalFlameEnchantment(
            Enchantment.Rarity.RARE,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> QUANTUM_BLADE = ENCHANTMENTS.register("quantum_blade",
        () -> new QuantumBladeEnchantment(
            Enchantment.Rarity.VERY_RARE,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> RUIN_FORCE = ENCHANTMENTS.register("ruin_force",
        () -> new RuinForceEnchantment(
            Enchantment.Rarity.RARE,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> IMMACULATE = ENCHANTMENTS.register("immaculate",
        () -> new ImmaculateEnchantment(
            Enchantment.Rarity.VERY_RARE,
            EquipmentSlot.HEAD,
            EquipmentSlot.CHEST,
            EquipmentSlot.LEGS,
            EquipmentSlot.FEET
        ));

    public static final RegistryObject<Enchantment> QUANTUM_ARROW = ENCHANTMENTS.register("quantum_arrow",
        () -> new QuantumArrowEnchantment(
            Enchantment.Rarity.RARE,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> STARLIGHT_FORCE = ENCHANTMENTS.register("starlight_force",
        () -> new StarlightForceEnchantment(
            Enchantment.Rarity.VERY_RARE,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> THOUSAND_WIND_FORCE = ENCHANTMENTS.register("thousand_wind_force",
        () -> new ThousandWindForceEnchantment(
            Enchantment.Rarity.VERY_RARE,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> JUDGMENT = ENCHANTMENTS.register("judgment",
        () -> new JudgmentEnchantment(
            Enchantment.Rarity.VERY_RARE,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> ETERNAL = ENCHANTMENTS.register("eternal",
        () -> new EternalEnchantment(
            Enchantment.Rarity.VERY_RARE,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> PLUNDER = ENCHANTMENTS.register("plunder",
        () -> new PlunderEnchantment(
            Enchantment.Rarity.RARE,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> DOUBLE = ENCHANTMENTS.register("double",
        () -> new DoubleEnchantment(
            Enchantment.Rarity.RARE,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> HARVEST = ENCHANTMENTS.register("harvest",
        () -> new HarvestEnchantment(
            Enchantment.Rarity.RARE,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> SUPER_LUCKY = ENCHANTMENTS.register("super_lucky",
        () -> new SuperLuckyEnchantment(
            Enchantment.Rarity.VERY_RARE,
            EquipmentSlot.MAINHAND,
            EquipmentSlot.HEAD,
            EquipmentSlot.CHEST,
            EquipmentSlot.LEGS,
            EquipmentSlot.FEET
        ));

    public static final RegistryObject<Enchantment> UNDYING = ENCHANTMENTS.register("undying",
        () -> new UndyingEnchantment(
            Enchantment.Rarity.VERY_RARE,
            EquipmentSlot.HEAD,
            EquipmentSlot.CHEST,
            EquipmentSlot.LEGS,
            EquipmentSlot.FEET
        ));

    public static final RegistryObject<Enchantment> OXYGEN = ENCHANTMENTS.register("oxygen",
        () -> new OxygenEnchantment(
            Enchantment.Rarity.UNCOMMON,
            EquipmentSlot.HEAD
        ));

    public static final RegistryObject<Enchantment> LAVA_WALKER = ENCHANTMENTS.register("lava_walker",
        () -> new LavaWalkerEnchantment(
            Enchantment.Rarity.RARE,
            EquipmentSlot.FEET
        ));

    public static final RegistryObject<Enchantment> GREAT_FORTUNE = ENCHANTMENTS.register("great_fortune",
        () -> new GreatFortuneEnchantment(
            Enchantment.Rarity.RARE,
            EquipmentSlot.FEET
        ));

    public static final RegistryObject<Enchantment> SEA_GOD_EXPLORER = ENCHANTMENTS.register("sea_god_explorer",
        () -> new SeaGodExplorerEnchantment(
            Enchantment.Rarity.RARE,
            EquipmentSlot.FEET
        ));

    public static final RegistryObject<Enchantment> ETERNAL_LOYALTY = ENCHANTMENTS.register("eternal_loyalty",
        () -> new EternalLoyaltyEnchantment(
            Enchantment.Rarity.VERY_RARE,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> BUTCHER = ENCHANTMENTS.register("butcher",
        () -> new ButcherEnchantment(
            Enchantment.Rarity.UNCOMMON,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> SUPER_NUKE = ENCHANTMENTS.register("super_nuke",
        () -> new SuperNukeEnchantment(
            Enchantment.Rarity.VERY_RARE,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> HUFF = ENCHANTMENTS.register("huff",
        () -> new HuffEnchantment(
            Enchantment.Rarity.UNCOMMON,
            EquipmentSlot.HEAD
        ));

    public static final RegistryObject<Enchantment> ENDER_GAZE = ENCHANTMENTS.register("ender_gaze",
        () -> new EnderGazeEnchantment(
            Enchantment.Rarity.RARE,
            EquipmentSlot.HEAD
        ));

    public static final RegistryObject<Enchantment> TREASURE_GATHERING = ENCHANTMENTS.register("treasure_gathering",
        () -> new TreasureGatheringEnchantment(
            Enchantment.Rarity.VERY_RARE,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> BARBARIAN_VANGUARD = ENCHANTMENTS.register("barbarian_vanguard",
        () -> new BarbarianVanguardEnchantment(
            Enchantment.Rarity.RARE,
            EquipmentSlot.HEAD
        ));

    public static final RegistryObject<Enchantment> SPACE_SLASH = ENCHANTMENTS.register("space_slash",
        () -> new SpaceSlashEnchantment(
            Enchantment.Rarity.VERY_RARE,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> STAR_TREASURE = ENCHANTMENTS.register("star_treasure",
        () -> new StarTreasureEnchantment(
            Enchantment.Rarity.VERY_RARE,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> CHERRY_BLOSSOM = ENCHANTMENTS.register("cherry_blossom",
        () -> new CherryBlossomEnchantment(
            Enchantment.Rarity.VERY_RARE,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> UNIVERSE_BREAKER = ENCHANTMENTS.register("universe_breaker",
        () -> new UniverseBreakerEnchantment(
            Enchantment.Rarity.VERY_RARE,
            EquipmentSlot.MAINHAND
        ));

    public static final RegistryObject<Enchantment> PERVERT = ENCHANTMENTS.register("pervert",
        () -> new PervertEnchantment(
            Enchantment.Rarity.RARE,
            EquipmentSlot.MAINHAND
        ));

    // 药水抗性：装备在胸甲上，降低负面效果的时长 / 效果等级。
    // 该类原先只写好了壳子却从未注册，导致附魔根本不存在于游戏里。
    public static final RegistryObject<Enchantment> POTION_RESISTANCE = ENCHANTMENTS.register("potion_resistance",
        () -> new PotionResistanceEnchantment(
            Enchantment.Rarity.RARE,
            EquipmentSlot.CHEST
        ));
}
