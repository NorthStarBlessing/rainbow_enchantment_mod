package cn.autoforged.rainbow_enchantment_mod.acquisition;

import cn.autoforged.rainbow_enchantment_mod.RainbowEnchantmentMod;
import com.mojang.serialization.Codec;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** 全局战利品修改器序列化器的注册。 */
public final class ModLootModifiers {
    public static final DeferredRegister<Codec<? extends IGlobalLootModifier>> SERIALIZERS =
        DeferredRegister.create(ForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS,
            RainbowEnchantmentMod.MOD_ID);

    public static final RegistryObject<Codec<SourceGateModifier>> SOURCE_GATE =
        SERIALIZERS.register("source_gate", () -> SourceGateModifier.CODEC);

    private ModLootModifiers() {
    }
}
