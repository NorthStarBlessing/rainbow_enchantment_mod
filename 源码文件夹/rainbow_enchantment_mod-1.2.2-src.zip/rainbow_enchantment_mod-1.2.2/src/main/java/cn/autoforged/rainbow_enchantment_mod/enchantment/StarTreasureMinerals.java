package cn.autoforged.rainbow_enchantment_mod.enchantment;

import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.Tags;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * 「星光财宝」的矿物注册表 —— 全模组唯一的一份数值来源。
 *
 * <p>锻造（{@code ModEvents#handleStarTreasureAnvil}）、属性计算
 * （{@code ModEvents#handleStarTreasureAttribute}）、最大耐久（{@code StarTreasureMixin}）
 * 与 tooltip（{@code ClientModEvents#handleStarTreasureTooltip}）都只读这张表，
 * 避免「几份数字各写一套、改一处漏几处」。
 *
 * <h2>数据模型</h2>
 * 物品 NBT 里 {@code star_treasure_data} 是一个复合标签，键为下面的 {@link #key}，
 * 值为该矿物已累积的<b>计数</b>：
 * <pre>{"iron": 12, "redstone": 3, "echo_shard": 1}</pre>
 *
 * <p><b>一块材料记 1 点，一个方块记 {@link #POINTS_PER_BLOCK_FORGE} 点。</b>
 * 这正是「铁块 = 铁锭的 10 倍」的实现方式，也是为什么这里只登记「每点增幅」一份数字：
 * 方块档 = 每点增幅 × 10，没有第二份数据需要同步。
 *
 * <h2>三类增幅</h2>
 * 每类矿物每 1 点计数带来的增幅：
 * <ul>
 *   <li>伤害：{@link #getDamageBonus()}</li>
 *   <li>速度：{@link #getSpeedBonus()}（只有红石）</li>
 *   <li>耐久：{@link #getDurabilityBonus()}</li>
 * </ul>
 * 回响碎片、石头、末地石、黑曜石、黑石、模组矿物没有方块形态，只有材料档。
 *
 * <h2>上限的语义</h2>
 * {@link #getLimit()} 是<b>该类矿物的计数上限</b>，不是最终属性上限。
 * 最终属性还要再受配置里的三项总上限（伤害 / 速度 / 耐久）二次封顶，
 * 这一步统一在 {@link #computeStats} 与 {@link #durabilityBonus} 里做。
 *
 * <h2>优先级</h2>
 * 精确表优先，标签兜底：先按 {@link #itemForms} / {@link #blockForms} 里的精确物品匹配，
 * 没命中再看它是不是「非原版命名空间的 {@code forge:ores} 方块」，是则归入 {@link #MOD_ORE}。
 */
public enum StarTreasureMinerals {
    /** 铁锭 / 铁块：每点耐久 +1，计数上限 1400。 */
    IRON("iron", 0.0, 0.0, 1.0,
        new Item[] {net.minecraft.world.item.Items.IRON_INGOT},
        new Item[] {net.minecraft.world.item.Items.IRON_BLOCK}),

    /** 钻石 / 钻石块：每点伤害 +0.1，计数上限 100。 */
    DIAMOND("diamond", 0.1, 0.0, 0.0,
        new Item[] {net.minecraft.world.item.Items.DIAMOND},
        new Item[] {net.minecraft.world.item.Items.DIAMOND_BLOCK}),

    /** 绿宝石 / 绿宝石块：每点耐久 +1，计数上限 1400。 */
    EMERALD("emerald", 0.0, 0.0, 1.0,
        new Item[] {net.minecraft.world.item.Items.EMERALD},
        new Item[] {net.minecraft.world.item.Items.EMERALD_BLOCK}),

    /** 紫水晶碎片 / 紫水晶块：每点伤害 +0.1，计数上限 100。 */
    AMETHYST("amethyst", 0.1, 0.0, 0.0,
        new Item[] {net.minecraft.world.item.Items.AMETHYST_SHARD},
        new Item[] {net.minecraft.world.item.Items.AMETHYST_BLOCK}),

    /** 红石 / 红石块：每点速度 +0.01，计数上限 600。整张表唯一的速度类。 */
    REDSTONE("redstone", 0.0, 0.01, 0.0,
        new Item[] {net.minecraft.world.item.Items.REDSTONE},
        new Item[] {net.minecraft.world.item.Items.REDSTONE_BLOCK}),

    /** 回响碎片：每点伤害 +10（默认，配置可改），计数上限 50。无方块形态。 */
    ECHO_SHARD("echo_shard", 10.0, 0.0, 0.0,
        new Item[] {net.minecraft.world.item.Items.ECHO_SHARD},
        new Item[0]),

    /** 萤石粉 / 萤石块：每点伤害 +0.01，计数上限 100。 */
    GLOWSTONE("glowstone", 0.01, 0.0, 0.0,
        new Item[] {net.minecraft.world.item.Items.GLOWSTONE_DUST},
        new Item[] {net.minecraft.world.item.Items.GLOWSTONE}),

    /** 石头 / 深板岩：每点耐久 +1，计数上限 100。无方块形态。 */
    STONE("stone", 0.0, 0.0, 1.0,
        new Item[] {net.minecraft.world.item.Items.STONE, net.minecraft.world.item.Items.DEEPSLATE},
        new Item[0]),

    /** 末地石：每点耐久 +1，计数上限 500。 */
    END_STONE("end_stone", 0.0, 0.0, 1.0,
        new Item[] {net.minecraft.world.item.Items.END_STONE},
        new Item[0]),

    /** 黑曜石 / 哭泣的黑曜石：每点耐久 +10，计数上限 500。 */
    OBSIDIAN("obsidian", 0.0, 0.0, 10.0,
        new Item[] {net.minecraft.world.item.Items.OBSIDIAN, net.minecraft.world.item.Items.CRYING_OBSIDIAN},
        new Item[0]),

    /** 黑石：每点耐久 +1，计数上限 100。 */
    BLACKSTONE("blackstone", 0.0, 0.0, 1.0,
        new Item[] {net.minecraft.world.item.Items.BLACKSTONE},
        new Item[0]),

    /** 下界合金锭 / 下界合金块：每点伤害 +0.1，计数上限 100。 */
    NETHERITE("netherite", 0.1, 0.0, 0.0,
        new Item[] {net.minecraft.world.item.Items.NETHERITE_INGOT},
        new Item[] {net.minecraft.world.item.Items.NETHERITE_BLOCK}),

    /** 青金石 / 青金石块：每点伤害 +0.01，计数上限 50。 */
    LAPIS("lapis", 0.01, 0.0, 0.0,
        new Item[] {net.minecraft.world.item.Items.LAPIS_LAZULI},
        new Item[] {net.minecraft.world.item.Items.LAPIS_BLOCK}),

    /** 下界石英 / 下界石英块：每点伤害 +0.1，计数上限 100。 */
    QUARTZ("quartz", 0.1, 0.0, 0.0,
        new Item[] {net.minecraft.world.item.Items.QUARTZ},
        new Item[] {net.minecraft.world.item.Items.QUARTZ_BLOCK}),

    /** 金锭 / 金块：每点耐久 +0.1，计数上限 150。 */
    GOLD("gold", 0.0, 0.0, 0.1,
        new Item[] {net.minecraft.world.item.Items.GOLD_INGOT},
        new Item[] {net.minecraft.world.item.Items.GOLD_BLOCK}),

    /** 铜锭 / 铜块：每点耐久 +0.1，计数上限 1000。 */
    COPPER("copper", 0.0, 0.0, 0.1,
        new Item[] {net.minecraft.world.item.Items.COPPER_INGOT},
        new Item[] {net.minecraft.world.item.Items.COPPER_BLOCK}),

    /** 兜底：非原版命名空间的 {@code forge:ores} 方块，每点伤害 +0.01，计数上限 1500。 */
    MOD_ORE("mod_ore", 0.01, 0.0, 0.0,
        new Item[0],
        new Item[0]);

    /** 一个「方块形态」的锻造计入多少点。材料一律记 1 点。 */
    public static final int POINTS_PER_BLOCK_FORGE = 10;

    /** NBT 键名，同时也是语言键 {@code star_treasure_mineral.<key>} 的后缀。 */
    private final String key;
    /** 每点计数带来的伤害增幅。 */
    private final double damagePerPoint;
    /** 每点计数带来的速度增幅。 */
    private final double speedPerPoint;
    /** 每点计数带来的耐久增幅。 */
    private final double durabilityPerPoint;
    /** 材料形态的物品。 */
    private final Item[] itemForms;
    /** 方块形态的物品。 */
    private final Item[] blockForms;

    StarTreasureMinerals(String key,
                         double damagePerPoint,
                         double speedPerPoint,
                         double durabilityPerPoint,
                         Item[] itemForms,
                         Item[] blockForms) {
        this.key = key;
        this.damagePerPoint = damagePerPoint;
        this.speedPerPoint = speedPerPoint;
        this.durabilityPerPoint = durabilityPerPoint;
        this.itemForms = itemForms;
        this.blockForms = blockForms;
    }

    // ══════════════════ 静态查表 ══════════════════

    /** 精确物品 → 枚举。 */
    private static final Map<Item, StarTreasureMinerals> BY_ITEM;
    /** 方块形态的物品（决定一次锻造记 10 点还是 1 点）。 */
    private static final Map<Item, StarTreasureMinerals> BY_BLOCK_FORM;

    static {
        Map<Item, StarTreasureMinerals> byItem = new LinkedHashMap<>();
        Map<Item, StarTreasureMinerals> byBlockForm = new LinkedHashMap<>();
        for (StarTreasureMinerals mineral : values()) {
            // putIfAbsent：万一两个常量误配了同一个物品，保留先声明的那条，不静默覆盖
            for (Item item : mineral.itemForms) {
                byItem.putIfAbsent(item, mineral);
            }
            for (Item block : mineral.blockForms) {
                byItem.putIfAbsent(block, mineral);
                byBlockForm.putIfAbsent(block, mineral);
            }
        }
        BY_ITEM = Collections.unmodifiableMap(byItem);
        BY_BLOCK_FORM = Collections.unmodifiableMap(byBlockForm);
    }

    /** 按声明顺序遍历（锻造、tooltip 都依赖这个顺序，保证展示稳定）。 */
    public static StarTreasureMinerals[] all() {
        return values();
    }

    /**
     * 找出这个物品属于哪类矿物 —— 锻造入口用的就是它。
     *
     * <p>顺序：精确表优先，{@code forge:ores} 标签兜底。精确表命中后不再看标签，
     * 所以原版矿石方块不会被误判成「模组矿物」。
     *
     * @return 命中的类别，未命中返回 null
     */
    @Nullable
    public static StarTreasureMinerals match(ItemStack stack) {
        if (stack.isEmpty()) return null;
        StarTreasureMinerals exact = BY_ITEM.get(stack.getItem());
        if (exact != null) return exact;
        if (isForeignOre(stack)) return MOD_ORE;
        return null;
    }

    /** 这个物品是方块形态吗（一次锻造记 {@link #POINTS_PER_BLOCK_FORGE} 点）。 */
    public static boolean isBlockForm(ItemStack stack) {
        return BY_BLOCK_FORM.containsKey(stack.getItem());
    }

    /**
     * 非原版命名空间的 {@code forge:ores} 方块 —— 即「模组矿物」。
     *
     * <p>用命名空间过滤而不是硬编码排除表：这样原版的煤炭矿石~深层钻石矿石全部排除，
     * 而任何模组注册的锡矿 / 铅矿 / 秘银矿都会自动被接手。
     */
    private static boolean isForeignOre(ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) return false;
        if (!blockItem.getBlock().defaultBlockState().is(Tags.Blocks.ORES)) return false;
        ResourceLocation id = ForgeRegistries.ITEMS.getKey(stack.getItem());
        return id != null && !"minecraft".equals(id.getNamespace());
    }

    // ══════════════════ 实例读取 ══════════════════

    public String getKey() {
        return key;
    }

    /** 每点计数的伤害增幅（回响碎片走配置，默认 10.0）。 */
    public double getDamageBonus() {
        return this == ECHO_SHARD ? echoShardDamagePerPoint() : damagePerPoint;
    }

    /** 每点计数的速度增幅。 */
    public double getSpeedBonus() {
        return speedPerPoint;
    }

    /** 每点计数的耐久增幅。 */
    public double getDurabilityBonus() {
        return durabilityPerPoint;
    }

    /** 这一项是不是耐久类（「消耗矿物修复」模式下挑消耗对象时用）。 */
    public boolean isDurabilityType() {
        return durabilityPerPoint > 0;
    }

    /**
     * 该类矿物的计数上限，从配置读。
     *
     * <p>配置尚未加载时（构造期 / 数据生成早期）返回 0，等价于「不允许锻造」，
     * 不会崩也不会给出错误上限。
     */
    public int getLimit() {
        try {
            var c = ModConfig.COMMON;
            return switch (this) {
                case IRON -> c.starTreasureMaxIron.get();
                case DIAMOND -> c.starTreasureMaxDiamond.get();
                case EMERALD -> c.starTreasureMaxEmerald.get();
                case AMETHYST -> c.starTreasureMaxAmethyst.get();
                case REDSTONE -> c.starTreasureMaxRedstone.get();
                case ECHO_SHARD -> c.starTreasureMaxEchoShard.get();
                case GLOWSTONE -> c.starTreasureMaxGlowstone.get();
                case STONE -> c.starTreasureMaxStone.get();
                case END_STONE -> c.starTreasureMaxEndStone.get();
                case OBSIDIAN -> c.starTreasureMaxObsidian.get();
                case BLACKSTONE -> c.starTreasureMaxBlackstone.get();
                case NETHERITE -> c.starTreasureMaxNetherite.get();
                case LAPIS -> c.starTreasureMaxLapis.get();
                case QUARTZ -> c.starTreasureMaxQuartz.get();
                case GOLD -> c.starTreasureMaxGold.get();
                case COPPER -> c.starTreasureMaxCopper.get();
                case MOD_ORE -> c.starTreasureMaxModOre.get();
            };
        } catch (Exception e) {
            return 0;
        }
    }

    /** 回响碎片的每点伤害走配置（默认 10.0，与其他矿物差两个量级，所以单独一个旋钮）。 */
    private static double echoShardDamagePerPoint() {
        try {
            return ModConfig.COMMON.starTreasureEchoShardDamage.get();
        } catch (Exception e) {
            return 10.0;
        }
    }

    // ══════════════════ 汇总计算 ══════════════════

    /**
     * 读取物品上某一类矿物的计数。
     *
     * @param data 已经取出的 {@code star_treasure_data} 复合标签，可为 null
     */
    public int getCount(@Nullable CompoundTag data) {
        if (data == null) return 0;
        return data.getInt(key);
    }

    /**
     * 从物品根标签取出某一类矿物的计数。
     *
     * @param itemTag 物品的根标签，可为 null
     */
    public static int countOf(@Nullable CompoundTag itemTag, StarTreasureMinerals mineral) {
        if (itemTag == null || !itemTag.contains(StarTreasureEnchantment.STAR_TREASURE_DATA_TAG, 10)) return 0;
        return mineral.getCount(itemTag.getCompound(StarTreasureEnchantment.STAR_TREASURE_DATA_TAG));
    }

    /**
     * 一次算清三类加成 —— 属性计算与 tooltip 都用它，保证两边永远一致。
     *
     * <p>流程：各类矿物「计数 × 每点增幅」累加 → 三类各自按配置的总上限截断。
     * 总上限截断放在这里，这样「计数上限」和「总上限」的双重限制
     * 在任何调用点都是同一套结果。
     */
    public static Stats computeStats(@Nullable CompoundTag itemTag) {
        double rawDamage = 0.0;
        double rawSpeed = 0.0;
        double rawDurability = 0.0;

        for (StarTreasureMinerals mineral : values()) {
            int count = countOf(itemTag, mineral);
            if (count <= 0) continue;
            rawDamage += count * mineral.getDamageBonus();
            rawSpeed += count * mineral.getSpeedBonus();
            rawDurability += count * mineral.getDurabilityBonus();
        }

        return new Stats(
            Math.min(rawDamage, totalMaxDamage()),
            Math.min(rawSpeed, totalMaxSpeed()),
            Math.min(rawDurability, totalMaxDurability()));
    }

    /** 三类加成的最终结果（已经过总上限截断）。 */
    public record Stats(double damage, double speed, double durability) {}

    /**
     * 只算耐久加成的点数（已按总上限截断）—— Mixin 注入 {@code getMaxDamage()} 时用。
     *
     * <p>比 {@link #computeStats} 便宜：耐久检查会被原版每次损耗耐久时调用，
     * 没必要顺带把伤害与速度也算一遍。
     *
     * <p>会把 {@code durability_mode} 一起判掉：只有 MAX_DAMAGE / BOTH 才返回非 0，
     * 于是 NONE / RESTORE_ON_BREAK 下最大耐久保持原样。
     *
     * @param itemTag 物品的根标签，可为 null
     * @return 应加到最大耐久上的点数，不生效时为 0
     */
    public static double durabilityBonus(@Nullable CompoundTag itemTag) {
        if (!durabilityMode().usesMaxDamage()) return 0.0;
        if (itemTag == null || !itemTag.contains(StarTreasureEnchantment.STAR_TREASURE_DATA_TAG, 10)) return 0.0;
        CompoundTag data = itemTag.getCompound(StarTreasureEnchantment.STAR_TREASURE_DATA_TAG);

        double raw = 0.0;
        for (StarTreasureMinerals mineral : values()) {
            int count = mineral.getCount(data);
            if (count > 0) raw += count * mineral.getDurabilityBonus();
        }
        return Math.min(raw, totalMaxDurability());
    }

    private static double totalMaxDamage() {
        try {
            return ModConfig.COMMON.starTreasureTotalMaxDamage.get();
        } catch (Exception e) {
            return 100.0;
        }
    }

    private static double totalMaxSpeed() {
        try {
            return ModConfig.COMMON.starTreasureTotalMaxSpeed.get();
        } catch (Exception e) {
            return 600.0;
        }
    }

    private static double totalMaxDurability() {
        try {
            return ModConfig.COMMON.starTreasureTotalMaxDurability.get();
        } catch (Exception e) {
            return 1400.0;
        }
    }

    // ══════════════════ 耐久模式 ══════════════════

    /**
     * 耐久加成的生效方式。
     *
     * <ul>
     *   <li>{@code MAX_DAMAGE}：由 {@code StarTreasureMixin} 把点数加到物品最大耐久上，
     *       是真正的「最大耐久 +N」，会体现在耐久条长度与 {@code hurtAndBreak} 的判据上；</li>
     *   <li>{@code RESTORE_ON_BREAK}：不改最大耐久，等武器耐久耗尽时消耗 1 点矿物把它救回来；</li>
     *   <li>{@code BOTH}：两者都做（默认）。最大耐久变高之后，真正耗尽时还有池子兜底；</li>
     *   <li>{@code NONE}：整体关闭耐久加成。</li>
     * </ul>
     */
    public enum DurabilityMode {
        /** 提升武器最大耐久（走 Mixin 注入 {@code ItemStack#getMaxDamage}）。 */
        MAX_DAMAGE,
        /** 耐久耗尽时消耗 1 点矿物、修复 1 点耐久。 */
        RESTORE_ON_BREAK,
        /** 两者都做（默认）。 */
        BOTH,
        /** 关闭耐久加成。 */
        NONE;

        /** 是否把点数加到最大耐久上。 */
        public boolean usesMaxDamage() {
            return this == MAX_DAMAGE || this == BOTH;
        }

        /** 是否启用「损坏时消耗矿物修复」。 */
        public boolean usesRestoreOnBreak() {
            return this == RESTORE_ON_BREAK || this == BOTH;
        }
    }

    /** 读配置里的耐久模式；值不合法或配置未加载时按 BOTH 处理。 */
    public static DurabilityMode durabilityMode() {
        try {
            String raw = ModConfig.COMMON.starTreasureDurabilityMode.get();
            if (raw == null) return DurabilityMode.BOTH;
            return switch (raw.trim().toUpperCase(java.util.Locale.ROOT)) {
                case "MAX_DAMAGE" -> DurabilityMode.MAX_DAMAGE;
                case "RESTORE_ON_BREAK" -> DurabilityMode.RESTORE_ON_BREAK;
                case "NONE" -> DurabilityMode.NONE;
                default -> DurabilityMode.BOTH;
            };
        } catch (Exception e) {
            return DurabilityMode.BOTH;
        }
    }

    /**
     * 「损坏时修复」模式下按固定优先级挑一个还有剩余计数的耐久类矿物来消耗。
     *
     * <p>声明顺序即优先级：铁 → 绿宝石 → 铜 → 金 → 黑曜石 → 末地石 → 黑石 → 石头。
     *
     * @return 挑中的类别，一件可消耗的都没有时返回 null
     */
    @Nullable
    public static StarTreasureMinerals pickDurabilityMineral(@Nullable CompoundTag itemTag) {
        for (StarTreasureMinerals mineral : values()) {
            if (mineral.isDurabilityType() && countOf(itemTag, mineral) > 0) {
                return mineral;
            }
        }
        return null;
    }
}
