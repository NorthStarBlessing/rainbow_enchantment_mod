package cn.autoforged.rainbow_enchantment_mod;

import cn.autoforged.rainbow_enchantment_mod.acquisition.ModLootEntries;
import cn.autoforged.rainbow_enchantment_mod.acquisition.ModLootModifiers;
import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import cn.autoforged.rainbow_enchantment_mod.effect.ModEffects;
import cn.autoforged.rainbow_enchantment_mod.enchantment.ModEnchantments;
import cn.autoforged.rainbow_enchantment_mod.network.ModNetwork;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig.Type;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(RainbowEnchantmentMod.MOD_ID)
public class RainbowEnchantmentMod {
    public static final String MOD_ID = "rainbow_enchantment_mod";

    public RainbowEnchantmentMod() {
        ModLoadingContext.get().registerConfig(Type.COMMON, ModConfig.COMMON_SPEC, MOD_ID + "-common.toml");

        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEnchantments.ENCHANTMENTS.register(modEventBus);
        ModEffects.EFFECTS.register(modEventBus);
        ModCreativeTab.CREATIVE_MODE_TABS.register(modEventBus);
        // 「游玩获取」用的自定义战利品条目类型（宝箱 / 钓鱼的获取判定）
        ModLootEntries.LOOT_POOL_ENTRY_TYPES.register(modEventBus);
        // 原版战利品闸门：剥掉不该出现在原版掉落里的本模组附魔
        ModLootModifiers.SERIALIZERS.register(modEventBus);

        // 网络通道：星光之力的「左键空气」是纯客户端事件，必须发包到服务端才能开演出
        modEventBus.addListener((FMLCommonSetupEvent event) -> event.enqueueWork(ModNetwork::register));
    }
}
