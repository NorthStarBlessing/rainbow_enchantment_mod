package cn.autoforged.rainbow_enchantment_mod.effect;

import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeMap;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

import java.util.UUID;

/**
 * 侵蚀（Corrosion）。
 *
 * <p>维护者口径：「攻击时给目标施加『侵蚀』效果，每秒按目标最大生命值百分比造成伤害。
 * 同时额外扣除目标当前最大生命上限」。
 *
 * <p><b>2026-10-12 修复</b>：本类以前<b>只造成伤害、完全没有削减生命上限</b> ——
 * 那正是 {@code QuantumBladeEnchantment.applyMaxHpDeduction} 注释里已经点名过的
 * 「用一发等量伤害冒充扣上限」的老写法（见本文件旧实现与 docs/BUGS.md 第 7 条）。
 * 所以维护者看到的现象是「侵蚀后目标最大生命值上限不减，疑似又改回去了」。
 *
 * <p><b>现在怎么做</b>：用 {@link MobEffect} 自带的属性修饰符生命周期钩子
 * ——{@link #addAttributeModifiers} 在效果被施加 / 刷新时调用、
 * {@link #removeAttributeModifiers} 在效果到期 / 被牛奶清除 / 目标死亡时调用
 * （反编译 {@code LivingEntity.java:1046}、{@code :1065-1066}、{@code :1078}，
 * 这三处都是无条件调用，不检查 {@code hasAttributeModifiers()}）。
 * 因此不需要自己维护「到期时间表 + 每 tick 扫描」，也不会漏掉任何移除路径。
 *
 * <p>扣减采用 {@code MULTIPLY_TOTAL}（比例），修饰符带有固定 UUID，
 * 施加前先 {@code removeModifier} 再 {@code getBaseValue()}，
 * 所以效果反复刷新也不会在上次已扣的基础上层层复利。
 * 效果结束时上限自动恢复。
 */
public class CorrosionEffect extends MobEffect {
    /** 侵蚀扣上限用的修饰符 ID。同一个实体同一时刻只会有一层侵蚀效果，因此固定 UUID 即可。 */
    private static final UUID MAX_HP_MODIFIER_ID =
        UUID.fromString("6f3a1c2e-9d4b-4b7a-8f21-5c0e7a1d9b30");
    private static final String MAX_HP_MODIFIER_NAME = "Corrosion max HP deduction";

    public CorrosionEffect(MobEffectCategory category, int color) {
        super(category, color);
    }

    @Override
    public void applyEffectTick(LivingEntity entity, int amplifier) {
        if (!entity.level().isClientSide) {
            float maxHp = entity.getMaxHealth();
            float damage = maxHp * ModConfig.COMMON.quantumBladeErosionPercent.get().floatValue();
            entity.hurt(entity.damageSources().magic(), damage);
        }
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        return duration % 20 == 0;
    }

    /**
     * 效果生效（施加 / 等级变化刷新）时：按配置比例扣掉目标的「生命上限」。
     */
    @Override
    public void addAttributeModifiers(LivingEntity entity, AttributeMap attributes, int amplifier) {
        super.addAttributeModifiers(entity, attributes, amplifier);

        AttributeInstance maxHealth = attributes.getInstance(Attributes.MAX_HEALTH);
        if (maxHealth == null) return;

        double deductionPct = ModConfig.COMMON.quantumBladeErosionPercent.get();
        if (deductionPct <= 0.0) return;

        // 先摘旧的再取 base：反复刷新不会在上次已扣的基础上再扣（避免复利）
        maxHealth.removeModifier(MAX_HP_MODIFIER_ID);
        double base = maxHealth.getBaseValue();
        // 等级越高扣得越多：amplifier 0 → 1 倍；并夹在 95% 以内，避免把上限压成 0
        double pct = Math.min(0.95, deductionPct * (amplifier + 1));
        double newMax = Math.max(1.0, base * (1.0 - pct));
        maxHealth.addTransientModifier(new AttributeModifier(
            MAX_HP_MODIFIER_ID, MAX_HP_MODIFIER_NAME,
            (newMax / Math.max(base, 1.0)) - 1.0, AttributeModifier.Operation.MULTIPLY_TOTAL));

        // 上限被扣到低于当前血量时夹一下，避免「血比上限还多」
        if (entity.getHealth() > newMax) {
            entity.setHealth((float) newMax);
        }
    }

    /**
     * 效果结束（到期 / 被清除 / 目标死亡）时：摘掉修饰符，把生命上限还原。
     */
    @Override
    public void removeAttributeModifiers(LivingEntity entity, AttributeMap attributes, int amplifier) {
        AttributeInstance maxHealth = attributes.getInstance(Attributes.MAX_HEALTH);
        if (maxHealth != null) {
            maxHealth.removeModifier(MAX_HP_MODIFIER_ID);
        }
        super.removeAttributeModifiers(entity, attributes, amplifier);
    }
}
