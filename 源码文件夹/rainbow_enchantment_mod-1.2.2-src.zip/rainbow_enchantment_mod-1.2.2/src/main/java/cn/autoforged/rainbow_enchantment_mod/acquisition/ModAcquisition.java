package cn.autoforged.rainbow_enchantment_mod.acquisition;

import cn.autoforged.rainbow_enchantment_mod.RainbowEnchantmentMod;
import cn.autoforged.rainbow_enchantment_mod.config.AcquisitionSection;
import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import cn.autoforged.rainbow_enchantment_mod.enchantment.ModEnchantments;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraftforge.registries.ForgeRegistries;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 获取核心：候选池 → 抽附魔 → 抽等级 → 折线取概率 → 幸运/超级幸运修正 → 掷骰。
 *
 * <p>候选池由 {@code [acquisition.exclusive]} 决定：
 * <ul>
 *   <li>通用池途径（古城/末地城/雪地/埋藏/钓鱼/送礼/村民）：只从「没有专属条目」的附魔里抽；</li>
 *   <li>专属途径（要塞图书馆/废弃传送门/唤魔者/凋灵/烈焰人/远古守卫者/附魔台/判决）：
 *       只从「专属条目里点名给它的」附魔里抽。</li>
 * </ul>
 *
 * <p>村庄英雄送礼的概率折线按**英雄效果等级**取值，其余战利品途径按附魔等级取值。
 */
public final class ModAcquisition {
    private static final Logger LOGGER = LogManager.getLogger();

    private ModAcquisition() {
    }

    // ==================================================================
    //                          配置读取
    // ==================================================================

    public static AcquisitionSection section() {
        return ModConfig.COMMON.acquisition;
    }

    public static AcquisitionSection.Source configFor(AcquisitionSource source) {
        AcquisitionSection acq = section();
        return switch (source) {
            case ANCIENT_CITY -> acq.ancientCity;
            case END_CITY -> acq.endCity;
            case SNOWY_CHEST -> acq.snowyChest;
            case BURIED_TREASURE -> acq.buriedTreasure;
            case FISHING -> acq.fishing;
            case HERO_GIFT -> acq.ancientCity;      // 送礼走 HeroGift 配置，这里只作兜底
            case STRONGHOLD_LIBRARY -> acq.strongholdLibrary;
            case RUINED_PORTAL -> acq.ruinedPortal;
        };
    }

    public static boolean enabled() {
        try {
            return section().enabled.get();
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean logRolls() {
        try {
            return section().logRolls.get() || ModConfig.COMMON.debugLog.get();
        } catch (Exception e) {
            return false;
        }
    }

    // ==================================================================
    //                          专属表
    // ==================================================================

    /** 解析 `[acquisition.exclusive]`：附魔短名 → 允许的来源 id 列表。 */
    public static Map<String, List<String>> exclusiveMap() {
        Map<String, List<String>> result = new LinkedHashMap<>();
        List<? extends String> raw;
        try {
            raw = section().exclusive.get();
        } catch (Exception e) {
            return result;
        }
        for (String entry : raw) {
            if (entry == null) {
                continue;
            }
            int eq = entry.indexOf('=');
            if (eq <= 0) {
                continue;
            }
            String enchant = shortName(entry.substring(0, eq).trim());
            List<String> sources = new ArrayList<>();
            for (String source : entry.substring(eq + 1).split(",")) {
                String trimmed = source.trim();
                if (!trimmed.isEmpty()) {
                    sources.add(trimmed);
                }
            }
            result.put(enchant, sources);
        }
        return result;
    }

    /** 去掉命名空间前缀（`rainbow_enchantment_mod:frost` → `frost`）。 */
    public static String shortName(String id) {
        int colon = id.indexOf(':');
        return colon < 0 ? id : id.substring(colon + 1);
    }

    // ==================================================================
    //                          附魔候选池
    // ==================================================================

    /** 全部「参与获取」的本模组附魔（已应用白/黑名单）。 */
    public static List<Enchantment> allCandidates() {
        List<? extends String> whitelist;
        List<? extends String> blacklist;
        try {
            whitelist = section().enchantmentWhitelist.get();
            blacklist = section().enchantmentBlacklist.get();
        } catch (Exception e) {
            whitelist = List.of();
            blacklist = List.of();
        }
        List<Enchantment> result = new ArrayList<>();
        for (Map.Entry<net.minecraft.resources.ResourceKey<Enchantment>, Enchantment> entry
                : ForgeRegistries.ENCHANTMENTS.getEntries()) {
            ResourceLocation key = entry.getKey().location();
            if (!RainbowEnchantmentMod.MOD_ID.equals(key.getNamespace())) {
                continue;
            }
            String id = key.toString();
            if (blacklist.contains(id) || blacklist.contains(key.getPath())) {
                continue;
            }
            if (!whitelist.isEmpty() && !whitelist.contains(id) && !whitelist.contains(key.getPath())) {
                continue;
            }
            result.add(entry.getValue());
        }
        return result;
    }

    /**
     * 某个来源可以产出的附魔池。
     *
     * @param dedicated true = 专属途径，只取「点名给它的」；false = 通用池，只取「没有专属条目的」
     */
    public static List<Enchantment> poolFor(String sourceId, boolean dedicated) {
        Map<String, List<String>> exclusive = exclusiveMap();
        List<Enchantment> result = new ArrayList<>();
        for (Enchantment enchantment : allCandidates()) {
            ResourceLocation key = ForgeRegistries.ENCHANTMENTS.getKey(enchantment);
            if (key == null) {
                continue;
            }
            List<String> allowed = exclusive.get(key.getPath());
            if (dedicated) {
                if (allowed != null && allowed.contains(sourceId)) {
                    result.add(enchantment);
                }
            } else if (allowed == null) {
                result.add(enchantment);
            }
        }
        return result;
    }

    /** 通用池（宝箱 / 钓鱼 / 送礼 / 村民交易都用它）。 */
    public static List<Enchantment> generalPool() {
        return poolFor("general", false);
    }

    /** 按稀有度权重（或等概率）挑一个附魔。 */
    public static Enchantment pickEnchantment(List<Enchantment> pool, RandomSource random) {
        boolean weighted;
        try {
            weighted = section().rarityWeight.get();
        } catch (Exception e) {
            weighted = true;
        }
        if (!weighted || pool.size() == 1) {
            return pool.get(random.nextInt(pool.size()));
        }
        int total = 0;
        for (Enchantment enchantment : pool) {
            total += Math.max(1, enchantment.getRarity().getWeight());
        }
        int roll = random.nextInt(total);
        for (Enchantment enchantment : pool) {
            roll -= Math.max(1, enchantment.getRarity().getWeight());
            if (roll < 0) {
                return enchantment;
            }
        }
        return pool.get(pool.size() - 1);
    }

    /** 按短名取本模组附魔（配置里写的名字）。 */
    @Nullable
    public static Enchantment byShortName(String name) {
        ResourceLocation id = new ResourceLocation(RainbowEnchantmentMod.MOD_ID, shortName(name));
        return ForgeRegistries.ENCHANTMENTS.getValue(id);
    }

    /** 该生物类型是否属于这条掉落途径。 */
    public static boolean matchesEntity(AcquisitionSection.MobDrop cfg, Entity entity) {
        ResourceLocation key = ForgeRegistries.ENTITY_TYPES.getKey(entity.getType());
        if (key == null) {
            return false;
        }
        try {
            for (String configured : cfg.entities.get()) {
                if (key.toString().equals(configured) || key.getPath().equals(configured)) {
                    return true;
                }
            }
        } catch (Exception ignored) {
            // 配置未加载
        }
        return false;
    }

    // ==================================================================
    //                          等级与概率
    // ==================================================================

    /** 在 [levelMin, upper] 内取一个等级；upper &lt; levelMin 时返回 0（不可产出）。 */
    public static int drawLevel(int levelMin, int configuredMax, int enchantMaxLevel, RandomSource random) {
        int upper = configuredMax > 0 ? Math.min(configuredMax, enchantMaxLevel) : enchantMaxLevel;
        int lower = Math.max(1, levelMin);
        if (upper < lower) {
            return 0;
        }
        return Mth.nextInt(random, lower, upper);
    }

    /** 折线求值：锚点之间线性插值，低于首锚点用首值，高于末锚点按 above 决定（负数 = 沿用末值）。 */
    private static double curveChance(int[] levels, double[] chances, double above, int level) {
        if (levels.length == 0) {
            return 0.0D;
        }
        if (level <= levels[0]) {
            return chances[0];
        }
        for (int i = 1; i < levels.length; i++) {
            if (level <= levels[i]) {
                int span = levels[i] - levels[i - 1];
                if (span <= 0) {
                    return chances[i];
                }
                double t = (double) (level - levels[i - 1]) / (double) span;
                return chances[i - 1] + t * (chances[i] - chances[i - 1]);
            }
        }
        return above < 0.0D ? chances[chances.length - 1] : above;
    }

    private static int[] ints(List<? extends Integer> list) {
        int[] result = new int[list.size()];
        for (int i = 0; i < list.size(); i++) {
            Integer value = list.get(i);
            result[i] = value == null ? 0 : value;
        }
        return result;
    }

    private static double[] doubles(List<? extends Double> list) {
        double[] result = new double[list.size()];
        for (int i = 0; i < list.size(); i++) {
            Double value = list.get(i);
            result[i] = value == null ? 0.0D : value;
        }
        return result;
    }

    /** 战利品途径：按附魔等级取概率。 */
    public static double baseChance(AcquisitionSection.Source cfg, int level) {
        try {
            double above = cfg.aboveLastLevelChance.get();
            return curveChance(ints(cfg.curveLevels.get()), doubles(cfg.curveChances.get()), above, level);
        } catch (Exception e) {
            return 0.0D;
        }
    }

    /** 送礼途径：按村庄英雄等级取概率。 */
    public static double heroChance(AcquisitionSection.HeroGift cfg, int heroLevel) {
        try {
            double above = cfg.aboveLastLevelChance.get();
            return curveChance(ints(cfg.heroLevels.get()), doubles(cfg.heroChances.get()), above, heroLevel);
        } catch (Exception e) {
            return 0.0D;
        }
    }

    // ==================================================================
    //                          修正项
    // ==================================================================

    @Nullable
    public static Player playerOf(LootContext context) {
        Entity entity = context.getParamOrNull(LootContextParams.THIS_ENTITY);
        if (entity instanceof Player player) {
            return player;
        }
        entity = context.getParamOrNull(LootContextParams.KILLER_ENTITY);
        if (entity instanceof Player player) {
            return player;
        }
        return null;
    }

    /** 幸运修正后的概率（幸运来自战利品上下文 / 击杀者玩家）。 */
    public static double applyLuck(double chance, float luck) {
        double perPoint;
        try {
            perPoint = section().luckBonusPerPoint.get();
        } catch (Exception e) {
            perPoint = 0.05D;
        }
        return Mth.clamp(chance * (1.0D + (double) luck * perPoint), 0.0D, 1.0D);
    }

    /** 超级幸运修正后的概率。 */
    public static double applySuperLucky(double chance, @Nullable Player player, RandomSource random) {
        if (player == null) {
            return chance;
        }
        int level = EnchantmentHelper.getEnchantmentLevel(ModEnchantments.SUPER_LUCKY.get(), player);
        if (level <= 0) {
            return chance;
        }
        boolean usesOwnChance;
        double multiplier;
        try {
            usesOwnChance = section().superLuckyUsesOwnChance.get();
            multiplier = section().superLuckyMultiplier.get();
        } catch (Exception e) {
            usesOwnChance = false;
            multiplier = 2.0D;
        }
        if (usesOwnChance && random.nextDouble() >= superLuckyOwnDoubleChance(level)) {
            return chance;
        }
        return Mth.clamp(chance * multiplier, 0.0D, 1.0D);
    }

    /** 借用「超级幸运」自身配置里的翻倍概率：1 级到满级之间线性过渡。 */
    private static double superLuckyOwnDoubleChance(int level) {
        double level1;
        double max;
        int maxLevel;
        try {
            level1 = ModConfig.COMMON.luckyDoubleChanceLevel1.get();
            max = ModConfig.COMMON.luckyDoubleChanceMax.get();
            maxLevel = ModEnchantments.SUPER_LUCKY.get().getMaxLevel();
        } catch (Exception e) {
            return 0.0D;
        }
        if (maxLevel <= 1) {
            return level1;
        }
        double t = Mth.clamp((double) (level - 1) / (double) (maxLevel - 1), 0.0D, 1.0D);
        return level1 + t * (max - level1);
    }

    private static void log(String source, @Nullable Enchantment enchantment, int level, double chance, boolean hit) {
        if (!logRolls()) {
            return;
        }
        LOGGER.info("[RainbowEnchantment] 获取判定 来源={} 附魔={} 等级={} 概率={} 命中={}",
            source, enchantment == null ? "-" : ForgeRegistries.ENCHANTMENTS.getKey(enchantment), level,
            String.format("%.4f", chance), hit);
    }

    // ==================================================================
    //                          战利品表途径
    // ==================================================================

    /**
     * 战利品表途径的一次判定。
     *
     * @return 命中时返回一本附魔书，否则 {@link ItemStack#EMPTY}
     */
    public static ItemStack roll(AcquisitionSource source, LootContext context) {
        if (!enabled()) {
            return ItemStack.EMPTY;
        }
        if (source == AcquisitionSource.HERO_GIFT) {
            return rollHeroGift(context);
        }
        AcquisitionSection.Source cfg = configFor(source);
        try {
            if (!cfg.enabled.get()) {
                return ItemStack.EMPTY;
            }
        } catch (Exception e) {
            return ItemStack.EMPTY;
        }
        int levelMin;
        int levelMax;
        try {
            levelMin = cfg.levelMin.get();
            levelMax = cfg.levelMax.get();
        } catch (Exception e) {
            return ItemStack.EMPTY;
        }
        List<Enchantment> pool = poolFor(source.id(), source.dedicated());
        if (pool.isEmpty()) {
            return ItemStack.EMPTY;
        }
        RandomSource random = context.getRandom();
        Enchantment enchantment = pickEnchantment(pool, random);
        int level = drawLevel(levelMin, levelMax, enchantment.getMaxLevel(), random);
        if (level <= 0) {
            return ItemStack.EMPTY;
        }
        double chance = baseChance(cfg, level);
        chance = applyLuck(chance, context.getLuck());
        if (context.getParamOrNull(LootContextParams.THIS_ENTITY) instanceof Villager) {
            chance = applySuperLucky(chance, heroOf(context), random);   // 送礼：玩家不在上下文里
        } else {
            chance = applySuperLucky(chance, playerOf(context), random);
        }
        boolean hit = chance > 0.0D && random.nextDouble() < chance;
        log(source.id(), enchantment, level, chance, hit);
        return hit ? EnchantedBookItem.createForEnchantment(new EnchantmentInstance(enchantment, level))
                   : ItemStack.EMPTY;
    }

    /** 村庄英雄送礼：概率按英雄等级取，候选池是通用池。 */
    private static ItemStack rollHeroGift(LootContext context) {
        AcquisitionSection.HeroGift cfg = section().heroGift;
        try {
            if (!cfg.enabled.get()) {
                return ItemStack.EMPTY;
            }
        } catch (Exception e) {
            return ItemStack.EMPTY;
        }
        Player hero = heroOf(context);
        int heroLevel = hero == null ? 0 : heroLevel(hero);
        if (heroLevel <= 0) {
            return ItemStack.EMPTY;
        }
        int levelMin;
        int levelMax;
        try {
            levelMin = cfg.enchantLevelMin.get();
            levelMax = cfg.enchantLevelMax.get();
        } catch (Exception e) {
            return ItemStack.EMPTY;
        }
        List<Enchantment> pool = generalPool();
        if (pool.isEmpty()) {
            return ItemStack.EMPTY;
        }
        RandomSource random = context.getRandom();
        Enchantment enchantment = pickEnchantment(pool, random);
        int level = drawLevel(levelMin, levelMax, enchantment.getMaxLevel(), random);
        if (level <= 0) {
            return ItemStack.EMPTY;
        }
        double chance = heroChance(cfg, heroLevel);
        chance = applyLuck(chance, context.getLuck());
        boolean superLucky;
        try {
            superLucky = cfg.superLuckyApplies.get();
        } catch (Exception e) {
            superLucky = true;
        }
        if (superLucky) {
            chance = applySuperLucky(chance, hero, random);
        }
        boolean hit = chance > 0.0D && random.nextDouble() < chance;
        log(AcquisitionSource.HERO_GIFT.id() + "/英雄" + heroLevel, enchantment, level, chance, hit);
        return hit ? EnchantedBookItem.createForEnchantment(new EnchantmentInstance(enchantment, level))
                   : ItemStack.EMPTY;
    }

    /** 从「送礼的村民」找到正在收礼的英雄玩家（原版上下文里只传了村民）。 */
    @Nullable
    public static Player heroOf(LootContext context) {
        if (!(context.getParamOrNull(LootContextParams.THIS_ENTITY) instanceof Villager villager)) {
            return null;
        }
        Optional<Player> visible = villager.getBrain().getMemory(MemoryModuleType.NEAREST_VISIBLE_PLAYER)
            .filter(p -> p.hasEffect(MobEffects.HERO_OF_THE_VILLAGE));
        if (visible.isPresent()) {
            return visible.get();
        }
        return villager.getBrain().getMemory(MemoryModuleType.INTERACTION_TARGET)
            .filter(e -> e instanceof Player)
            .map(e -> (Player) e)
            .filter(p -> p.hasEffect(MobEffects.HERO_OF_THE_VILLAGE))
            .orElse(null);
    }

    /** 村庄英雄效果等级（1 起算）；没有该效果时返回 0。 */
    public static int heroLevel(Player player) {
        var effect = player.getEffect(MobEffects.HERO_OF_THE_VILLAGE);
        return effect == null ? 0 : effect.getAmplifier() + 1;
    }

    // ==================================================================
    //                          生物掉落途径
    // ==================================================================

    /**
     * 生物掉落的一次判定。
     *
     * @param killer       击杀者玩家（可为 null，例如非玩家击杀）
     * @param lootingLevel 抢夺等级
     * @return 命中时返回一本附魔书，否则 null
     */
    @Nullable
    public static ItemStack rollMob(MobSource source, ServerLevel level, @Nullable Player killer, int lootingLevel) {
        if (!enabled()) {
            return null;
        }
        AcquisitionSection.MobDrop cfg = source.config();
        boolean enabled;
        double baseChance;
        int levelMin;
        int levelMax;
        boolean lootingEffect;
        double lootingBonus;
        boolean playerKillOnly;
        try {
            enabled = cfg.enabled.get();
            baseChance = cfg.chance.get();
            levelMin = cfg.levelMin.get();
            levelMax = cfg.levelMax.get();
            lootingEffect = cfg.lootingEffect.get();
            lootingBonus = cfg.lootingBonusPerLevel.get();
            playerKillOnly = cfg.playerKillOnly.get();
        } catch (Exception e) {
            return null;
        }
        if (!enabled || (playerKillOnly && killer == null)) {
            return null;
        }
        List<Enchantment> pool = poolFor(source.id(), true);
        if (pool.isEmpty()) {
            return null;
        }
        RandomSource random = level.getRandom();
        Enchantment enchantment = pickEnchantment(pool, random);
        int enchantLevel = drawLevel(levelMin, levelMax, enchantment.getMaxLevel(), random);
        if (enchantLevel <= 0) {
            return null;
        }
        double chance = baseChance;
        if (killer != null) {
            chance = applyLuck(chance, killer.getLuck());
        }
        if (lootingEffect && lootingLevel > 0) {
            chance = Mth.clamp(chance * (1.0D + lootingBonus * lootingLevel), 0.0D, 1.0D);
        }
        boolean hit = chance > 0.0D && random.nextDouble() < chance;
        log(source.id(), enchantment, enchantLevel, chance, hit);
        return hit ? EnchantedBookItem.createForEnchantment(new EnchantmentInstance(enchantment, enchantLevel))
                   : null;
    }

    // ==================================================================
    //                          附魔台两条隐藏机制
    // ==================================================================

    /**
     * 附魔完成时调用：判定「15.55% 追加判决」。
     *
     * <p>满级附魔台的 7 个附魔**不走这里** —— 它们由 {@link ModEnchantTableState} 作为
     * 正常候选放进附魔池（会出现在三档预览里），详见该类的说明。
     *
     * <p>必须在原版把附魔写进物品**之前**调用（`PlayerXpEvent.LevelChange` 正好是那个时机）。
     *
     * @param power 当前附魔台的书架威力（0~15）
     */
    public static void applyEnchantingBonuses(Player player, ItemStack stack, int power, RandomSource random) {
        if (!enabled() || stack.isEmpty()) {
            return;
        }
        applyJudgment(player, stack, power, random);
    }

    private static void applyJudgment(Player player, ItemStack stack, int power, RandomSource random) {
        AcquisitionSection.BonusEnchant cfg = section().bonusEnchant;
        try {
            if (!cfg.enabled.get()) {
                return;
            }
        } catch (Exception e) {
            return;
        }
        double chance;
        int[] levelMin;
        int[] levelMax;
        boolean keepHigher;
        Enchantment judgment;
        try {
            chance = cfg.chance.get();
            levelMin = ints(cfg.levelMinByPower.get());
            levelMax = ints(cfg.levelMaxByPower.get());
            keepHigher = cfg.keepHigher.get();
            judgment = byShortName(cfg.enchantment.get());
        } catch (Exception e) {
            return;
        }
        if (judgment == null || random.nextDouble() >= chance) {
            return;
        }
        int index = Mth.clamp(power, 0, Math.min(levelMin.length, levelMax.length) - 1);
        if (index < 0) {
            return;
        }
        int min = Math.max(1, levelMin[index]);
        int max = Math.max(min, levelMax[index]);
        int level = Mth.nextInt(random, min, max);
        applyEnchant(stack, judgment, level, keepHigher);
        log("bonus_enchant", judgment, level, chance, true);
    }

    /** 把附魔写进物品：书走 StoredEnchantments，普通物品走 Enchantments；keepHigher 时只升不降。 */
    public static void applyEnchant(ItemStack stack, Enchantment enchantment, int level, boolean keepHigher) {
        if (keepHigher && currentLevel(stack, enchantment) >= level) {
            return;
        }
        if (stack.is(Items.BOOK) || stack.is(Items.ENCHANTED_BOOK)) {
            EnchantedBookItem.addEnchantment(stack, new EnchantmentInstance(enchantment, level));
        } else {
            stack.enchant(enchantment, level);
        }
    }

    /** 取物品上该附魔的当前等级（{@code EnchantmentHelper.getEnchantments} 同时兼容附魔书的 StoredEnchantments）。 */
    public static int currentLevel(ItemStack stack, Enchantment enchantment) {
        try {
            return EnchantmentHelper.getEnchantments(stack).getOrDefault(enchantment, 0);
        } catch (Exception e) {
            return 0;
        }
    }

    /** 供村民交易用的抽取：不掷骰子，只挑「附魔 + 等级」。 */
    @Nullable
    public static EnchantmentInstance pickInstance(int levelMin, int levelMax, RandomSource random) {
        List<Enchantment> pool = generalPool();
        if (pool.isEmpty()) {
            return null;
        }
        Enchantment enchantment = pickEnchantment(pool, random);
        int level = drawLevel(levelMin, levelMax, enchantment.getMaxLevel(), random);
        if (level <= 0) {
            return null;
        }
        return new EnchantmentInstance(enchantment, level);
    }

    /** 组合成一本附魔书。 */
    public static ItemStack bookOf(EnchantmentInstance instance) {
        return EnchantedBookItem.createForEnchantment(instance);
    }

    // ==================================================================
    //                 原版战利品闸门（全局战利品修改器用）
    // ==================================================================

    /** `vanilla_sources.allow_vanilla_random_loot = true` 时放行原版随机附魔。 */
    public static boolean vanillaRandomLootAllowed() {
        try {
            return section().allowVanillaRandomLoot.get();
        } catch (Exception e) {
            return false;
        }
    }

    /** 通用池途径（这些途径可以产出「没有专属条目」的附魔）。 */
    public static boolean isGeneralSource(String sourceId) {
        for (AcquisitionSource source : AcquisitionSource.values()) {
            if (!source.dedicated() && source.id().equals(sourceId)) {
                return true;
            }
        }
        return "librarian".equals(sourceId);
    }

    /** 战利品表 id → 我们给它挂的途径 id；不是我们的表则返回 null。 */
    @Nullable
    public static String sourceIdForLootTable(ResourceLocation tableId) {
        if (tableId == null) {
            return null;
        }
        String id = tableId.toString();
        try {
            AcquisitionSection acq = section();
            for (AcquisitionSource source : AcquisitionSource.values()) {
                List<? extends String> tables;
                boolean enabled;
                if (source == AcquisitionSource.HERO_GIFT) {
                    enabled = acq.heroGift.enabled.get();
                    tables = acq.heroGift.lootTables.get();
                } else {
                    AcquisitionSection.Source cfg = configFor(source);
                    enabled = cfg.enabled.get();
                    tables = cfg.lootTables.get();
                }
                if (!enabled) {
                    continue;
                }
                for (String configured : tables) {
                    if (id.equals(configured)) {
                        return source.id();
                    }
                }
            }
        } catch (Exception ignored) {
            // 配置未加载
        }
        return null;
    }

    /**
     * 剥掉「在当前来源下不合法」的本模组附魔。
     *
     * @param sourceId 当前战利品表对应的途径；null = 不是我们注入的表（本模组附魔一律视为泄漏）
     * @return null 表示整件物品应当从掉落里移除；等于原对象表示没动；否则是替换用的新栈
     */
    @Nullable
    public static ItemStack stripLeakedEnchantments(ItemStack stack, @Nullable String sourceId) {
        if (stack == null || stack.isEmpty()) {
            return stack;
        }
        Map<String, List<String>> exclusive = exclusiveMap();
        if (stack.is(Items.ENCHANTED_BOOK)) {
            ListTag stored = EnchantedBookItem.getEnchantments(stack);
            ListTag filtered = new ListTag();
            boolean removed = false;
            for (int i = 0; i < stored.size(); i++) {
                CompoundTag tag = stored.getCompound(i);
                if (isLeaked(ResourceLocation.tryParse(tag.getString("id")), sourceId, exclusive)) {
                    removed = true;
                    continue;
                }
                filtered.add(tag.copy());
            }
            if (!removed) {
                return stack;
            }
            if (filtered.isEmpty()) {
                return null;   // 整本书都是泄漏附魔：直接不掉
            }
            ItemStack copy = stack.copy();
            copy.getOrCreateTag().put("StoredEnchantments", filtered);
            return copy;
        }
        Map<Enchantment, Integer> enchantments = EnchantmentHelper.getEnchantments(stack);
        if (enchantments.isEmpty()) {
            return stack;
        }
        Map<Enchantment, Integer> kept = new LinkedHashMap<>();
        boolean removed = false;
        for (Map.Entry<Enchantment, Integer> entry : enchantments.entrySet()) {
            if (isLeaked(ForgeRegistries.ENCHANTMENTS.getKey(entry.getKey()), sourceId, exclusive)) {
                removed = true;
                continue;
            }
            kept.put(entry.getKey(), entry.getValue());
        }
        if (!removed) {
            return stack;
        }
        ItemStack copy = stack.copy();
        EnchantmentHelper.setEnchantments(kept, copy);
        if (kept.isEmpty()) {
            copy.removeTagKey("Enchantments");
        }
        return copy;
    }

    private static boolean isLeaked(@Nullable ResourceLocation id, @Nullable String sourceId,
                                    Map<String, List<String>> exclusive) {
        if (id == null || !RainbowEnchantmentMod.MOD_ID.equals(id.getNamespace())) {
            return false;
        }
        return !allowedFor(id.getPath(), sourceId, exclusive);
    }

    private static boolean allowedFor(String path, @Nullable String sourceId,
                                      Map<String, List<String>> exclusive) {
        if (sourceId == null) {
            return false;   // 不是我们的表 => 本模组附魔一律剥掉
        }
        List<String> allowed = exclusive.get(path);
        if (allowed != null) {
            return allowed.contains(sourceId);
        }
        return isGeneralSource(sourceId);   // 通用池附魔：只有在我们自己的通用途径上才合法
    }
}
