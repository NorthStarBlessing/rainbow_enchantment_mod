package cn.autoforged.rainbow_enchantment_mod.mixin;

import cn.autoforged.rainbow_enchantment_mod.enchantment.ModEnchantments;
import cn.autoforged.rainbow_enchantment_mod.enchantment.StarTreasureMinerals;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 星光财宝「耐久 +N」的真正实现：把耐久池的点数加到物品的最大耐久上。
 *
 * <h2>为什么需要 Mixin</h2>
 * Forge 1.20.1 没有任何出口能改大物品的最大耐久：
 * <ul>
 *   <li>属性系统的 {@code MAX_DAMAGE} 是 Minecraft 1.21 才加的，1.20.1 的 {@code Attributes} 没有；</li>
 *   <li>{@code ItemStack#getMaxDamage()} 不是可覆写的扩展点，也没有对应事件；</li>
 *   <li>{@code ItemAttributeModifierEvent} 的修饰符只作用于实体属性，没有物品耐久属性。</li>
 * </ul>
 * 所以只能注入 {@code getMaxDamage()}，这是唯一能同时影响原版耐久消耗
 * （{@code ItemStack#hurtAndBreak} 用的是 {@code getMaxDamage()}）与耐久条渲染的位置。
 *
 * <h2>注入方式</h2>
 * 没有用 {@code @ModifyReturnValue}：那个注解在 MixinExtras 里，
 * 而 Forge 1.20.1 尚未内置 MixinExtras，引入它等于多一个模组依赖。
 * 这里改用原版 Mixin 的 {@code @Inject(at = @At("RETURN"), cancellable = true)}，
 * 效果相同且零额外依赖。
 *
 * <h2>边界</h2>
 * 只处理「有该附魔、且 NBT 里记着矿物、且 durability_mode 允许」的物品，其余一律放行返回原值。
 * 数值走 {@link StarTreasureMinerals#durabilityBonus}，与 tooltip 显示同一套口径。
 */
@Mixin(ItemStack.class)
public abstract class StarTreasureMixin {

    /** 物品的根 NBT —— 用真实字段名，@Shadow 会按目标类解析。 */
    @Shadow
    private net.minecraft.nbt.CompoundTag tag;

    @Inject(method = "getMaxDamage", at = @At("RETURN"), cancellable = true)
    private void rainbow_enchantment_mod$starTreasureMaxDamage(CallbackInfoReturnable<Integer> cir) {
        // @Shadow 出来的字段是目标类里那个真实的 tag，等价于 this.getTag()
        var rootTag = this.tag;
        if (rootTag == null) return;

        // 没这个附魔就别算（避免给所有带 star_treasure_data 的杂项物品加耐久）。
        //
        // RegistryObject#get() 在注册表尚未就绪时会抛异常，而 getMaxDamage 是会被
        // 早期加载路径调用的方法（例如物品自带 NBT 解析）。所以这里一律包起来：
        // 拿不到就直接放行返回原值，绝不让一个装饰性的耐久加成把启动搞崩。
        int enchantLevel;
        try {
            var enchantment = ModEnchantments.STAR_TREASURE.get();
            if (enchantment == null) return;
            ItemStack self = (ItemStack) (Object) this;
            enchantLevel = self.getEnchantmentLevel(enchantment);
        } catch (Throwable ignored) {
            return;
        }
        if (enchantLevel <= 0) return;

        // durability_mode 的判定在 durabilityBonus 里（NONE / RESTORE_ON_BREAK 会返回 0）
        double bonus = StarTreasureMinerals.durabilityBonus(rootTag);
        if (bonus <= 0) return;

        int extra = (int) Math.round(bonus);
        if (extra <= 0) return;

        // 用 long 相加再夹到 int 范围，防止配置被改成天文数字后溢出成负数
        long total = (long) cir.getReturnValueI() + extra;
        cir.setReturnValue((int) Math.min(Integer.MAX_VALUE, total));
    }
}
