package cn.autoforged.rainbow_enchantment_mod.effect;

import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import cn.autoforged.rainbow_enchantment_mod.enchantment.FrostEnchantment;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;

public class ColdEffect extends MobEffect {
    public ColdEffect(MobEffectCategory category, int color) {
        super(category, color);
    }

    @Override
    public void applyEffectTick(LivingEntity entity, int amplifier) {
        if (!entity.level().isClientSide) {
            int actualAmplifier = amplifier;
            boolean nightWalkerBoost = false;
            if (amplifier >= FrostEnchantment.NIGHT_WALKER_AMPLIFIER_FLAG) {
                nightWalkerBoost = true;
                actualAmplifier = amplifier - FrostEnchantment.NIGHT_WALKER_AMPLIFIER_FLAG;
            }

            float damage = ModConfig.COMMON.frostBaseDamagePerSecond.get();
            if (entity.fireImmune()) {
                damage *= 2;
            }
            if (nightWalkerBoost) {
                damage *= ModConfig.COMMON.frostNightWalkerMultiplier.get().floatValue();
            }
            boolean hasDeepSea = entity.hasEffect(ModEffects.DEEP_SEA.get());
            boolean deepSeaBoost = hasDeepSea && !entity.isInWaterOrRain();
            if (deepSeaBoost) {
                damage *= 1.2f;
            }
            entity.hurt(entity.damageSources().magic(), damage);

            if (entity.isOnFire() && entity.tickCount % 20 == 0) {
                double multiplier = ModConfig.COMMON.frostFireInteractionMultiplier.get();
                int frostLevel = actualAmplifier + 1;
                float extraDamage = (float) (frostLevel * multiplier);
                if (deepSeaBoost) {
                    extraDamage *= 1.2f;
                }
                entity.hurt(entity.damageSources().magic(), extraDamage);
            }
        }
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        int actualAmplifier = amplifier >= FrostEnchantment.NIGHT_WALKER_AMPLIFIER_FLAG
            ? amplifier - FrostEnchantment.NIGHT_WALKER_AMPLIFIER_FLAG : amplifier;
        java.util.List<? extends Integer> intervals = ModConfig.COMMON.frostDamageIntervalTicks.get();
        int index = Math.min(actualAmplifier, intervals.size() - 1);
        int interval = intervals.get(index);
        if (interval < 1) interval = 1;
        return duration % interval == 0;
    }
}
