package cn.autoforged.rainbow_enchantment_mod.acquisition;

import cn.autoforged.rainbow_enchantment_mod.RainbowEnchantmentMod;
import cn.autoforged.rainbow_enchantment_mod.config.AcquisitionSection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.entity.npc.VillagerTrades;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;
import net.minecraftforge.event.LootTableLoadEvent;
import net.minecraftforge.event.village.VillagerTradesEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 把「战利品表类获取途径」挂进原版世界：
 * <ul>
 *   <li>{@link LootTableLoadEvent}：给配置里列出的宝箱 / 钓鱼 / 送礼表补一个专属战利品池；</li>
 *   <li>{@link VillagerTradesEvent}：给图书管理员 1~5 级各挂一条附魔书交易。</li>
 * </ul>
 */
@Mod.EventBusSubscriber(modid = RainbowEnchantmentMod.MOD_ID)
public final class AcquisitionHandler {
    private static final Logger LOGGER = LogManager.getLogger();
    private static final ResourceLocation LIBRARIAN =
        new ResourceLocation("minecraft", "librarian");

    private AcquisitionHandler() {
    }

    @SubscribeEvent
    public static void onLootTableLoad(LootTableLoadEvent event) {
        if (!ModAcquisition.enabled()) {
            return;
        }
        String poolName = null;
        AcquisitionSource source = sourceForTable(event.getName());
        if (source == null) {
            return;
        }
        poolName = RainbowEnchantmentMod.MOD_ID + ":acquisition/" + source.id();
        if (event.getTable().getPool(poolName) != null) {
            return;  // 已经被注入过
        }
        int rolls = rollCount();
        LootPool pool = LootPool.lootPool()
            .name(poolName)
            .setRolls(ConstantValue.exactly(rolls))
            .add(ModAcquisitionEntry.acquisition(source))
            .build();
        event.getTable().addPool(pool);
        LOGGER.info("[RainbowEnchantment] 已把获取途径 [{}] 挂到战利品表 {}（每个容器判定 {} 次）",
            source.id(), event.getName(), rolls);
    }

    @SubscribeEvent
    public static void onVillagerTrades(VillagerTradesEvent event) {
        if (!ModAcquisition.enabled()) {
            return;
        }
        if (!LIBRARIAN.equals(ForgeRegistries.VILLAGER_PROFESSIONS.getKey(event.getType()))) {
            return;
        }
        AcquisitionSection.Librarian cfg = ModAcquisition.section().librarian;
        try {
            if (!cfg.enabled.get()) {
                return;
            }
        } catch (Exception e) {
            return;
        }
        for (int tier = 1; tier <= 5; tier++) {
            List<VillagerTrades.ItemListing> list = event.getTrades().get(tier);
            if (list == null) {
                continue;
            }
            double chance = librarianChance(cfg, tier);
            if (chance <= 0.0D) {
                continue;
            }
            list.add(new ModEnchantBookTrade(tier, list, chance));
        }
        try {
            LOGGER.info("[RainbowEnchantment] 已给图书管理员挂上获取途径 [librarian]（等级 1~5，概率 {}）",
                cfg.chanceByTier.get());
        } catch (Exception ignored) {
            // 日志失败不影响功能
        }
    }

    private static double librarianChance(AcquisitionSection.Librarian cfg, int tier) {
        try {
            List<? extends Double> list = cfg.chanceByTier.get();
            if (tier >= 1 && tier <= list.size()) {
                Double value = list.get(tier - 1);
                if (value != null) {
                    return value;
                }
            }
        } catch (Exception ignored) {
            // 配置未加载：按「不产出」处理
        }
        return 0.0D;
    }

    /** 战利品表 id → 途径（含送礼；同一张表只归第一条匹配到的途径）。 */
    private static AcquisitionSource sourceForTable(ResourceLocation table) {
        String id = table.toString();
        Map<String, AcquisitionSource> mapping = new LinkedHashMap<>();
        try {
            AcquisitionSection acq = ModAcquisition.section();
            for (AcquisitionSource source : AcquisitionSource.values()) {
                List<? extends String> tables;
                boolean enabled;
                if (source == AcquisitionSource.HERO_GIFT) {
                    enabled = acq.heroGift.enabled.get();
                    tables = acq.heroGift.lootTables.get();
                } else {
                    AcquisitionSection.Source cfg = ModAcquisition.configFor(source);
                    enabled = cfg.enabled.get();
                    tables = cfg.lootTables.get();
                }
                if (!enabled) {
                    continue;
                }
                for (String configured : tables) {
                    mapping.putIfAbsent(configured, source);
                }
            }
        } catch (Exception e) {
            return null;
        }
        return mapping.get(id);
    }

    private static int rollCount() {
        try {
            return Math.max(1, ModAcquisition.section().rollsPerContainer.get());
        } catch (Exception e) {
            return 1;
        }
    }

    /**
     * 服务器启动完成后把「通用池 / 各专属池」的构成打进日志：
     * 一眼就能核对 {@code [acquisition.exclusive]} 是否按预期生效。
     */
    @SubscribeEvent
    public static void onServerStarted(net.minecraftforge.event.server.ServerStartedEvent event) {
        if (!ModAcquisition.enabled()) {
            LOGGER.info("[RainbowEnchantment] 游玩获取总开关已关闭（acquisition.enabled = false）");
            return;
        }
        LOGGER.info("[RainbowEnchantment] 通用池 {} 个：{}",
            ModAcquisition.generalPool().size(), ids(ModAcquisition.generalPool()));
        for (AcquisitionSource source : AcquisitionSource.values()) {
            if (source.dedicated()) {
                List<net.minecraft.world.item.enchantment.Enchantment> pool =
                    ModAcquisition.poolFor(source.id(), true);
                LOGGER.info("[RainbowEnchantment] 专属池 [{}] {} 个：{}", source.id(), pool.size(), ids(pool));
            }
        }
        for (MobSource source : MobSource.values()) {
            List<net.minecraft.world.item.enchantment.Enchantment> pool =
                ModAcquisition.poolFor(source.id(), true);
            LOGGER.info("[RainbowEnchantment] 专属池 [{}] {} 个：{}", source.id(), pool.size(), ids(pool));
        }
        List<net.minecraft.world.item.enchantment.Enchantment> tablePool =
            ModAcquisition.poolFor("enchanting_table", true);
        LOGGER.info("[RainbowEnchantment] 专属池 [enchanting_table] {} 个：{}",
            tablePool.size(), ids(tablePool));
        List<net.minecraft.world.item.enchantment.Enchantment> bonusPool =
            ModAcquisition.poolFor("bonus_enchant", true);
        LOGGER.info("[RainbowEnchantment] 专属池 [bonus_enchant] {} 个：{}",
            bonusPool.size(), ids(bonusPool));
    }

    private static String ids(List<net.minecraft.world.item.enchantment.Enchantment> pool) {
        StringBuilder builder = new StringBuilder();
        for (net.minecraft.world.item.enchantment.Enchantment enchantment : pool) {
            ResourceLocation key = ForgeRegistries.ENCHANTMENTS.getKey(enchantment);
            if (key == null) {
                continue;
            }
            if (builder.length() > 0) {
                builder.append(", ");
            }
            builder.append(key.getPath());
        }
        return builder.toString();
    }
}
