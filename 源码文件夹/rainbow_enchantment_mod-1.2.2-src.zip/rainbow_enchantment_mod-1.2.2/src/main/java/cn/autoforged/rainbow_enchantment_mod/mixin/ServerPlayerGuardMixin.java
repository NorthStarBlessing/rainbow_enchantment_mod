package cn.autoforged.rainbow_enchantment_mod.mixin;

import cn.autoforged.rainbow_enchantment_mod.enchantment.UndyingGuard;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 不死附魔的死亡拦截（{@code ServerPlayer} 自己那道 {@code die}）。
 *
 * <h2>为什么必须单独来这一层</h2>
 * 原版 {@code ServerPlayer} <b>重写了 {@code die} 而且不调用父类</b>，所以
 * {@link LivingEntityGuardMixin} 与 {@link PlayerGuardMixin} 那两道都拦不到它。
 * 这是原版自己的写法决定的，与任何其它模组无关。
 *
 * <p>取消整个 {@code die()} 之后，死亡消息、掉落、统计这些原版副作用一并跳过 —— 这正是
 * 「被不死保着的玩家不该死」的预期。
 */
@Mixin(ServerPlayer.class)
public abstract class ServerPlayerGuardMixin {

    @Inject(method = "die", at = @At("HEAD"), cancellable = true)
    private void rainbow$guardedNoDie(DamageSource source, CallbackInfo ci) {
        try {
            ServerPlayer self = (ServerPlayer) (Object) this;
            if (UndyingGuard.isGuarded(self)) {
                ci.cancel();
                UndyingGuard.recover(self);
            }
        } catch (Throwable ignored) {
            // 失败一律放行
        }
    }
}
