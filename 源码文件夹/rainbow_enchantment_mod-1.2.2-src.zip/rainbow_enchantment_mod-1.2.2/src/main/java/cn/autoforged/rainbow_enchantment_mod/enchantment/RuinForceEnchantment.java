package cn.autoforged.rainbow_enchantment_mod.enchantment;

import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import cn.autoforged.rainbow_enchantment_mod.effect.ModEffects;
import cn.autoforged.rainbow_enchantment_mod.effect.RuinWitherEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.Enchantments;

public class RuinForceEnchantment extends ModEnchantment {
    protected RuinForceEnchantment(Rarity rarity, EquipmentSlot... slots) {
        super(rarity, EnchantmentCategory.WEAPON, slots);
    }

    @Override
    public int getMinCost(int level) {
        return 20 + 10 * (level - 1);
    }

    @Override
    public int getMaxCost(int level) {
        return super.getMinCost(level) + 50;
    }

    @Override
    public int getMaxLevel() {
        return 5;
    }

    @Override
    public boolean isTreasureOnly() {
        return true;
    }

    @Override
    public boolean canEnchant(ItemStack stack) {
        return stack.getItem() instanceof SwordItem || stack.getItem() instanceof BowItem
            || stack.getItem() instanceof CrossbowItem || stack.getItem() instanceof AxeItem;
    }

    @Override
    public void doPostAttack(LivingEntity attacker, Entity target, int level) {
        if (target instanceof LivingEntity livingTarget && !target.level().isClientSide) {
            float maxHp = attacker.getMaxHealth();
            float costPct = ModConfig.COMMON.ruinSelfCostPercent.get().floatValue();
            float newHealth = Math.max(attacker.getHealth() - maxHp * costPct, 1.0f);
            attacker.setHealth(newHealth);

            applyRuinWither(attacker, livingTarget, level);

            sweepAttack(attacker, target, level);
        }
    }

    private void applyRuinWither(LivingEntity attacker, LivingEntity target, int level) {
        double atkDmg = attacker.getAttributeValue(Attributes.ATTACK_DAMAGE);
        RuinWitherEffect.ATTACK_DAMAGE_CACHE.put(target.getUUID(), atkDmg);
        RuinWitherEffect.ATTACKER_CACHE.put(target.getUUID(), attacker.getUUID());

        int maxDuration = ModConfig.COMMON.ruinWitherDuration.get();
        int duration = level * (maxDuration / 5);
        target.addEffect(new MobEffectInstance(ModEffects.RUIN_WITHER.get(), duration, level - 1));
    }

    private void sweepAttack(LivingEntity attacker, Entity target, int level) {
        if (!(attacker instanceof Player player)) return;
        if (player.getMainHandItem().getEnchantmentLevel(Enchantments.SWEEPING_EDGE) <= 0) return;

        var box = player.getMainHandItem().getSweepHitBox(player, target);
        for (LivingEntity le : player.level().getEntitiesOfClass(LivingEntity.class, box)) {
            if (le != player && le != target && !player.isAlliedTo(le)) {
                applyRuinWither(attacker, le, level);
            }
        }
    }
}
