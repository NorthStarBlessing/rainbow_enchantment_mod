package cn.autoforged.rainbow_enchantment_mod.network;

import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import cn.autoforged.rainbow_enchantment_mod.enchantment.ModEnchantments;
import cn.autoforged.rainbow_enchantment_mod.enchantment.StarlightForceEnchantment;
import cn.autoforged.rainbow_enchantment_mod.particle.ParticleEffectManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * 客户端 → 服务端：「我在空气上左键挥了一下」。
 *
 * <p>服务端收到后做三件事：
 * <ol>
 *   <li>校验主手确实握着带「星光之力」的物品（客户端可以伪造，必须服务端自己判）；</li>
 *   <li>校验冷却（沿用 {@link StarlightForceEnchantment#checkAndSetCooldown}）；</li>
 *   <li>用玩家视线算出落点，交给 {@link ParticleEffectManager} 开一场流星演出。</li>
 * </ol>
 *
 * <p>落点取值：沿视线做一次方块射线，命中方块就用命中点，
 * 没命中（对着天空挥）就用「视线方向 × 24 格」再往下找地面 —— 这样朝天上挥也能砸到人。
 */
public class StarlightTriggerPacket {

    public StarlightTriggerPacket() {}

    public static void encode(StarlightTriggerPacket msg, FriendlyByteBuf buf) {
        // 无载荷：服务端完全可以从玩家自己的状态推出一切，少传就少一处可伪造的输入
    }

    public static StarlightTriggerPacket decode(FriendlyByteBuf buf) {
        return new StarlightTriggerPacket();
    }

    public static void handle(StarlightTriggerPacket msg, Supplier<NetworkEvent.Context> ctxSup) {
        NetworkEvent.Context ctx = ctxSup.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player == null) return;
            if (!(player.level() instanceof ServerLevel level)) return;

            ItemStack weapon = player.getMainHandItem();
            int lvl = weapon.getEnchantmentLevel(ModEnchantments.STARLIGHT_FORCE.get());
            // 诊断：打开 general.debug_log 后，这一行会告诉你包到底到没到服务端、
            // 主手是什么、附魔等级是多少 —— 「一点特效没有」时先看这里。
            if (ModConfig.COMMON.debugLog.get()) {
                org.apache.logging.log4j.LogManager.getLogger().info(
                    "[RainbowEnchantment] 收到星光触发包: 主手={} 星光等级={}",
                    weapon.getItem(), lvl);
            }
            if (lvl <= 0) return;                       // 服务端自己再判一次，不信客户端
            if (!StarlightForceEnchantment.checkAndSetCooldown(player)) {
                if (ModConfig.COMMON.debugLog.get()) {
                    org.apache.logging.log4j.LogManager.getLogger().info(
                        "[RainbowEnchantment] 星光触发被冷却拦下");
                }
                return;
            }

            int stars = StarlightForceEnchantment.getStarCount(weapon);
            Vec3 impact = resolveImpact(level, player);
            if (ModConfig.COMMON.debugLog.get()) {
                org.apache.logging.log4j.LogManager.getLogger().info(
                    "[RainbowEnchantment] 星光落点 {} (玩家 {}), 星数 {}", impact, player.position(), stars);
            }
            ParticleEffectManager.triggerStarlight(level, impact, player, lvl, stars);
        });
        ctx.setPacketHandled(true);
    }

    /**
     * 由玩家视线推出落点。
     *
     * <p>⚠ 必须**先打实体、再打方块**。只做方块射线的话，对着怪左键时射线会穿过怪、
     * 一直落到 48 格外的地面 —— 表现为「明明在打怪，流星却砸到很远的地方」。
     */
    private static Vec3 resolveImpact(ServerLevel level, ServerPlayer player) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        Vec3 far = eye.add(look.scale(48.0));

        // ① 先找视线上的实体（怪 / 玩家），取最近的那个
        EntityHitResult entityHit = null;
        double best = Double.MAX_VALUE;
        AABB sweep = player.getBoundingBox().expandTowards(look.scale(48.0)).inflate(1.0);
        for (Entity e : level.getEntities(player, sweep)) {
            if (!e.isPickable() || !e.isAlive()) continue;
            AABB box = e.getBoundingBox().inflate(e.getPickRadius());
            var opt = box.clip(eye, far);
            if (opt.isEmpty()) continue;
            double d = eye.distanceToSqr(opt.get());
            if (d < best) {
                best = d;
                entityHit = new EntityHitResult(e, opt.get());
            }
        }

        // ② 再打方块
        BlockHitResult blockHit = level.clip(new ClipContext(
            eye, far, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));

        // ③ 取更近的那个
        double blockD = blockHit.getType() == HitResult.Type.BLOCK
            ? eye.distanceToSqr(blockHit.getLocation()) : Double.MAX_VALUE;
        if (entityHit != null && best <= blockD) {
            // 砸在实体身上：取实体脚下，让扩散贴地铺开（符合"砸向地面"的表现）
            Vec3 p = entityHit.getLocation();
            BlockHitResult down = level.clip(new ClipContext(
                p, p.add(0, -16, 0), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
            return down.getType() == HitResult.Type.BLOCK ? down.getLocation() : p;
        }
        if (blockHit.getType() == HitResult.Type.BLOCK) {
            return blockHit.getLocation();
        }

        // ④ 什么都没打到（对着天空挥）：取视线前方一段，再往下找一个可站立面
        Vec3 ahead = eye.add(look.scale(24.0));
        BlockHitResult down = level.clip(new ClipContext(
            ahead, ahead.add(0, -64, 0), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        return down.getType() == HitResult.Type.BLOCK ? down.getLocation() : ahead;
    }
}
