package cn.autoforged.rainbow_enchantment_mod.enchantment;

import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import cn.autoforged.rainbow_enchantment_mod.damage.ModDamageTypes;
import cn.autoforged.rainbow_enchantment_mod.event.ModEvents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.Enchantments;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class BreakEnchantment extends ModEnchantment {
    private static final Map<UUID, Long> COOLDOWN_MAP = new HashMap<>();
    private static final Map<UUID, List<Long>> TRIGGER_TIMES_MAP = new HashMap<>();
    private static final long TRIGGER_WINDOW_TICKS = 300;
    private static final int MAX_TRIGGERS_PER_WINDOW = 8;

    protected BreakEnchantment(Rarity rarity, EquipmentSlot... slots) {
        super(rarity, EnchantmentCategory.WEAPON, slots);
    }

    @Override
    public int getMinCost(int level) {
        return 15 + 15 * (level - 1);
    }

    @Override
    public int getMaxCost(int level) {
        return super.getMinCost(level) + 50;
    }

    @Override
    public int getMaxLevel() {
        return 5;
    }

    @Override
    public void doPostAttack(LivingEntity attacker, Entity target, int level) {
        if (target instanceof LivingEntity livingTarget && !target.level().isClientSide) {
            long now = attacker.level().getGameTime();
            int cooldownTicks = Math.max(ModConfig.COMMON.breakCooldownMinTicks.get(),
                ModConfig.COMMON.breakCooldownBaseTicks.get() - (level - 1) * ModConfig.COMMON.breakCooldownReductionPerLevel.get());

            int sweepCount = countSweepTargets(attacker, target);
            if (sweepCount > 3) {
                COOLDOWN_MAP.put(attacker.getUUID(), 0L);
            }

            Long lastTrigger = COOLDOWN_MAP.get(attacker.getUUID());
            if (lastTrigger != null && (now - lastTrigger) < cooldownTicks) return;

            if (!canTriggerInWindow(attacker.getUUID(), now)) return;

            COOLDOWN_MAP.put(attacker.getUUID(), now);
            recordTrigger(attacker.getUUID(), now);

            float total = calcDamage(attacker, level);

            var holder = livingTarget.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ModDamageTypes.OVERLOAD_DAMAGE);
            livingTarget.hurt(new DamageSource(holder, attacker), total);
            spawnParticles(livingTarget);

            sweepAttack(attacker, target, level, now);
        }
    }

    private void sweepAttack(LivingEntity attacker, Entity target, int level, long now) {
        if (!(attacker instanceof Player player)) return;
        if (player.getMainHandItem().getEnchantmentLevel(Enchantments.SWEEPING_EDGE) <= 0) return;

        var box = player.getMainHandItem().getSweepHitBox(player, target);
        for (LivingEntity le : player.level().getEntitiesOfClass(LivingEntity.class, box)) {
            if (le != player && le != target && !player.isAlliedTo(le)) {
                int sweepCount = countSweepTargets(attacker, target);
                if (sweepCount > 3) {
                    COOLDOWN_MAP.put(attacker.getUUID(), 0L);
                }

                if (!canTriggerInWindow(attacker.getUUID(), now)) return;

                COOLDOWN_MAP.put(attacker.getUUID(), now);
                recordTrigger(attacker.getUUID(), now);

                float total = calcDamage(attacker, level);

                var holder = le.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ModDamageTypes.OVERLOAD_DAMAGE);
                le.hurt(new DamageSource(holder, attacker), total);
                spawnParticles(le);
            }
        }
    }

    private float calcDamage(LivingEntity attacker, int level) {
        double rainbowBonus = getRainbowBonus(attacker);
        double percent = ModConfig.COMMON.breakRainbowPercent.get();
        double divisor = ModConfig.COMMON.breakRainbowDivisor.get();
        double rainbowContribution = rainbowBonus * percent / divisor;
        int base = ModConfig.COMMON.breakBaseTrueDamage.get();
        return (float) (level * (base + rainbowContribution));
    }

    private void spawnParticles(LivingEntity target) {
        if (target.level() instanceof ServerLevel serverLevel) {
            double x = target.getX();
            double y = target.getY() + target.getBbHeight() * 0.5;
            double z = target.getZ();
            serverLevel.sendParticles(ParticleTypes.SOUL, x, y, z, 6, 0.3, 0.3, 0.3, 0.05);
            serverLevel.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y, z, 6, 0.3, 0.3, 0.3, 0.05);
        }
    }

    private int countSweepTargets(LivingEntity attacker, Entity target) {
        if (!(attacker instanceof Player player)) return 0;
        if (player.getMainHandItem().getEnchantmentLevel(Enchantments.SWEEPING_EDGE) <= 0) return 0;

        var box = player.getMainHandItem().getSweepHitBox(player, target);
        int count = 0;
        for (LivingEntity le : player.level().getEntitiesOfClass(LivingEntity.class, box)) {
            if (le != player && le != target && !player.isAlliedTo(le)) {
                count++;
            }
        }
        return count;
    }

    private boolean canTriggerInWindow(UUID attackerUuid, long now) {
        List<Long> triggers = TRIGGER_TIMES_MAP.get(attackerUuid);
        if (triggers == null) return true;

        int count = 0;
        for (Long t : triggers) {
            if (now - t < TRIGGER_WINDOW_TICKS) count++;
        }
        return count < MAX_TRIGGERS_PER_WINDOW;
    }

    private void recordTrigger(UUID attackerUuid, long now) {
        List<Long> triggers = TRIGGER_TIMES_MAP.computeIfAbsent(attackerUuid, k -> new ArrayList<>());
        triggers.add(now);
        triggers.removeIf(t -> now - t >= TRIGGER_WINDOW_TICKS);
    }

    private double getRainbowBonus(LivingEntity attacker) {
        ItemStack weapon = attacker.getMainHandItem();
        int rainbowLevel = weapon.getEnchantmentLevel(ModEnchantments.RAINBOW.get());
        if (rainbowLevel <= 0) return 0;

        int[] counts = ModEvents.countDyes(weapon);
        int unique = counts[0];
        int duplicate = counts[1];
        if (unique <= 0 && duplicate <= 0) return 0;

        double rawBonus = (unique + duplicate) * rainbowLevel;
        double rainbowMultiplier = ModConfig.COMMON.rainbowSwordDamageMultiplier.get();
        return rawBonus * rainbowMultiplier;
    }
}
