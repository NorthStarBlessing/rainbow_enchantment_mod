package cn.autoforged.rainbow_enchantment_mod;

import cn.autoforged.rainbow_enchantment_mod.enchantment.ModEnchantments;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModCreativeTab {
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS =
        DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RainbowEnchantmentMod.MOD_ID);

    public static final RegistryObject<CreativeModeTab> ENCHANTMENT_TAB = CREATIVE_MODE_TABS.register("enchantments",
        () -> CreativeModeTab.builder()
            .icon(() -> new ItemStack(Items.ENCHANTED_BOOK))
            .title(Component.translatable("creativetab." + RainbowEnchantmentMod.MOD_ID + ".enchantments"))
            .withSearchBar()
            .displayItems((params, output) -> {
                for (var enchRO : ModEnchantments.ENCHANTMENTS.getEntries()) {
                    int maxLv = enchRO.get().getMaxLevel();
                    output.accept(EnchantedBookItem.createForEnchantment(
                        new EnchantmentInstance(enchRO.get(), maxLv)));
                }
            })
            .build());
}
