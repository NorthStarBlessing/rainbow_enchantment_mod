package cn.autoforged.rainbow_enchantment_mod.acquisition;

import cn.autoforged.rainbow_enchantment_mod.RainbowEnchantmentMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.storage.loot.entries.LootPoolEntryType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

/** 战利品条目类型的注册（自定义「获取判定」条目靠它才能进战利品池）。 */
public final class ModLootEntries {
    public static final DeferredRegister<LootPoolEntryType> LOOT_POOL_ENTRY_TYPES =
        DeferredRegister.create(Registries.LOOT_POOL_ENTRY_TYPE, RainbowEnchantmentMod.MOD_ID);

    public static final RegistryObject<LootPoolEntryType> ACQUISITION =
        LOOT_POOL_ENTRY_TYPES.register("acquisition",
            () -> new LootPoolEntryType(new ModAcquisitionEntry.Serializer()));

    private ModLootEntries() {
    }
}
