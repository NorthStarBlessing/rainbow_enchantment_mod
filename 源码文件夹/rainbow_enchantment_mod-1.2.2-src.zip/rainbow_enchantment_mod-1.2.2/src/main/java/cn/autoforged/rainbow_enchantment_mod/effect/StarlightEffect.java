package cn.autoforged.rainbow_enchantment_mod.effect;

import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;

public class StarlightEffect extends MobEffect {
    public StarlightEffect(MobEffectCategory category, int color) {
        super(category, color);
    }

    @Override
    public void applyEffectTick(LivingEntity entity, int amplifier) {
        if (!entity.level().isClientSide) {
            float damage = ModConfig.COMMON.starlightEffectDamage.get().floatValue();
            entity.hurt(entity.damageSources().magic(), damage);
        }
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        java.util.List<? extends Integer> intervals = ModConfig.COMMON.starlightDamageIntervalTicks.get();
        int index = Math.min(amplifier, intervals.size() - 1);
        int interval = intervals.get(index);
        if (interval < 1) interval = 1;
        return duration % interval == 0;
    }
}
