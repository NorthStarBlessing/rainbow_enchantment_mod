package cn.autoforged.rainbow_enchantment_mod.network;

import cn.autoforged.rainbow_enchantment_mod.RainbowEnchantmentMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

/**
 * 模组的网络通道。
 *
 * <p>目前只有一件事需要走网络：<b>「左键空气」</b>。
 * Forge 的 {@code PlayerInteractEvent.LeftClickEmpty} 是**纯客户端**事件
 * （服务端根本收不到"玩家对着空气挥了一下"这件事），
 * 而星光之力的触发恰恰是「左键空气 → 天上射下流星」，
 * 所以必须由客户端发包、服务端来真正开演出。
 */
public final class ModNetwork {

    private static final String PROTOCOL_VERSION = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
        new ResourceLocation(RainbowEnchantmentMod.MOD_ID, "main"),
        () -> PROTOCOL_VERSION,
        PROTOCOL_VERSION::equals,
        PROTOCOL_VERSION::equals);

    private ModNetwork() {}

    /** 在 FMLCommonSetupEvent 里调用一次。 */
    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, StarlightTriggerPacket.class,
            StarlightTriggerPacket::encode,
            StarlightTriggerPacket::decode,
            StarlightTriggerPacket::handle);
    }
}
