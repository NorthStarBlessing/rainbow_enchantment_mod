package cn.autoforged.rainbow_enchantment_mod.config;

import net.minecraftforge.common.ForgeConfigSpec;

public final class ModConfig {
    public static final ForgeConfigSpec COMMON_SPEC;
    public static final Common COMMON;

    static {
        var builder = new ForgeConfigSpec.Builder();
        COMMON = new Common(builder);
        COMMON_SPEC = builder.build();
    }

    public static class Common {
        // ================= General =================
        public final ForgeConfigSpec.BooleanValue debugLog;

        // ================= 冰霜附加 =================
        public final ForgeConfigSpec.IntValue frostBaseDamagePerSecond;
        public final ForgeConfigSpec.DoubleValue frostFireInteractionMultiplier;
        public final ForgeConfigSpec.IntValue frostEffectDuration;
        public final ForgeConfigSpec.IntValue frostEffectMaxAmplifier;
        public final ForgeConfigSpec.DoubleValue frostNightWalkerMultiplier;
        public final ForgeConfigSpec.ConfigValue<java.util.List<? extends Integer>> frostDamageIntervalTicks;

        // ================= 永恒附魔 =================
        public final ForgeConfigSpec.IntValue eternalMaxLevel;
        public final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> eternalItemWhitelist;
        public final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> eternalItemBlacklist;
        public final ForgeConfigSpec.BooleanValue eternalMendingRepair;

        // ================= 永劫之火 =================
        public final ForgeConfigSpec.IntValue eternalBaseDamage;
        public final ForgeConfigSpec.ConfigValue<java.util.List<? extends Integer>> eternalDamageIntervalTicks;
        public final ForgeConfigSpec.IntValue eternalEffectDuration;

        // ================= 彩虹 =================
        public final ForgeConfigSpec.DoubleValue rainbowSwordDamageMultiplier;
        public final ForgeConfigSpec.DoubleValue rainbowArmorReductionPerColor;
        public final ForgeConfigSpec.DoubleValue rainbowArmorToughnessFactor;
        public final ForgeConfigSpec.DoubleValue rainbowReductionMultiplier;
        public final ForgeConfigSpec.IntValue rainbowArmorExtraDamageOnDuplicate;
        public final ForgeConfigSpec.DoubleValue rainbowArmorReflectMultiplier;
        public final ForgeConfigSpec.IntValue rainbowArmorReflectCooldownMaxTicks;
        public final ForgeConfigSpec.IntValue rainbowArmorReflectCooldownMinTicks;
        public final ForgeConfigSpec.DoubleValue rainbowArmorMaxReduction;
        public final ForgeConfigSpec.DoubleValue rainbowArmorBossReductionFactor;
        public final ForgeConfigSpec.DoubleValue rainbowNightWalkerMultiplier;

        // ================= 断刻 =================
        public final ForgeConfigSpec.IntValue breakBaseTrueDamage;
        public final ForgeConfigSpec.DoubleValue breakRainbowPercent;
        public final ForgeConfigSpec.DoubleValue breakRainbowDivisor;
        public final ForgeConfigSpec.IntValue breakCooldownBaseTicks;
        public final ForgeConfigSpec.IntValue breakCooldownReductionPerLevel;
        public final ForgeConfigSpec.IntValue breakCooldownMinTicks;

        // ================= 夜行者 =================
        public final ForgeConfigSpec.DoubleValue nightWalkerDamageMultiplier;
        public final ForgeConfigSpec.DoubleValue nightWalkerDamageConstant;

        // ================= 海洋附加 =================
        public final ForgeConfigSpec.IntValue oceanDeepSeaDuration;
        public final ForgeConfigSpec.IntValue oceanWaterDamagePerSecond;
        public final ForgeConfigSpec.DoubleValue oceanLandDamageMultiplier;

        // ================= 森林附加 =================
        public final ForgeConfigSpec.DoubleValue forestHealPercentPerLevel;
        public final ForgeConfigSpec.IntValue forestArmorPieceDivisor;

        // ================= 崩坏之力 =================
        public final ForgeConfigSpec.DoubleValue ruinSelfCostPercent;
        public final ForgeConfigSpec.IntValue ruinWitherDuration;
        public final ForgeConfigSpec.DoubleValue ruinWitherHealLimitPerLevel;
        public final ForgeConfigSpec.DoubleValue ruinWitherHealLimitMax;

        // ================= 量子利刃 =================
        public final ForgeConfigSpec.DoubleValue quantumBladeErosionPercent;
        public final ForgeConfigSpec.DoubleValue quantumBladeMaxHpDeductionPercent;
        public final ForgeConfigSpec.IntValue quantumBladeCooldownTicks;

        // ================= 无暇 =================

        // ================= 量子之箭 =================
        public final ForgeConfigSpec.DoubleValue quantumArrowPenetrationDamageLoss;

        // ================= 星光之力 =================
        public final ForgeConfigSpec.DoubleValue starlightNetherStarBase;
        public final ForgeConfigSpec.DoubleValue starlightBaseRadius;
        public final ForgeConfigSpec.IntValue starlightSlowAmplifier;
        public final ForgeConfigSpec.IntValue starlightSlowDuration;
        public final ForgeConfigSpec.DoubleValue starlightKnockbackMin;
        public final ForgeConfigSpec.DoubleValue starlightKnockbackMax;
        public final ForgeConfigSpec.DoubleValue starlightEffectDamage;
        public final ForgeConfigSpec.ConfigValue<java.util.List<? extends Integer>> starlightDamageIntervalTicks;
        public final ForgeConfigSpec.IntValue starlightEffectDuration;
        /** 星光之力 / 千风之力：单件武器最多能锻造多少个下界之星（原先写死 20）。 */
        public final ForgeConfigSpec.IntValue netherStarForgeLimit;

        // ================= 千风之力 =================
        public final ForgeConfigSpec.IntValue windForceWallBaseRadius;
        public final ForgeConfigSpec.IntValue windForceWallRadiusPerLevel;
        public final ForgeConfigSpec.IntValue windForceBaseDamage;
        public final ForgeConfigSpec.DoubleValue windForceNetherStarBase;
        public final ForgeConfigSpec.DoubleValue windForceBaseSpreadRadius;

        // ================= 特效形态：星光之力（陨石演出） =================
        // 全部数值由「粒子特效预览实验室」定稿导出，改这里就能改观感，不用动代码。
        /** 流星生成高度（相对命中点，格）。 */
        public final ForgeConfigSpec.DoubleValue fxStarlightMeteorFromY;
        /** 流星下落耗时（tick）。 */
        public final ForgeConfigSpec.IntValue fxStarlightMeteorTicks;
        /** 下落加速度感：1=匀速，越大越"越掉越快"。 */
        public final ForgeConfigSpec.DoubleValue fxStarlightFallAccel;
        /** 拖尾密度。 */
        public final ForgeConfigSpec.DoubleValue fxStarlightTrailDensity;
        /** 扩散耗时（tick）：伤害在"环扫到目标"的那一 tick 才结算。 */
        public final ForgeConfigSpec.IntValue fxStarlightSpreadTicks;
        /** 球壳层数。 */
        public final ForgeConfigSpec.IntValue fxStarlightShellRings;
        /** 单位半径的粒子密度。 */
        public final ForgeConfigSpec.DoubleValue fxStarlightShellDensity;
        /** 球壳向上张开的比例：0=只贴地铺开，1=球形爆发。 */
        public final ForgeConfigSpec.DoubleValue fxStarlightAirborneShare;
        /** 球内持续粒子占比。 */
        public final ForgeConfigSpec.DoubleValue fxStarlightInteriorShare;
        /** 击飞最小格数。 */
        public final ForgeConfigSpec.DoubleValue fxStarlightKnockbackMin;
        /** 击飞最大格数。 */
        public final ForgeConfigSpec.DoubleValue fxStarlightKnockbackMax;
        /** 每 tick 发粒子的总上限（防止一发流星把客户端打爆）。 */
        public final ForgeConfigSpec.IntValue fxStarlightParticleBudget;
        /** 星数缩放的基数（加性）：半径/伤害 = 基础值 × (此值 + 星数)。 */
        public final ForgeConfigSpec.DoubleValue fxStarlightStarBaseMultiplier;

        // ================= 特效形态：千风之力（蓄力与扩散） =================
        /** 满蓄力所需 tick（原版拉满弓是 20）。 */
        public final ForgeConfigSpec.IntValue fxWindChargeTicks;
        /** 蓄力法阵的同心圆数量。 */
        public final ForgeConfigSpec.IntValue fxWindChargeRings;
        /** [已废弃] 旧箭尖风环的原点偏移；2026-10-12 改成脚下法阵后不再读取。 */
        public final ForgeConfigSpec.DoubleValue fxWindArrowTipOffset;
        /** [已废弃] 旧箭尖风环彼此的间距；同上，不再读取。 */
        public final ForgeConfigSpec.DoubleValue fxWindRingSpread;
        /**
         * 蓄力法阵整体缩放（相对风墙半径）：法阵基准半径 = max(1.2, 风墙半径 × 此值)。
         */
        public final ForgeConfigSpec.DoubleValue fxWindChargeRingScale;
        /** 扩散耗时（tick）。 */
        public final ForgeConfigSpec.IntValue fxWindSpreadTicks;
        /** 螺旋臂数量。 */
        public final ForgeConfigSpec.IntValue fxWindArms;
        /** 蓄力时风环的基础半径。 */
        public final ForgeConfigSpec.IntValue fxWindWallBaseRadius;
        /** 蓄力时风环每级附魔增加的范围。 */
        public final ForgeConfigSpec.IntValue fxWindWallRadiusPerLevel;
        /** 单位半径的粒子密度。 */
        public final ForgeConfigSpec.DoubleValue fxWindShellDensity;
        /** 球壳向上张开比例。 */
        public final ForgeConfigSpec.DoubleValue fxWindAirborneShare;
        /** 向心塌缩粒子占比。 */
        public final ForgeConfigSpec.DoubleValue fxWindInteriorShare;
        /** 扩散伤害基础值：伤害 = 此值 × (fx_star_base_multiplier + 星数)。 */
        public final ForgeConfigSpec.DoubleValue fxWindDamageBase;
        /** 扩散半径基础值：半径 = 此值 × (fx_star_base_multiplier + 星数)。 */
        public final ForgeConfigSpec.DoubleValue fxWindRadiusBase;
        /** 星数缩放的基数（加性）：半径/伤害 = 基础值 × (打怪 ? 此值 + 星数 : 此值)。 */
        public final ForgeConfigSpec.DoubleValue fxWindStarBaseMultiplier;
        /** 每 tick 发粒子的总上限。 */
        public final ForgeConfigSpec.IntValue fxWindParticleBudget;

        // ================= 波前粒子环（把"扩散边界"用粒子做实） =================
        /** 是否发波前环。 */
        public final ForgeConfigSpec.BooleanValue fxWaveRing;
        /** 波前密度：沿周长每单位半径的粒子数。 */
        public final ForgeConfigSpec.DoubleValue fxWaveDensity;
        /** 波前环相对地面的抬高（格）。 */
        public final ForgeConfigSpec.DoubleValue fxWaveLift;
        /** 波前粒子的大小倍率（要比球壳显眼）。 */
        public final ForgeConfigSpec.DoubleValue fxWaveScale;

        // ================= 判决 =================
        public final ForgeConfigSpec.DoubleValue judgmentKillDamageBonus;
        public final ForgeConfigSpec.IntValue judgmentMaxKillBonus;
        public final ForgeConfigSpec.DoubleValue judgmentSinBase;
        public final ForgeConfigSpec.DoubleValue judgmentSinMax;
        public final ForgeConfigSpec.DoubleValue judgmentUndeadMultiplier;
        public final ForgeConfigSpec.DoubleValue judgmentArthropodMultiplier;
        public final ForgeConfigSpec.DoubleValue judgmentPillagerMultiplier;
        /** 判决 vs 罪孽：基础倍率里「每 1 点罪孽等级」的加成（默认 0.002 = 0.2%）。 */
        public final ForgeConfigSpec.DoubleValue judgmentSinLevelMultiplier;
        /** 判决 vs 罪孽：判决高于所需等级时每高 1 级的加成（默认 0.015 = 1.5%）。 */
        public final ForgeConfigSpec.DoubleValue judgmentLevelDiffBonus;
        /** 判决低于所需等级时，对「罪孽敌方加成」惩罚的缩放（默认 1.0 = 原样使用）。 */
        public final ForgeConfigSpec.DoubleValue judgmentLevelDiffPenaltyScale;

        // ================= 无瑕 =================
        /** 无瑕·生命：公式里的第一个常量（默认 2.0）。 */
        public final ForgeConfigSpec.DoubleValue immaculateHpBase;
        /** 无瑕·生命：血量系数（默认 11.0，对应设定里的 (11 x 2)）。 */
        public final ForgeConfigSpec.DoubleValue immaculateHpHealthFactor;
        /** 无瑕·生命：血量百分比系数（默认 0.05 = 5%）。 */
        public final ForgeConfigSpec.DoubleValue immaculateHpHealthPercent;
        /** 无瑕·生命：附魔等级系数（默认 2.0）. */
        public final ForgeConfigSpec.DoubleValue immaculateHpLevelFactor;
        /** 无瑕·生命：附魔等级乘数（默认 2.55）。 */
        public final ForgeConfigSpec.DoubleValue immaculateHpLevelMultiplier;
        /** 无瑕·生命：公式末尾的加值（默认 10.0）。 */
        public final ForgeConfigSpec.DoubleValue immaculateHpFlat;
        /** 无瑕·攻击：公式里的第一个常量（默认 1.0）。 */
        public final ForgeConfigSpec.DoubleValue immaculateAtkBase;
        /** 无瑕·攻击：攻击系数（默认 12.0，对应设定里的 (12 x 2)）。 */
        public final ForgeConfigSpec.DoubleValue immaculateAtkAttackFactor;
        /** 无瑕·攻击：攻击百分比系数（默认 0.15 = 15%）。 */
        public final ForgeConfigSpec.DoubleValue immaculateAtkAttackPercent;
        /** 无瑕·攻击：附魔等级系数（默认 2.0）。 */
        public final ForgeConfigSpec.DoubleValue immaculateAtkLevelFactor;
        /** 无瑕·攻击：附魔等级乘数（默认 1.55）。 */
        public final ForgeConfigSpec.DoubleValue immaculateAtkLevelMultiplier;
        /** 无瑕·攻击：公式末尾的加值（默认 5.0）。 */
        public final ForgeConfigSpec.DoubleValue immaculateAtkFlat;
        /** 无瑕·减伤：生命值达到多少开始有减伤（默认 1520）。 */
        public final ForgeConfigSpec.DoubleValue immaculateDrStartHealth;
        /** 无瑕·减伤：每档的跨度 = 起始生命 × 此值（默认 0.15 = 15%）。 */
        public final ForgeConfigSpec.DoubleValue immaculateDrStepRatio;
        /** 无瑕·减伤：起始减伤（默认 0.01 = 1%）。 */
        public final ForgeConfigSpec.DoubleValue immaculateDrBase;
        /** 无瑕·减伤：每档额外减伤（默认 0.005 = 0.5%）。 */
        public final ForgeConfigSpec.DoubleValue immaculateDrStepBonus;
        /** 无瑕·减伤：计算减伤的生命值上限（默认 11520）。 */
        public final ForgeConfigSpec.DoubleValue immaculateDrMaxHealth;
        /** 无瑕·减伤：减伤上限（默认 0.95 = 95%）。 */
        public final ForgeConfigSpec.DoubleValue immaculateDrCap;
        /** 无瑕：生命上限提升的倍率上限（默认 1.50 = 基础生命的 150%）。 */
        public final ForgeConfigSpec.DoubleValue immaculateHpCapRatio;
        /** 无瑕：攻击力加成上限（默认 520）。 */
        public final ForgeConfigSpec.DoubleValue immaculateAttackCap;

        // ================= 空间斩 =================
        /** 空间斩连斩递减：线性项（默认 0.15，即每段少 15%）。 */
        public final ForgeConfigSpec.DoubleValue spaceSlashSegmentDecayLinear;
        /** 空间斩连斩递减：指数项（默认 0.85，第 n 段 = 原伤害 × 0.85^n）。 */
        public final ForgeConfigSpec.DoubleValue spaceSlashSegmentDecayExponential;

        // ================= 哈气 =================
        /** 哈气恐惧范围：基础值（默认 1.0）。 */
        public final ForgeConfigSpec.DoubleValue huffBaseRange;
        /** 哈气恐惧范围：附魔等级乘数（默认 1.0）。 */
        public final ForgeConfigSpec.DoubleValue huffRangePerLevel;
        /** 哈气恐惧范围：等级之外的加值（默认 2.0）。 */
        public final ForgeConfigSpec.DoubleValue huffRangeOffset;

        // ================= 寰宇破坏者 =================
        /** 寰宇破坏者：有效工具等级抬升档位的常量项（默认 1.0）。 */
        public final ForgeConfigSpec.DoubleValue universeBreakerTierBoostBase;
        /** 寰宇破坏者：每级抬升的工具等级档位（默认 0.5）。 */
        public final ForgeConfigSpec.DoubleValue universeBreakerTierBoostPerLevel;
        /** 寰宇破坏者：挖掘速度加成，每级乘数（默认 0.5，与等级抬升同一算法）。 */
        public final ForgeConfigSpec.DoubleValue universeBreakerSpeedPerLevel;

        // ================= 大运 =================
        /** 大运：伤害占自身攻击力的最低比例（默认 0.01 = 1%）。 */
        public final ForgeConfigSpec.DoubleValue greatFortuneDamageMinPercent;
        /** 大运：伤害占自身攻击力的最高比例（默认 0.10 = 10%）。 */
        public final ForgeConfigSpec.DoubleValue greatFortuneDamageMaxPercent;
        /** 大运：属性速度的基准值（默认 0.10，玩家未加成时的属性速度）。 */
        public final ForgeConfigSpec.DoubleValue greatFortuneDamageSpeedReference;
        /** 大运：达到最高伤害比例所需的速度跨度（默认 0.18）。 */
        public final ForgeConfigSpec.DoubleValue greatFortuneDamageSpeedRange;
        /** 大运：移速公式里每级附魔的乘数（默认 1.25）。 */
        public final ForgeConfigSpec.DoubleValue greatFortuneSpeedLevelMultiplier;
        /** 大运：移速公式里速度 buff 的乘数（默认 0.005）。 */
        public final ForgeConfigSpec.DoubleValue greatFortuneSpeedBuffMultiplier;
        /** 大运：移速公式里基础速度的乘数（默认 0.05 = 5%）。 */
        public final ForgeConfigSpec.DoubleValue greatFortuneBaseSpeedMultiplier;
        /** 大运：移速公式最后的除数（默认 2.2）。 */
        public final ForgeConfigSpec.DoubleValue greatFortuneSpeedDivisor;
        /** 大运·冰霜行者联动：每级额外移速（默认 0.15 = 15%）。 */
        public final ForgeConfigSpec.DoubleValue greatFortuneFrostWalkerSpeedPerLevel;
        /** 大运：坐船时船继承的速度比例（默认 0.15 = 15%）。 */
        public final ForgeConfigSpec.DoubleValue greatFortuneBoatSpeedShare;
        /** 大运：坐船撞击伤害倍率（默认 1.20 = 120%）。 */
        public final ForgeConfigSpec.DoubleValue greatFortuneBoatImpactMultiplier;

        // ================= 罪孽深重系统 =================
        public final ForgeConfigSpec.DoubleValue sinSpawnChance;
        public final ForgeConfigSpec.IntValue sinSmallMobMaxLevel;
        public final ForgeConfigSpec.IntValue sinEliteMobMaxLevel;
        public final ForgeConfigSpec.DoubleValue sinDropWeightBase;
        public final ForgeConfigSpec.DoubleValue sinDropWeightMax;
        /**
         * 药水抗性：每级降低「负面效果」的时长或效果等级的比例。
         * 默认 0.05（每级 5%），与百科口径「每级减 5% 效果等级与持续时间」一致。
         */
        public final ForgeConfigSpec.DoubleValue potionResistancePerLevel;
        /** 药水抗性：用于「降低效果等级」的档位占比（默认 0.5，其余档位用于压时长）。 */
        public final ForgeConfigSpec.DoubleValue potionResistanceAmplifierShare;
        /**
         * 罪孽等级「防御力」的换算已按维护者给定公式固定实现，不再需要配置项：
         *   最终盔甲值 = 原版盔甲值(ARMOR) x (1 + 该等级防御力%)，再叠加盔甲韧性(ARMOR_TOUGHNESS)，
         *   每点提供 0.001 减伤，只作用于物理伤害。
         * （曾有一个 defense_to_armor_factor 配置项，因机制澄清后不再适用而移除。）
         */
        public final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> sinDropWhitelist;
        public final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> sinDropBlacklist;
        public final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> sinMonsterWhitelist;
        public final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> sinMonsterBlacklist;
        public final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> sinEliteWhitelist;
        public final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> sinEliteBlacklist;

        // sin_system.boss_spawns
        public final ForgeConfigSpec.DoubleValue sinBossDragonChance;
        public final ForgeConfigSpec.IntValue sinBossDragonMinLevel;
        public final ForgeConfigSpec.IntValue sinBossDragonMaxLevel;
        public final ForgeConfigSpec.DoubleValue sinBossWitherChance;
        public final ForgeConfigSpec.IntValue sinBossWitherMinLevel;
        public final ForgeConfigSpec.IntValue sinBossWitherMaxLevel;
        public final ForgeConfigSpec.DoubleValue sinBossWardenChance;
        public final ForgeConfigSpec.IntValue sinBossWardenMinLevel;
        public final ForgeConfigSpec.IntValue sinBossWardenMaxLevel;
        public final ForgeConfigSpec.DoubleValue sinBossElderGuardianChance;
        public final ForgeConfigSpec.IntValue sinBossElderGuardianMinLevel;
        public final ForgeConfigSpec.IntValue sinBossElderGuardianMaxLevel;
        public final ForgeConfigSpec.DoubleValue sinBossEndermanChance;
        public final ForgeConfigSpec.IntValue sinBossEndermanMinLevel;
        public final ForgeConfigSpec.IntValue sinBossEndermanMaxLevel;
        public final ForgeConfigSpec.DoubleValue sinBossWitherSkeletonLowChance;
        public final ForgeConfigSpec.IntValue sinBossWitherSkeletonLowMin;
        public final ForgeConfigSpec.IntValue sinBossWitherSkeletonLowMax;
        public final ForgeConfigSpec.DoubleValue sinBossWitherSkeletonMidChance;
        public final ForgeConfigSpec.IntValue sinBossWitherSkeletonMidMin;
        public final ForgeConfigSpec.IntValue sinBossWitherSkeletonMidMax;
        public final ForgeConfigSpec.DoubleValue sinBossWitherSkeletonHighChance;
        public final ForgeConfigSpec.IntValue sinBossWitherSkeletonHighMin;
        public final ForgeConfigSpec.IntValue sinBossWitherSkeletonHighMax;

        // sin_system.raid_spawns
        public final ForgeConfigSpec.DoubleValue sinRaidEasyChance;
        public final ForgeConfigSpec.IntValue sinRaidEasyMaxLevel;
        public final ForgeConfigSpec.DoubleValue sinRaidNormalChance;
        public final ForgeConfigSpec.IntValue sinRaidNormalMaxLevel;
        public final ForgeConfigSpec.DoubleValue sinRaidHardChance;
        public final ForgeConfigSpec.IntValue sinRaidHardMaxLevel;
        public final ForgeConfigSpec.DoubleValue sinRaidHardcoreChance;
        public final ForgeConfigSpec.IntValue sinRaidHardcoreMaxLevel;

        // ================= 掠夺 =================
        public final ForgeConfigSpec.DoubleValue plunderChance;

        // ================= 双倍 =================
        public final ForgeConfigSpec.DoubleValue doubleLevel1Chance;
        public final ForgeConfigSpec.DoubleValue doubleMaxChance;

        // ================= 丰收 =================
        public final ForgeConfigSpec.DoubleValue harvestLevel1Chance;
        public final ForgeConfigSpec.DoubleValue harvestMaxChance;

        // ================= 超级幸运 =================
        public final ForgeConfigSpec.DoubleValue luckyDoubleChanceLevel1;
        public final ForgeConfigSpec.DoubleValue luckyDoubleChanceMax;
        public final ForgeConfigSpec.DoubleValue luckyGoodLootChanceLevel1;
        public final ForgeConfigSpec.DoubleValue luckyGoodLootChanceMax;

        // ================= 不死 =================
        public final ForgeConfigSpec.DoubleValue undyingHealAmount;
        public final ForgeConfigSpec.IntValue undyingCooldownTicks;
        public final ForgeConfigSpec.IntValue undyingEffectDuration;
        public final ForgeConfigSpec.DoubleValue undyingPostEffectDamage;

        // ================= 氧气 =================
        public final ForgeConfigSpec.IntValue oxygenIntervalTicks;
        public final ForgeConfigSpec.IntValue oxygenIntervalReductionPerRespirationLevel;

        // ================= 海神探索者 =================
        public final ForgeConfigSpec.DoubleValue seaGodSpeedPerLevel;

        // ================= 空间斩 =================
        public final ForgeConfigSpec.IntValue spaceSlashCooldownLevel1;
        public final ForgeConfigSpec.IntValue spaceSlashCooldownMaxLevel;

        // ================= 星光财宝 =================
        // 每类矿物的「锻造次数上限」（不是最终属性上限）。
        public final ForgeConfigSpec.IntValue starTreasureMaxIron;
        public final ForgeConfigSpec.IntValue starTreasureMaxDiamond;
        public final ForgeConfigSpec.IntValue starTreasureMaxEmerald;
        public final ForgeConfigSpec.IntValue starTreasureMaxAmethyst;
        public final ForgeConfigSpec.IntValue starTreasureMaxRedstone;
        public final ForgeConfigSpec.IntValue starTreasureMaxEchoShard;
        public final ForgeConfigSpec.IntValue starTreasureMaxGlowstone;
        public final ForgeConfigSpec.IntValue starTreasureMaxStone;
        public final ForgeConfigSpec.IntValue starTreasureMaxEndStone;
        public final ForgeConfigSpec.IntValue starTreasureMaxObsidian;
        public final ForgeConfigSpec.IntValue starTreasureMaxBlackstone;
        public final ForgeConfigSpec.IntValue starTreasureMaxNetherite;
        public final ForgeConfigSpec.IntValue starTreasureMaxLapis;
        public final ForgeConfigSpec.IntValue starTreasureMaxQuartz;
        public final ForgeConfigSpec.IntValue starTreasureMaxGold;
        public final ForgeConfigSpec.IntValue starTreasureMaxCopper;
        public final ForgeConfigSpec.IntValue starTreasureMaxModOre;
        // 最终属性总上限（三类加成各自封顶）。
        public final ForgeConfigSpec.DoubleValue starTreasureTotalMaxDamage;
        public final ForgeConfigSpec.DoubleValue starTreasureTotalMaxSpeed;
        public final ForgeConfigSpec.DoubleValue starTreasureTotalMaxDurability;
        // 回响碎片的单块增幅（默认 +10，明显高于其他矿物，所以单独给一个旋钮）。
        public final ForgeConfigSpec.DoubleValue starTreasureEchoShardDamage;
        // 耐久加成的生效方式。
        public final ForgeConfigSpec.ConfigValue<String> starTreasureDurabilityMode;

        // ================= 变态 =================
        public final ForgeConfigSpec.DoubleValue pervertLevel1Chance;
        public final ForgeConfigSpec.DoubleValue pervertMaxChance;

        // ================= 樱花粉 =================
        public final ForgeConfigSpec.IntValue cherryBlossomMaxArmor;
        public final ForgeConfigSpec.IntValue cherryBlossomMaxFood;
        public final ForgeConfigSpec.IntValue cherryBlossomMaxWeapon;
        public final ForgeConfigSpec.IntValue cherryBlossomMaxTool;

        // ================= 杂项设置 =================
        public final ForgeConfigSpec.BooleanValue miscInfoKeyShift;
        public final ForgeConfigSpec.BooleanValue miscInfoKeyCtrl;

        // ================= 屠宰 =================
        public final ForgeConfigSpec.DoubleValue butcherLevel1Chance;
        public final ForgeConfigSpec.DoubleValue butcherMaxChance;
        public final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> butcherWhitelist;
        public final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> butcherBlacklist;

        // ================= 超级核弹 =================
        public final ForgeConfigSpec.DoubleValue superNukeBasePower;
        public final ForgeConfigSpec.DoubleValue superNukePowerPerLevel;

        // ================= 财宝聚集 =================
        public final ForgeConfigSpec.DoubleValue treasureGatheringLevel1Chance;
        public final ForgeConfigSpec.DoubleValue treasureGatheringMaxChance;
        public final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> treasureGatheringMineralList;

        // ================= 游玩获取配置（附魔怎么拿到） =================
        /** 见 {@link AcquisitionSection}：宝箱 / 钓鱼 / 村民交易的概率与等级表。 */
        public final AcquisitionSection acquisition;

        Common(ForgeConfigSpec.Builder b) {
            // ==============================================
            //           自定义附魔系统配置文件
            // ==============================================

            // ================= General =================
            b.comment("==============================================",
                      "          自定义附魔系统配置文件",
                      "==============================================").push("general");
            debugLog = b
                .comment("是否启用调试日志")
                .define("debug_log", false);
            b.pop();

            // ================= 冰霜附加 =================
            b.comment("================= 冰霜附加 =================").push("frost_enchantment");
            frostBaseDamagePerSecond = b
                .comment("寒冷基础每秒伤害（在触发时）")
                .defineInRange("base_damage_per_second", 2, 1, 100);
            frostFireInteractionMultiplier = b
                .comment("火焰交互伤害倍率（寒冷等级 × 此值）")
                .defineInRange("fire_interaction_multiplier", 2.0, 0.0, 100.0);
            frostEffectDuration = b
                .comment("寒冷效果持续时间 (tick)")
                .defineInRange("effect_duration", 100, 20, 72000);
            frostEffectMaxAmplifier = b
                .comment("寒冷最大等级 (0起算，4 = 等级V)")
                .defineInRange("max_amplifier", 4, 0, 10);
            frostNightWalkerMultiplier = b
                .comment("夜行者激活时寒冷伤害倍率")
                .defineInRange("night_walker_multiplier", 2.0, 1.0, 100.0);
            frostDamageIntervalTicks = b
                .comment("伤害触发间隔 (tick)，根据附魔等级索引 (1~5)",
                         "I:20, II:10, III:5, IV:2, V:1")
                .defineList("damage_interval_ticks",
                    java.util.List.of(20, 10, 5, 2, 1),
                    it -> it instanceof Integer);
            b.pop();

            // ================= 永恒附魔 =================
            b.comment("================= 永恒附魔 =================").push("eternal_enchantment");
            eternalMaxLevel = b
                .comment("永恒附魔最高等级（20）")
                .defineInRange("max_level", 20, 1, 20);
            eternalItemWhitelist = b
                .comment("永恒附魔可附魔物品的白名单（物品注册名列表，为空则使用内置规则）")
                .defineList("item_whitelist",
                    java.util.List.of(),
                    it -> it instanceof String);
            eternalItemBlacklist = b
                .comment("永恒附魔不可附魔物品的黑名单（物品注册名列表）")
                .defineList("item_blacklist",
                    java.util.List.of(),
                    it -> it instanceof String);
            eternalMendingRepair = b
                .comment("经验修补是否可修复永恒次数")
                .define("mending_repair", true);
            b.pop();

            // ================= 永劫之火 =================
            b.comment("================= 永劫之火 =================").push("eternal_fire_enchantment");
            eternalBaseDamage = b
                .comment("永燃伤害（每次触发）")
                .defineInRange("base_damage", 5, 1, 100);
            eternalDamageIntervalTicks = b
                .comment("伤害触发间隔 (tick)，与冰霜相同")
                .defineList("damage_interval_ticks",
                    java.util.List.of(20, 10, 5, 2, 1),
                    it -> it instanceof Integer);
            eternalEffectDuration = b
                .comment("永燃效果持续时间 (tick，持续刷新)")
                .defineInRange("effect_duration", 100, 20, 72000);
            b.pop();

            // ================= 彩虹 =================
            b.comment("================= 彩虹 =================").push("rainbow_enchantment");
            rainbowArmorReductionPerColor = b
                .comment("每独特染料每等级的减伤加成 (0.025 = 2.5%)")
                .defineInRange("armor_reduction_per_color", 0.025, 0.0, 1.0);
            rainbowArmorToughnessFactor = b
                .comment("护甲+韧性对减伤的贡献因子 (0.001 = 0.1%)")
                .defineInRange("armor_toughness_factor", 0.001, 0.0, 1.0);
            rainbowReductionMultiplier = b
                .comment("减伤公式中的乘数 (50%)")
                .defineInRange("reduction_multiplier", 0.5, 0.0, 1.0);
            rainbowArmorMaxReduction = b
                .comment("护甲最大减伤比例 (60%)")
                .defineInRange("armor_max_reduction", 0.6, 0.0, 1.0);
            rainbowArmorBossReductionFactor = b
                .comment("面对Boss类敌人时减伤效果降低幅度 (减伤效果×0.85)")
                .defineInRange("armor_boss_reduction_factor", 0.15, 0.0, 1.0);
            rainbowArmorExtraDamageOnDuplicate = b
                .comment("每重复颜料的反弹基础伤害")
                .defineInRange("armor_extra_damage_on_duplicate", 1, 0, 100);
            rainbowSwordDamageMultiplier = b
                .comment("剑类彩虹伤害倍率 (独特+重复) × 等级 × 此值")
                .defineInRange("sword_damage_multiplier", 2.0, 0.0, 100.0);
            rainbowArmorReflectMultiplier = b
                .comment("护甲反弹伤害倍率")
                .defineInRange("armor_reflect_multiplier", 0.25, 0.0, 10.0);
            rainbowArmorReflectCooldownMaxTicks = b
                .comment("最大反伤冷却 tick (等级1时)")
                .defineInRange("reflect_cooldown_max_ticks", 400, 0, 72000);
            rainbowArmorReflectCooldownMinTicks = b
                .comment("最小反伤冷却 tick (等级5时)")
                .defineInRange("reflect_cooldown_min_ticks", 200, 0, 72000);
            rainbowNightWalkerMultiplier = b
                .comment("夜行者激活时彩虹伤害倍率")
                .defineInRange("night_walker_multiplier", 1.5, 1.0, 10.0);
            b.pop();

            // ================= 断刻 =================
            b.comment("================= 断刻 =================").push("break_enchantment");
            breakBaseTrueDamage = b
                .comment("每附魔等级的基础真实伤害")
                .defineInRange("base_true_damage", 1, 0, 100);
            breakRainbowPercent = b
                .comment("消耗彩虹加成的百分比")
                .defineInRange("rainbow_percent", 0.05, 0.0, 1.0);
            breakRainbowDivisor = b
                .comment("彩虹贡献除数")
                .defineInRange("rainbow_divisor", 2.0, 0.01, 100.0);
            breakCooldownBaseTicks = b
                .comment("冷却基础 tick (等级1)")
                .defineInRange("cooldown_base_ticks", 300, 0, 72000);
            breakCooldownReductionPerLevel = b
                .comment("每级减少的冷却 tick")
                .defineInRange("cooldown_reduction_per_level", 60, 0, 72000);
            breakCooldownMinTicks = b
                .comment("最小冷却 tick")
                .defineInRange("cooldown_min_ticks", 60, 0, 72000);
            b.pop();

            // ================= 夜行者 =================
            b.comment("================= 夜行者 =================").push("night_walker_enchantment");
            nightWalkerDamageMultiplier = b
                .comment("夜晚额外基础伤害 = floor(武器伤害×此值 + 固定值)")
                .defineInRange("damage_multiplier", 0.15, 0.0, 100.0);
            nightWalkerDamageConstant = b
                .defineInRange("damage_constant", 2.0, 0.0, 1000.0);
            b.pop();

            // ================= 海洋附加 =================
            b.comment("================= 海洋附加 =================").push("ocean_strike_enchantment");
            oceanDeepSeaDuration = b
                .comment("深海效果持续时间 (tick)")
                .defineInRange("deep_sea_duration", 100, 20, 72000);
            oceanWaterDamagePerSecond = b
                .comment("雨天/水中深海每秒伤害")
                .defineInRange("water_damage_per_second", 2, 0, 100);
            oceanLandDamageMultiplier = b
                .comment("陆地时冰霜/火焰增伤倍率")
                .defineInRange("land_damage_multiplier", 1.2, 1.0, 100.0);
            b.pop();

            // ================= 森林附加 =================
            b.comment("================= 森林附加 =================").push("forest_strike_enchantment");
            forestHealPercentPerLevel = b
                .comment("每附魔等级的治疗百分比 (0.05 = 5%)")
                .defineInRange("heal_percent_per_level", 0.05, 0.0, 1.0);
            forestArmorPieceDivisor = b
                .comment("治疗公式中的件数除数 (4件时为满效果)")
                .defineInRange("armor_piece_divisor", 4, 1, 4);
            b.pop();

            // ================= 崩坏之力 =================
            b.comment("================= 崩坏之力 =================").push("ruin_force_enchantment");
            ruinSelfCostPercent = b
                .comment("自身消耗百分比（最大生命×此值）")
                .defineInRange("self_cost_percent", 0.05, 0.0, 1.0);
            ruinWitherDuration = b
                .comment("崩坏凋零基础持续时间 (tick) 等级映射：1->20,2->40,...,5->100",
                         "这里设置最大持续时间，代码按等级线性映射")
                .defineInRange("wither_duration_max", 100, 20, 100);
            ruinWitherHealLimitPerLevel = b
                .comment("每级治疗削减比例")
                .defineInRange("heal_limit_per_level", 0.05, 0.0, 1.0);
            ruinWitherHealLimitMax = b
                .comment("最大治疗削减比例")
                .defineInRange("heal_limit_max", 0.15, 0.0, 1.0);
            b.pop();

            // ================= 量子利刃 =================
            b.comment("================= 量子利刃 =================").push("quantum_blade_enchantment");
            quantumBladeErosionPercent = b
                .comment("侵蚀伤害百分比 (1%)")
                .defineInRange("erosion_percent", 0.01, 0.0, 1.0);
            quantumBladeMaxHpDeductionPercent = b
                .comment("最大生命上限扣血百分比")
                .defineInRange("max_hp_deduction_percent", 0.05, 0.0, 1.0);
            quantumBladeCooldownTicks = b
                .comment("扣血冷却时间 (tick)")
                .defineInRange("max_hp_deduction_cooldown", 300, 0, 72000);
            b.pop();

            // ================= 无暇 =================
            b.comment("================= 无暇 =================").push("flawless_enchantment");
            immaculateHpBase = b
                .comment("生命公式: 常量项 (设定原文里的 2)")
                .defineInRange("hp_formula_base", 2.0, 0.0, 1000.0);
            immaculateHpHealthFactor = b
                .comment("生命公式: 血量系数 (设定原文里的 11)")
                .defineInRange("hp_formula_health_factor", 11.0, 0.0, 1000.0);
            immaculateHpHealthPercent = b
                .comment("生命公式: 血量百分比 (0.05 = 5%)")
                .defineInRange("hp_formula_health_percent", 0.05, 0.0, 10.0);
            immaculateHpLevelFactor = b
                .comment("生命公式: 附魔等级系数 (设定原文里的 2)")
                .defineInRange("hp_formula_level_factor", 2.0, 0.0, 100.0);
            immaculateHpLevelMultiplier = b
                .comment("生命公式: 附魔等级乘数 (设定原文里的 2.55)")
                .defineInRange("hp_formula_level_multiplier", 2.55, 0.0, 1000.0);
            immaculateHpFlat = b
                .comment("生命公式: 末尾加值 (设定原文里的 10)")
                .defineInRange("hp_formula_flat", 10.0, 0.0, 10000.0);
            immaculateAtkBase = b
                .comment("攻击公式: 常量项 (设定原文里的 1)")
                .defineInRange("attack_formula_base", 1.0, 0.0, 1000.0);
            immaculateAtkAttackFactor = b
                .comment("攻击公式: 攻击系数 (设定原文里的 12)")
                .defineInRange("attack_formula_attack_factor", 12.0, 0.0, 1000.0);
            immaculateAtkAttackPercent = b
                .comment("攻击公式: 攻击百分比 (0.15 = 15%)")
                .defineInRange("attack_formula_attack_percent", 0.15, 0.0, 10.0);
            immaculateAtkLevelFactor = b
                .comment("攻击公式: 附魔等级系数 (设定原文里的 2)")
                .defineInRange("attack_formula_level_factor", 2.0, 0.0, 100.0);
            immaculateAtkLevelMultiplier = b
                .comment("攻击公式: 附魔等级乘数 (设定原文里的 1.55)")
                .defineInRange("attack_formula_level_multiplier", 1.55, 0.0, 1000.0);
            immaculateAtkFlat = b
                .comment("攻击公式: 末尾加值 (设定原文里的 5)")
                .defineInRange("attack_formula_flat", 5.0, 0.0, 10000.0);
            immaculateHpCapRatio = b
                .comment("生命上限提升的倍率上限 (1.50 = 基础生命的 150%)")
                .defineInRange("hp_cap_ratio", 1.50, 0.0, 100.0);
            immaculateAttackCap = b
                .comment("攻击力加成上限 (设定里的 520)")
                .defineInRange("attack_cap", 520.0, 0.0, 10000.0);
            // ── 无瑕·减伤门槛 ──
            immaculateDrStartHealth = b
                .comment("生命值达到多少开始有减伤 (设定里的 1520)")
                .defineInRange("damage_reduction_start_health", 1520.0, 0.0, 1.0E7);
            immaculateDrStepRatio = b
                .comment("每档跨度 = 起始生命 x 此值 (0.15 = 每多 15% 生命一档)")
                .defineInRange("damage_reduction_step_ratio", 0.15, 0.001, 100.0);
            immaculateDrBase = b
                .comment("起始减伤 (0.01 = 1%)")
                .defineInRange("damage_reduction_base", 0.01, 0.0, 1.0);
            immaculateDrStepBonus = b
                .comment("每档额外减伤 (0.005 = 0.5%)")
                .defineInRange("damage_reduction_step_bonus", 0.005, 0.0, 1.0);
            immaculateDrMaxHealth = b
                .comment("计算减伤的生命值上限 (设定里的 11520)")
                .defineInRange("damage_reduction_max_health", 11520.0, 0.0, 1.0E7);
            immaculateDrCap = b
                .comment("减伤上限 (0.95 = 95%)")
                .defineInRange("damage_reduction_cap", 0.95, 0.0, 1.0);
            b.pop();

            // ================= 量子之箭 =================
            b.comment("================= 量子之箭 =================").push("quantum_arrow_enchantment");
            quantumArrowPenetrationDamageLoss = b
                .comment("每次穿透伤害降低比例 (5%)")
                .defineInRange("penetration_damage_loss", 0.05, 0.0, 1.0);
            b.pop();

            // ================= 星光之力 =================
            b.comment("================= 星光之力 =================").push("starlight_enchantment");
            starlightNetherStarBase = b
                .comment("[已废弃 · 不再读取] 下界之星贡献的底数",
                         "只有 StarlightForceEnchantment#getDamageMultiplier / getRangeMultiplier 读它，",
                         "而这两个方法全项目没有调用点。星数缩放见下方 fx_star_base_multiplier。",
                         "保留键名只为兼容旧配置文件。")
                .defineInRange("nether_star_base", 1.3, 1.0, 10.0);
            fxStarlightStarBaseMultiplier = b
                .comment("星数缩放的基数（加性，每颗星 +1）",
                         "扩散半径 = base_radius x (此值 + 星数)，伤害 = (1 + (等级+1) x 2.75) x (此值 + 星数)")
                .defineInRange("fx_star_base_multiplier", 1.3, 0.0, 100.0);
            starlightBaseRadius = b
                .comment("星光效果扩散范围基础半径")
                .defineInRange("base_radius", 3.0, 0.0, 100.0);
            starlightSlowAmplifier = b
                .comment("缓慢效果等级 (0起算，IV=3)")
                .defineInRange("slow_amplifier", 3, 0, 10);
            starlightSlowDuration = b
                .comment("缓慢持续时间 (秒)")
                .defineInRange("slow_duration", 3, 0, 100);
            starlightKnockbackMin = b
                .comment("[已废弃 · 不再读取] 击飞最小格数，已被本段下方的 fx_knockback_min 取代")
                .defineInRange("knockback_min", 2.0, 0.0, 100.0);
            starlightKnockbackMax = b
                .comment("[已废弃 · 不再读取] 击飞最大格数，已被本段下方的 fx_knockback_max 取代")
                .defineInRange("knockback_max", 5.0, 0.0, 100.0);
            starlightEffectDamage = b
                .comment("星光效果每跳伤害 (与寒冷效果一致)")
                .defineInRange("effect_damage", 2.0, 0.0, 100.0);
            starlightDamageIntervalTicks = b
                .comment("星光效果伤害触发间隔 (tick)，依附魔等级索引 (0~4)",
                         "I:20, II:10, III:5, IV:2, V:1")
                .defineList("damage_interval_ticks",
                    java.util.List.of(20, 10, 5, 2, 1),
                    it -> it instanceof Integer);
            starlightEffectDuration = b
                .comment("星光效果持续时间 (tick)")
                .defineInRange("effect_duration", 100, 20, 72000);
            netherStarForgeLimit = b
                .comment("星光之力 / 千风之力: 单件武器最多锻造的下界之星数 (原先写死 20)")
                .defineInRange("nether_star_forge_limit", 20, 1, 1000);
            // ── 陨石演出形态（由预览实验室定稿的默认值） ──
            fxStarlightMeteorFromY = b
                .comment("流星生成高度（相对命中点，格）")
                .defineInRange("fx_meteor_from_y", 26.0, 4.0, 200.0);
            fxStarlightMeteorTicks = b
                .comment("流星下落耗时 (tick)")
                .defineInRange("fx_meteor_ticks", 22, 1, 200);
            fxStarlightFallAccel = b
                .comment("下落加速度感 (1=匀速, 越大越'越掉越快')")
                .defineInRange("fx_fall_accel", 1.55, 0.2, 5.0);
            fxStarlightTrailDensity = b
                .comment("拖尾密度")
                .defineInRange("fx_trail_density", 7.0, 0.0, 60.0);
            fxStarlightSpreadTicks = b
                .comment("扩散耗时 (tick)：伤害在'环扫到目标'的那一 tick 才结算")
                .defineInRange("fx_spread_ticks", 20, 1, 200);
            fxStarlightShellRings = b
                .comment("球壳层数")
                .defineInRange("fx_shell_rings", 4, 1, 12);
            fxStarlightShellDensity = b
                .comment("单位半径的粒子密度")
                .defineInRange("fx_shell_density", 1.6, 0.0, 12.0);
            fxStarlightAirborneShare = b
                .comment("球壳向上张开比例 (0=只贴地铺开, 1=球形爆发)")
                .defineInRange("fx_airborne_share", 0.45, 0.0, 3.0);
            fxStarlightInteriorShare = b
                .comment("球内持续粒子占比")
                .defineInRange("fx_interior_share", 0.85, 0.0, 5.0);
            fxStarlightKnockbackMin = b
                .comment("击飞最小格数")
                .defineInRange("fx_knockback_min", 2.0, 0.0, 30.0);
            fxStarlightKnockbackMax = b
                .comment("击飞最大格数")
                .defineInRange("fx_knockback_max", 5.0, 0.0, 30.0);
            fxStarlightParticleBudget = b
                .comment("每 tick 发粒子总上限（防止一发流星把客户端打爆）")
                .defineInRange("fx_particle_budget", 260, 0, 4000);
            b.pop();

            // ================= 千风之力 =================
            b.comment("================= 千风之力 =================").push("wind_force_enchantment");
            windForceWallBaseRadius = b
                .comment("风墙基础范围")
                .defineInRange("wind_wall_base_radius", 2, 0, 100);
            windForceWallRadiusPerLevel = b
                .comment("每附魔等级增加的风墙范围")
                .defineInRange("wind_wall_radius_per_level", 1, 0, 100);
            windForceBaseDamage = b
                .comment("[已废弃 · 不再读取] 旧「落地 AOE」的伤害基础值，已被本段下方的 fx_damage_base 取代",
                         "（旧的 onProjectileImpact 落地 AOE 分支已整块删除，见 docs/FIXES-2026-10-12.md 第 9 节）")
                .defineInRange("base_damage", 5, 0, 100);
            windForceNetherStarBase = b
                .comment("[已废弃 · 不再读取] 下界之星底数",
                         "只有 ThousandWindForceEnchantment#getDamageMultiplier / getRangeMultiplier 读它，",
                         "而这两个方法全项目没有调用点。星数缩放见下方 fx_star_base_multiplier。",
                         "保留键名只为兼容旧配置文件。")
                .defineInRange("nether_star_base", 1.2, 1.0, 10.0);
            fxWindStarBaseMultiplier = b
                .comment("星数缩放的基数（加性，每颗星 +1；打地面时星数不参与）",
                         "扩散半径 = fx_radius_base x (打怪 ? 此值 + 星数 : 此值)，伤害同理用 fx_damage_base")
                .defineInRange("fx_star_base_multiplier", 1.3, 0.0, 100.0);
            windForceBaseSpreadRadius = b
                .comment("[已废弃 · 不再读取] 旧「落地 AOE」的半径基础值，已被本段下方的 fx_radius_base 取代")
                .defineInRange("base_spread_radius", 4.0, 0.0, 100.0);
            // ── 千风演出形态（由预览实验室定稿的默认值） ──
            fxWindChargeTicks = b
                .comment("满蓄力所需 tick（原版拉满弓是 20）")
                .defineInRange("fx_charge_ticks", 20, 1, 200);
            fxWindChargeRings = b
                .comment("蓄力法阵的同心圆数量（2~4 比较像法阵，再多会糊成一圈）")
                .defineInRange("fx_charge_rings", 3, 1, 10);
            fxWindArrowTipOffset = b
                .comment("[已废弃] 旧版箭尖风环的原点偏移；2026-10-12 改成脚下法阵后不再使用，保留仅为兼容旧配置文件")
                .defineInRange("fx_arrow_tip_offset", 1.10, 0.0, 10.0);
            fxWindRingSpread = b
                .comment("[已废弃] 旧版箭尖风环彼此间距；2026-10-12 改成脚下法阵后不再使用，保留仅为兼容旧配置文件")
                .defineInRange("fx_ring_spread", 0.55, 0.0, 10.0);
            fxWindChargeRingScale = b
                .comment("蓄力法阵整体缩放（相对风墙半径）；法阵半径 = max(1.2, 风墙半径 x 此值)")
                .defineInRange("fx_charge_ring_scale", 0.22, 0.02, 2.0);
            fxWindSpreadTicks = b
                .comment("扩散耗时 (tick)")
                .defineInRange("fx_spread_ticks", 20, 1, 200);
            fxWindArms = b
                .comment("螺旋臂数量")
                .defineInRange("fx_arms", 3, 1, 12);
            fxWindWallBaseRadius = b
                .comment("蓄力时风环的基础半径（= 此值 + 等级 x 每级）")
                .defineInRange("fx_wall_base_radius", 2, 0, 100);
            fxWindWallRadiusPerLevel = b
                .comment("蓄力时风环每级附魔增加的范围")
                .defineInRange("fx_wall_radius_per_level", 1, 0, 100);
            fxWindShellDensity = b
                .comment("单位半径的粒子密度")
                .defineInRange("fx_shell_density", 1.6, 0.0, 12.0);
            fxWindAirborneShare = b
                .comment("球壳向上张开比例")
                .defineInRange("fx_airborne_share", 0.45, 0.0, 3.0);
            fxWindInteriorShare = b
                .comment("向心塌缩粒子占比")
                .defineInRange("fx_interior_share", 0.85, 0.0, 5.0);
            fxWindDamageBase = b
                .comment("扩散伤害基础值：伤害 = 此值 x (1.3 + 星数)")
                .defineInRange("fx_damage_base", 2.0, 0.0, 100.0);
            fxWindRadiusBase = b
                .comment("扩散半径基础值：半径 = 此值 x (1.3 + 星数)")
                .defineInRange("fx_radius_base", 5.0, 0.0, 100.0);
            fxWindParticleBudget = b
                .comment("每 tick 发粒子总上限")
                .defineInRange("fx_particle_budget", 260, 0, 4000);
            b.pop();

            // ================= 波前粒子环 =================
            b.comment("================= 波前粒子环 =================").push("wave_ring");
            fxWaveRing = b
                .comment("是否发波前环（把扩散边界用粒子做实）")
                .define("enabled", true);
            fxWaveDensity = b
                .comment("波前密度：沿周长每单位半径的粒子数")
                .defineInRange("density", 1.1, 0.05, 12.0);
            fxWaveLift = b
                .comment("波前环相对地面的抬高 (格)")
                .defineInRange("lift", 0.10, 0.0, 5.0);
            fxWaveScale = b
                .comment("波前粒子大小倍率（比球壳显眼）")
                .defineInRange("scale", 1.9, 0.1, 10.0);
            b.pop();

            // ================= 判决 =================
            b.comment("================= 判决 =================").push("judgment_enchantment");
            judgmentKillDamageBonus = b
                .comment("每10击杀的基础伤害加成（1.0 = 每10击杀+1伤害）")
                .defineInRange("kill_damage_bonus", 1.0, 0.0, 100.0);
            judgmentSinBase = b
                .comment("每次恶行增加的基础罪孽值（0.05 = 每次+0.05）")
                .defineInRange("sin_base", 0.05, 0.0, 1.0);
            judgmentSinMax = b
                .comment("罪孽值上限 (0.022 = 2.2%)")
                .defineInRange("sin_max", 0.022, 0.0, 1.0);
            judgmentMaxKillBonus = b
                .comment("最大击杀伤害加成")
                .defineInRange("max_kill_bonus", 30, 1, 1000);
            judgmentUndeadMultiplier = b
                .comment("对亡灵类伤害倍率")
                .defineInRange("undead_multiplier", 1.012, 1.0, 10.0);
            judgmentArthropodMultiplier = b
                .comment("对节肢类伤害倍率")
                .defineInRange("arthropod_multiplier", 1.011, 1.0, 10.0);
            judgmentPillagerMultiplier = b
                .comment("对掠夺者伤害倍率")
                .defineInRange("pillager_multiplier", 1.015, 1.0, 10.0);
            // ── 判决 vs 罪孽深重 的伤害公式参数 ──
            judgmentSinLevelMultiplier = b
                .comment("基础倍率 = 1 + 罪孽等级 x 此值 (0.002 = 每级 0.2%)")
                .defineInRange("sin_level_multiplier", 0.002, 0.0, 1.0);
            judgmentLevelDiffBonus = b
                .comment("判决高于「所需等级」时，每高 1 级的伤害加成 (0.015 = 1.5%)")
                .defineInRange("level_diff_bonus", 0.015, 0.0, 1.0);
            judgmentLevelDiffPenaltyScale = b
                .comment("判决低于「所需等级」时，对罪孽敌方加成惩罚的缩放 (1.0 = 原样)")
                .defineInRange("level_diff_penalty_scale", 1.0, 0.0, 10.0);
            b.pop();

            // ================= 罪孽深重系统 =================
            b.comment("================= 罪孽深重系统 =================").push("sin_system");
            sinSpawnChance = b
                .comment("生物生成时获得词条的基准概率 (13.25%)")
                .defineInRange("spawn_chance", 0.1325, 0.0, 1.0);
            sinSmallMobMaxLevel = b
                .comment("普通怪物最高等级")
                .defineInRange("small_mob_max_level", 6, 1, 20);
            sinEliteMobMaxLevel = b
                .comment("精英怪物最高等级")
                .defineInRange("elite_mob_max_level", 15, 1, 20);
            sinDropWeightBase = b
                .comment("掉落权重基础 (1级)")
                .defineInRange("drop_weight_base", 0.0025, 0.0, 1.0);
            sinDropWeightMax = b
                .comment("掉落权重最大值 (20级)")
                .defineInRange("drop_weight_max", 0.2225, 0.0, 1.0);
            sinDropWhitelist = b
                .comment("可掉落的稀有物品")
                .defineList("drop_whitelist",
                    java.util.List.of(
                        "minecraft:enchanted_golden_apple",
                        "minecraft:golden_apple",
                        "minecraft:nether_star",
                        "minecraft:totem_of_undying"
                    ),
                    it -> it instanceof String);
            sinDropBlacklist = b
                .comment("掉落黑名单")
                .defineList("drop_blacklist",
                    java.util.List.of(),
                    it -> it instanceof String);
            sinMonsterWhitelist = b
                .comment("普通怪物白名单（实体类型注册名）")
                .defineList("monster_whitelist",
                    java.util.List.of(),
                    it -> it instanceof String);
            sinMonsterBlacklist = b
                .comment("普通怪物黑名单（实体类型注册名）")
                .defineList("monster_blacklist",
                    java.util.List.of(),
                    it -> it instanceof String);
            sinEliteWhitelist = b
                .comment("精英怪物白名单（实体类型注册名）")
                .defineList("elite_whitelist",
                    java.util.List.of(),
                    it -> it instanceof String);
            sinEliteBlacklist = b
                .comment("精英怪物黑名单（实体类型注册名）")
                .defineList("elite_blacklist",
                    java.util.List.of(),
                    it -> it instanceof String);

            // Boss及特殊生物的罪孽等级生成概率
            b.push("boss_spawns");
            sinBossDragonChance = b
                .comment("末影龙: 复活时22%概率获得12~20级")
                .defineInRange("dragon_chance", 0.22, 0.0, 1.0);
            sinBossDragonMinLevel = b
                .defineInRange("dragon_min_level", 12, 1, 20);
            sinBossDragonMaxLevel = b
                .defineInRange("dragon_max_level", 20, 1, 20);
            sinBossWitherChance = b
                .comment("凋零: 召唤时22%概率获得12~20级")
                .defineInRange("wither_chance", 0.22, 0.0, 1.0);
            sinBossWitherMinLevel = b
                .defineInRange("wither_min_level", 12, 1, 20);
            sinBossWitherMaxLevel = b
                .defineInRange("wither_max_level", 20, 1, 20);
            sinBossWardenChance = b
                .comment("坚守者: 被尖啸体召唤时15%概率获得10~20级")
                .defineInRange("warden_chance", 0.15, 0.0, 1.0);
            sinBossWardenMinLevel = b
                .defineInRange("warden_min_level", 10, 1, 20);
            sinBossWardenMaxLevel = b
                .defineInRange("warden_max_level", 20, 1, 20);
            sinBossElderGuardianChance = b
                .comment("远古守卫者: 生成时10%概率获得5~15级")
                .defineInRange("elder_guardian_chance", 0.10, 0.0, 1.0);
            sinBossElderGuardianMinLevel = b
                .defineInRange("elder_guardian_min_level", 5, 1, 20);
            sinBossElderGuardianMaxLevel = b
                .defineInRange("elder_guardian_max_level", 15, 1, 20);
            sinBossEndermanChance = b
                .comment("末影人: 生成时16%概率获得10~12级")
                .defineInRange("enderman_chance", 0.16, 0.0, 1.0);
            sinBossEndermanMinLevel = b
                .defineInRange("enderman_min_level", 10, 1, 20);
            sinBossEndermanMaxLevel = b
                .defineInRange("enderman_max_level", 12, 1, 20);
            sinBossWitherSkeletonLowChance = b
                .comment("凋零骷髅: 生成时20%概率1-10级")
                .defineInRange("wither_skeleton_low_chance", 0.20, 0.0, 1.0);
            sinBossWitherSkeletonLowMin = b
                .defineInRange("wither_skeleton_low_min", 1, 1, 20);
            sinBossWitherSkeletonLowMax = b
                .defineInRange("wither_skeleton_low_max", 10, 1, 20);
            sinBossWitherSkeletonMidChance = b
                .comment("凋零骷髅: 10%概率10-15级")
                .defineInRange("wither_skeleton_mid_chance", 0.10, 0.0, 1.0);
            sinBossWitherSkeletonMidMin = b
                .defineInRange("wither_skeleton_mid_min", 10, 1, 20);
            sinBossWitherSkeletonMidMax = b
                .defineInRange("wither_skeleton_mid_max", 15, 1, 20);
            sinBossWitherSkeletonHighChance = b
                .comment("凋零骷髅: 5%概率15-20级")
                .defineInRange("wither_skeleton_high_chance", 0.05, 0.0, 1.0);
            sinBossWitherSkeletonHighMin = b
                .defineInRange("wither_skeleton_high_min", 15, 1, 20);
            sinBossWitherSkeletonHighMax = b
                .defineInRange("wither_skeleton_high_max", 20, 1, 20);
            b.pop();

            // 掠夺事件生成概率
            b.push("raid_spawns");
            sinRaidEasyChance = b
                .comment("简单: 25%概率，最高5级")
                .defineInRange("easy_chance", 0.25, 0.0, 1.0);
            sinRaidEasyMaxLevel = b
                .defineInRange("easy_max_level", 5, 1, 20);
            sinRaidNormalChance = b
                .comment("普通: 35%概率，最高10级")
                .defineInRange("normal_chance", 0.35, 0.0, 1.0);
            sinRaidNormalMaxLevel = b
                .defineInRange("normal_max_level", 10, 1, 20);
            sinRaidHardChance = b
                .comment("困难: 45%概率，最高15级")
                .defineInRange("hard_chance", 0.45, 0.0, 1.0);
            sinRaidHardMaxLevel = b
                .defineInRange("hard_max_level", 15, 1, 20);
            sinRaidHardcoreChance = b
                .comment("极限: 60%概率，最高18级")
                .defineInRange("hardcore_chance", 0.60, 0.0, 1.0);
            sinRaidHardcoreMaxLevel = b
                .defineInRange("hardcore_max_level", 18, 1, 20);
            b.pop();

            b.pop(); // sin_system

            // ================= 掠夺 =================
            b.comment("================= 掠夺 =================").push("plunder_enchantment");
            plunderChance = b
                .comment("掠夺触发概率 (5%)")
                .defineInRange("chance", 0.05, 0.0, 1.0);
            b.pop();

            // ================= 双倍 =================
            b.comment("================= 双倍 =================").push("double_enchantment");
            doubleLevel1Chance = b
                .comment("双倍1级概率 (11.2%)")
                .defineInRange("level_1_chance", 0.112, 0.0, 1.0);
            doubleMaxChance = b
                .comment("双倍满级概率 (25%)")
                .defineInRange("max_chance", 0.25, 0.0, 1.0);
            b.pop();

            // ================= 丰收 =================
            b.comment("================= 丰收 =================").push("harvest_enchantment");
            harvestLevel1Chance = b
                .comment("丰收1级概率 (15%)")
                .defineInRange("level_1_chance", 0.15, 0.0, 1.0);
            harvestMaxChance = b
                .comment("丰收满级概率 (30%)")
                .defineInRange("max_chance", 0.30, 0.0, 1.0);
            b.pop();

            // ================= 超级幸运 =================
            b.comment("================= 超级幸运 =================").push("super_lucky_enchantment");
            luckyDoubleChanceLevel1 = b
                .comment("超级幸运1级双倍概率 (15%)")
                .defineInRange("double_chance_level_1", 0.15, 0.0, 1.0);
            luckyDoubleChanceMax = b
                .comment("超级幸运满级双倍概率 (22%)")
                .defineInRange("double_chance_max", 0.22, 0.0, 1.0);
            luckyGoodLootChanceLevel1 = b
                .comment("超级幸运1级好东西概率 (12%)")
                .defineInRange("good_loot_chance_level_1", 0.12, 0.0, 1.0);
            luckyGoodLootChanceMax = b
                .comment("超级幸运满级好东西概率 (20%)")
                .defineInRange("good_loot_chance_max", 0.20, 0.0, 1.0);
            b.pop();

            // ================= 不死 =================
            b.comment("================= 不死 =================").push("undying_enchantment");
            undyingHealAmount = b
                .comment("触发时恢复血量 (6点)")
                .defineInRange("heal_amount", 6.0, 0.0, 100.0);
            undyingCooldownTicks = b
                .comment("冷却时间 (tick, 30秒=600)")
                .defineInRange("cooldown_ticks", 600, 0, 72000);
            undyingEffectDuration = b
                .comment("冥界花持续时间 (tick, 15秒=300)")
                .defineInRange("effect_duration", 300, 0, 72000);
            undyingPostEffectDamage = b
                .comment("冥界花结束后扣除血量 (1点)")
                .defineInRange("post_effect_damage", 1.0, 0.0, 100.0);
            b.pop();

            // ================= 氧气 =================
            b.comment("================= 氧气 =================").push("oxygen_enchantment");
            oxygenIntervalTicks = b
                .comment("水下氧气恢复间隔 (tick, 5秒=100)")
                .defineInRange("oxygen_interval_ticks", 100, 10, 72000);
            oxygenIntervalReductionPerRespirationLevel = b
                .comment("每级水下呼吸减少的恢复间隔 tick")
                .defineInRange("interval_reduction_per_respiration_level", 15, 0, 1000);
            b.pop();

            // ================= 海神探索者 =================
            b.comment("================= 海神探索者 =================").push("sea_god_explorer_enchantment");
            seaGodSpeedPerLevel = b
                .comment("每级水下速度增加比例 (0.25 = 1/4)")
                .defineInRange("speed_per_level", 0.25, 0.0, 10.0);
            b.pop();

            // ================= 屠宰 =================
            b.comment("================= 屠宰 =================").push("butcher_enchantment");
            butcherLevel1Chance = b
                .comment("屠宰1级概率 (15%)")
                .defineInRange("level_1_chance", 0.15, 0.0, 1.0);
            butcherMaxChance = b
                .comment("屠宰满级概率 (45%)")
                .defineInRange("max_chance", 0.45, 0.0, 1.0);
            butcherWhitelist = b
                .comment("双倍掉落白名单（实体类型注册名，如 minecraft:cow）")
                .defineList("whitelist",
                    java.util.List.of(
                        "minecraft:cow",
                        "minecraft:pig",
                        "minecraft:sheep",
                        "minecraft:chicken",
                        "minecraft:rabbit",
                        "minecraft:cod",
                        "minecraft:salmon",
                        "minecraft:tropical_fish",
                        "minecraft:pufferfish"
                    ),
                    it -> it instanceof String);
            butcherBlacklist = b
                .comment("黑名单（实体类型注册名）")
                .defineList("blacklist",
                    java.util.List.of(),
                    it -> it instanceof String);
            b.pop();

            // ================= 超级核弹 =================
            b.comment("================= 超级核弹 =================").push("super_nuke_enchantment");
            superNukeBasePower = b
                .comment("核弹基础爆炸强度 (5)")
                .defineInRange("base_power", 5.0, 1.0, 100.0);
            superNukePowerPerLevel = b
                .comment("每级增加的爆炸强度 (2)")
                .defineInRange("power_per_level", 2.0, 0.0, 100.0);
            b.pop();

            // ================= 哈气 =================
            b.comment("================= 哈气 =================").push("huff_enchantment");
            huffBaseRange = b
                .comment("哈气恐惧范围的基础值 (与等级、每级乘数共同决定范围)")
                .defineInRange("base_range", 1.0, 0.0, 64.0);
            huffRangePerLevel = b
                .comment("哈气恐惧范围: 每级附魔的乘数")
                .defineInRange("range_per_level", 1.0, 0.0, 64.0);
            huffRangeOffset = b
                .comment("哈气恐惧范围: 等级之外的加值")
                .defineInRange("range_offset", 2.0, 0.0, 64.0);
            b.pop();

            // ================= 财宝聚集 =================
            b.comment("================= 财宝聚集 =================").push("treasure_gathering_enchantment");
            treasureGatheringLevel1Chance = b
                .comment("财宝聚集1级概率 (15%)")
                .defineInRange("level_1_chance", 0.15, 0.0, 1.0);
            treasureGatheringMaxChance = b
                .comment("财宝聚集满级概率 (60%)")
                .defineInRange("max_chance", 0.60, 0.0, 1.0);
            treasureGatheringMineralList = b
                .comment("矿物列表（物品注册名）")
                .defineList("mineral_list",
                    java.util.List.of(
                        "minecraft:coal",
                        "minecraft:iron_ingot",
                        "minecraft:gold_ingot",
                        "minecraft:diamond",
                        "minecraft:emerald",
                        "minecraft:lapis_lazuli",
                        "minecraft:redstone",
                        "minecraft:copper_ingot"
                    ),
                    it -> it instanceof String);
            b.pop();

            // ================= 空间斩 =================
            b.comment("================= 空间斩 =================").push("space_slash_enchantment");
            spaceSlashCooldownLevel1 = b
                .comment("空间斩1级冷却 (tick, 30秒=600)")
                .defineInRange("cooldown_level_1", 600, 0, 72000);
            spaceSlashCooldownMaxLevel = b
                .comment("空间斩满级冷却 (tick, 5秒=100)")
                .defineInRange("cooldown_max_level", 100, 0, 72000);
            // ── 空间斩连斩递减参数 ──
            // 第 n 段 = 玩家那一刀 × (1 - 线性) × 指数^n
            spaceSlashSegmentDecayLinear = b
                .comment("连斩每段减少的比例 (0.15 = 每段少 15%)")
                .defineInRange("segment_decay_linear", 0.15, 0.0, 1.0);
            spaceSlashSegmentDecayExponential = b
                .comment("连斩递减的指数底 (0.85 → 第 n 段 = 原伤害 x 0.85^n)")
                .defineInRange("segment_decay_exponential", 0.85, 0.0, 1.0);
            b.pop();

            // ================= 星光财宝 =================
            b.comment("================= 星光财宝 =================").push("star_treasure_enchantment");
            b.comment("下面每一项都是「该类矿物最多能锻造多少次」的次数上限，",
                      "不是最终属性上限。最终属性还受 total_max_* 三项二次封顶。")
                .push("max_forge_count");
            starTreasureMaxIron = b
                .comment("铁锭/铁块 (耐久 +1 / +10)")
                .defineInRange("iron", 1400, 0, 100000);
            starTreasureMaxDiamond = b
                .comment("钻石 (伤害 +0.1 / +1)")
                .defineInRange("diamond", 100, 0, 100000);
            starTreasureMaxEmerald = b
                .comment("绿宝石 (耐久 +1 / +10)")
                .defineInRange("emerald", 1400, 0, 100000);
            starTreasureMaxAmethyst = b
                .comment("紫水晶碎片/紫水晶块 (伤害 +0.1 / +1)")
                .defineInRange("amethyst", 100, 0, 100000);
            starTreasureMaxRedstone = b
                .comment("红石 (速度 +0.01 / +0.1)")
                .defineInRange("redstone", 600, 0, 100000);
            starTreasureMaxEchoShard = b
                .comment("回响碎片 (伤害 +10)")
                .defineInRange("echo_shard", 50, 0, 100000);
            starTreasureMaxGlowstone = b
                .comment("萤石粉/萤石块 (伤害 +0.01 / +0.04)")
                .defineInRange("glowstone", 100, 0, 100000);
            starTreasureMaxStone = b
                .comment("石头/深板岩 (耐久 +1)")
                .defineInRange("stone", 100, 0, 100000);
            starTreasureMaxEndStone = b
                .comment("末地石 (耐久 +1)")
                .defineInRange("end_stone", 500, 0, 100000);
            starTreasureMaxObsidian = b
                .comment("黑曜石/哭泣的黑曜石 (耐久 +10)")
                .defineInRange("obsidian", 500, 0, 100000);
            starTreasureMaxBlackstone = b
                .comment("黑石 (耐久 +1)")
                .defineInRange("blackstone", 100, 0, 100000);
            starTreasureMaxNetherite = b
                .comment("下界合金锭/下界合金块 (伤害 +0.1 / +1)")
                .defineInRange("netherite", 100, 0, 100000);
            starTreasureMaxLapis = b
                .comment("青金石/青金石块 (伤害 +0.01 / +0.1)")
                .defineInRange("lapis", 50, 0, 100000);
            starTreasureMaxQuartz = b
                .comment("下界石英/下界石英块 (伤害 +0.1 / +0.4)")
                .defineInRange("quartz", 100, 0, 100000);
            starTreasureMaxGold = b
                .comment("金锭/金块 (耐久 +0.1 / +1)")
                .defineInRange("gold", 150, 0, 100000);
            starTreasureMaxCopper = b
                .comment("铜锭/铜块 (耐久 +0.1 / +1)")
                .defineInRange("copper", 1000, 0, 100000);
            starTreasureMaxModOre = b
                .comment("模组矿物：非原版命名空间的 forge:ores 方块 (伤害 +0.01)")
                .defineInRange("mod_ore", 1500, 0, 100000);
            b.pop();

            b.comment("最终属性总上限：三类加成先按次数累加，再各自截断到这里。",
                      "注意 echo_shard_damage 默认 +10/个，会很快撞上伤害总上限。")
                .push("total_max");
            starTreasureTotalMaxDamage = b
                .comment("武器伤害总上限")
                .defineInRange("damage", 100.0, 0.0, 1000000.0);
            starTreasureTotalMaxSpeed = b
                .comment("武器速度总上限")
                .defineInRange("speed", 600.0, 0.0, 1000000.0);
            starTreasureTotalMaxDurability = b
                .comment("武器耐久总上限")
                .defineInRange("durability", 1400.0, 0.0, 1000000.0);
            b.pop();

            starTreasureEchoShardDamage = b
                .comment("回响碎片每个的伤害增幅（默认 +10，与其他矿物差两个量级，需要单独调就改这里）")
                .defineInRange("echo_shard_damage", 10.0, 0.0, 1000000.0);

            starTreasureDurabilityMode = b
                .comment("耐久加成的生效方式（大小写随意，填了不认识的值按 BOTH 处理）：",
                         "  MAX_DAMAGE        - 提前用耐久池抵掉消耗（当前与 RESTORE_ON_BREAK 同一实现）",
                         "  RESTORE_ON_BREAK  - 耐久耗尽时消耗 1 点对应矿物把武器修回来",
                         "  BOTH              - 两者都做（默认）",
                         "  NONE              - 整体关闭耐久加成",
                         "注：Forge 1.20.1 没有出口能真正改大物品最大耐久（MAX_DAMAGE 属性是 MC 1.21 才加的），",
                         "    所以「耐久 +N」表现为「耐久池」，而不是属性面板上的数字变大。")
                .define("durability_mode", "BOTH");
            b.pop();

            // ================= 变态 =================
            b.comment("================= 变态 =================").push("pervert_enchantment");
            pervertLevel1Chance = b
                .comment("变态1级掠夺概率 (5%)")
                .defineInRange("level_1_chance", 0.05, 0.0, 1.0);
            pervertMaxChance = b
                .comment("变态满级掠夺概率 (45%)")
                .defineInRange("max_chance", 0.45, 0.0, 1.0);
            b.pop();

            // ================= 樱花粉 =================
            b.comment("================= 樱花粉 =================").push("cherry_blossom_enchantment");
            cherryBlossomMaxArmor = b
                .comment("樱花粉盔甲最大锻造数")
                .defineInRange("max_armor", 500, 0, 100000);
            cherryBlossomMaxFood = b
                .comment("樱花粉食物最大锻造数")
                .defineInRange("max_food", 200, 0, 100000);
            cherryBlossomMaxWeapon = b
                .comment("樱花粉武器最大锻造数")
                .defineInRange("max_weapon", 200, 0, 100000);
            cherryBlossomMaxTool = b
                .comment("樱花粉工具最大锻造数")
                .defineInRange("max_tool", 200, 0, 100000);
            b.pop();

    // ================= 杂项设置 =================
    b.comment("================= 杂项设置 =================").push("misc");
            miscInfoKeyShift = b
                .comment("查看特殊信息的热键 Shift")
                .define("info_key_shift", true);
            miscInfoKeyCtrl = b
                .comment("查看特殊信息的热键 Ctrl")
                .define("info_key_ctrl", true);
            b.pop();

            // ================= 药水抗性 =================
            b.comment("================= 药水抗性 =================").push("potion_resistance_enchantment");
            potionResistancePerLevel = b
                .comment("每级降低负面效果时长/效果等级的比例 (0.05 = 每级 5%)")
                .defineInRange("per_level_reduction", 0.05, 0.0, 1.0);
            potionResistanceAmplifierShare = b
                .comment("用于「降低效果等级」的档位占比 (0.5 = 一半压等级、一半压时长)")
                .defineInRange("amplifier_share", 0.5, 0.0, 1.0);
            b.pop();

            // ================= 寰宇破坏者 =================
            b.comment("================= 寰宇破坏者 =================").push("universe_breaker_enchantment");
            universeBreakerTierBoostBase = b
                .comment("有效工具等级抬升的常量项")
                .defineInRange("tier_boost_base", 1.0, 0.0, 64.0);
            universeBreakerTierBoostPerLevel = b
                .comment("每级抬升的工具等级档位")
                .defineInRange("tier_boost_per_level", 0.5, 0.0, 64.0);
            universeBreakerSpeedPerLevel = b
                .comment("挖掘速度加成, 每级 (与等级抬升同一算法)")
                .defineInRange("speed_per_level", 0.5, 0.0, 64.0);
            b.pop();

            // ================= 大运 =================
            b.comment("================= 大运 =================").push("great_fortune_enchantment");
            greatFortuneDamageMinPercent = b
                .comment("撞击伤害占自身攻击力的最低比例 (0.01 = 1%)")
                .defineInRange("damage_min_percent", 0.01, 0.0, 10.0);
            greatFortuneDamageMaxPercent = b
                .comment("撞击伤害占自身攻击力的最高比例 (0.10 = 10%)")
                .defineInRange("damage_max_percent", 0.10, 0.0, 10.0);
            greatFortuneDamageSpeedReference = b
                .comment("伤害百分比的速度基准 (0.10 = 玩家未加成时的属性速度)")
                .defineInRange("damage_speed_reference", 0.10, 0.0, 10.0);
            greatFortuneDamageSpeedRange = b
                .comment("从最低比例涨到最高比例所需的速度跨度")
                .defineInRange("damage_speed_range", 0.18, 0.001, 10.0);
            greatFortuneSpeedLevelMultiplier = b
                .comment("移速公式: 每级附魔的乘数 (设定原文里的 1.25)")
                .defineInRange("speed_level_multiplier", 1.25, 0.0, 100.0);
            greatFortuneSpeedBuffMultiplier = b
                .comment("移速公式: 速度 buff 的乘数 (设定原文里的 0.5%)")
                .defineInRange("speed_buff_multiplier", 0.005, 0.0, 100.0);
            greatFortuneBaseSpeedMultiplier = b
                .comment("移速公式: 基础速度的乘数 (0.05 = 5%)")
                .defineInRange("base_speed_multiplier", 0.05, 0.0, 100.0);
            greatFortuneSpeedDivisor = b
                .comment("移速公式最后的除数 (设定原文里的 2.2)")
                .defineInRange("speed_divisor", 2.2, 0.001, 100.0);
            greatFortuneFrostWalkerSpeedPerLevel = b
                .comment("冰霜行者联动: 每级额外移速 (0.15 = 15%)")
                .defineInRange("frost_walker_speed_per_level", 0.15, 0.0, 100.0);
            greatFortuneBoatSpeedShare = b
                .comment("坐船时船继承的速度比例 (0.15 = 15%)")
                .defineInRange("boat_speed_share", 0.15, 0.0, 100.0);
            greatFortuneBoatImpactMultiplier = b
                .comment("坐船撞击伤害倍率 (1.20 = 120%)")
                .defineInRange("boat_impact_multiplier", 1.20, 0.0, 100.0);
            b.pop();

            // ================= 游玩获取配置 =================
            acquisition = new AcquisitionSection(b);
        }
    }
}
