package cn.autoforged.rainbow_enchantment_mod.enchantment;

import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.AbstractIllager;
import net.minecraft.world.entity.monster.piglin.AbstractPiglin;
import net.minecraft.world.entity.npc.WanderingTrader;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentCategory;

public class PlunderEnchantment extends ModEnchantment {
    protected PlunderEnchantment(Rarity rarity, EquipmentSlot... slots) {
        super(rarity, EnchantmentCategory.WEAPON, slots);
    }

    @Override
    public int getMinCost(int level) {
        return 25;
    }

    @Override
    public int getMaxCost(int level) {
        return 50;
    }

    @Override
    public int getMaxLevel() {
        return 1;
    }

    @Override
    public boolean isTreasureOnly() {
        return true;
    }

    @Override
    public boolean canEnchant(ItemStack stack) {
        return stack.getItem() instanceof SwordItem || stack.getItem() instanceof BowItem
            || stack.getItem() instanceof CrossbowItem || stack.getItem() instanceof AxeItem;
    }

    @Override
    public boolean checkCompatibility(Enchantment pOther) {
        return false;
    }

    @Override
    public void doPostAttack(LivingEntity attacker, Entity target, int level) {
        if (!(target instanceof LivingEntity livingTarget)) return;
        if (attacker.level().isClientSide) return;
        if (!(attacker instanceof Player player)) return;

        if (attacker.level().random.nextDouble() >= ModConfig.COMMON.plunderChance.get()) return;

        ServerLevel serverLevel = (ServerLevel) attacker.level();

        boolean isVillagerTarget = livingTarget instanceof AbstractVillager
            || livingTarget instanceof AbstractIllager
            || livingTarget instanceof WanderingTrader;

        boolean isPiglinTarget = livingTarget instanceof AbstractPiglin;

        if (isVillagerTarget) {
            ItemStack emerald = new ItemStack(Items.EMERALD);
            serverLevel.addFreshEntity(new net.minecraft.world.entity.item.ItemEntity(
                serverLevel, target.getX(), target.getY() + 0.5, target.getZ(), emerald));
        }

        if (isPiglinTarget) {
            ItemStack gold = new ItemStack(Items.GOLD_INGOT);
            serverLevel.addFreshEntity(new net.minecraft.world.entity.item.ItemEntity(
                serverLevel, target.getX(), target.getY() + 0.5, target.getZ(), gold));
        }
    }
}
