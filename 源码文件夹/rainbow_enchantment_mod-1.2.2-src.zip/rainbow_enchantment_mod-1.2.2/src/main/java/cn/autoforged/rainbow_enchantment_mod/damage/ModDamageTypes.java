package cn.autoforged.rainbow_enchantment_mod.damage;

import cn.autoforged.rainbow_enchantment_mod.RainbowEnchantmentMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageType;

public final class ModDamageTypes {
    public static final ResourceKey<DamageType> OVERLOAD_DAMAGE =
        ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation(RainbowEnchantmentMod.MOD_ID, "overload_damage"));

    public static final ResourceKey<DamageType> RUIN_FORCE =
        ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation(RainbowEnchantmentMod.MOD_ID, "ruin_force"));

    private ModDamageTypes() {}
}
