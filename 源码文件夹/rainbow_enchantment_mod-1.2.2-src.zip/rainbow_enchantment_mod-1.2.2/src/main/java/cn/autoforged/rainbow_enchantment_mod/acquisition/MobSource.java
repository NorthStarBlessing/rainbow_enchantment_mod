package cn.autoforged.rainbow_enchantment_mod.acquisition;

import cn.autoforged.rainbow_enchantment_mod.config.AcquisitionSection;

/**
 * 「生物死亡掉落」类获取途径。全部是专属途径：只产出专属表里点名给它的附魔。
 */
public enum MobSource {
    EVOKER("evoker"),
    WITHER("wither"),
    BLAZE("blaze"),
    ELDER_GUARDIAN("elder_guardian");

    private final String id;

    MobSource(String id) {
        this.id = id;
    }

    public String id() {
        return this.id;
    }

    public AcquisitionSection.MobDrop config() {
        return switch (this) {
            case EVOKER -> ModAcquisition.section().evoker;
            case WITHER -> ModAcquisition.section().wither;
            case BLAZE -> ModAcquisition.section().blaze;
            case ELDER_GUARDIAN -> ModAcquisition.section().elderGuardian;
        };
    }
}
