package cn.autoforged.rainbow_enchantment_mod.enchantment;

import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentCategory;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class JudgmentEnchantment extends ModEnchantment {
    public static final Map<UUID, Integer> JUDGMENT_KILLS = new HashMap<>();
    public static final Map<UUID, Double> JUDGMENT_SIN = new HashMap<>();

    protected JudgmentEnchantment(Rarity rarity, EquipmentSlot... slots) {
        super(rarity, EnchantmentCategory.WEAPON, slots);
    }

    @Override
    public int getMinCost(int level) {
        return 30;
    }

    @Override
    public int getMaxCost(int level) {
        return 60;
    }

    @Override
    public int getMaxLevel() {
        return 30;
    }

    @Override
    public boolean isTreasureOnly() {
        return true;
    }

    @Override
    public boolean canEnchant(ItemStack stack) {
        return stack.getItem() instanceof SwordItem || stack.getItem() instanceof AxeItem
            || stack.getItem() instanceof BowItem || stack.getItem() instanceof CrossbowItem;
    }

    @Override
    public boolean checkCompatibility(Enchantment pOther) {
        if (pOther == ModEnchantments.RAINBOW.get()) return false;
        if (pOther == ModEnchantments.NIGHT_WALKER.get()) return false;
        return super.checkCompatibility(pOther);
    }

    public static float getDamageMultiplier(MobType mobType) {
        var c = ModConfig.COMMON;
        if (mobType == MobType.UNDEAD) return c.judgmentUndeadMultiplier.get().floatValue();
        if (mobType == MobType.ARTHROPOD) return c.judgmentArthropodMultiplier.get().floatValue();
        if (mobType == MobType.ILLAGER) return c.judgmentPillagerMultiplier.get().floatValue();
        return 1.0f;
    }

    public static int getKillDamageBonus(UUID playerUuid) {
        int kills = JUDGMENT_KILLS.getOrDefault(playerUuid, 0);
        // 每 10 击杀的加成值与上限都来自配置（judgment_enchantment 分组）。
        // 原先这里写死「kills / 10」= 每 10 杀 +1 点伤害，
        // 配置项 kill_damage_bonus 从未被读取，现已接上。
        double per10 = ModConfig.COMMON.judgmentKillDamageBonus.get();
        int maxBonus = ModConfig.COMMON.judgmentMaxKillBonus.get();
        return Math.min((int) ((kills / 10) * per10), maxBonus);
    }

    public static double getSinMultiplier(UUID playerUuid) {
        double sinMax = ModConfig.COMMON.judgmentSinMax.get();
        return 1.0 + Math.min(JUDGMENT_SIN.getOrDefault(playerUuid, 0.0), sinMax);
    }

    public static void recordSin(UUID playerUuid) {
        var c = ModConfig.COMMON;
        double sinBase = c.judgmentSinBase.get();
        double sinMax = c.judgmentSinMax.get();
        double sin = JUDGMENT_SIN.getOrDefault(playerUuid, 0.0) + sinBase;
        JUDGMENT_SIN.put(playerUuid, Math.min(sin, sinMax));
    }
}
