package cn.autoforged.rainbow_enchantment_mod.acquisition;

/**
 * 「战利品表」类获取途径。
 *
 * <p>{@code dedicated = true} 的途径只产出在
 * {@code [acquisition.exclusive]} 里点名给它的附魔；{@code false} 的是通用池，
 * 只产出「没有专属条目」的附魔。
 *
 * <p>村庄英雄送礼（{@link #HERO_GIFT}）也是通用池，只是它的概率折线按**英雄效果等级**取值。
 */
public enum AcquisitionSource {
    ANCIENT_CITY("ancient_city", false),
    END_CITY("end_city", false),
    SNOWY_CHEST("snowy_chest", false),
    BURIED_TREASURE("buried_treasure", false),
    FISHING("fishing", false),
    HERO_GIFT("hero_gift", false),
    STRONGHOLD_LIBRARY("stronghold_library", true),
    RUINED_PORTAL("ruined_portal", true);

    private final String id;
    private final boolean dedicated;

    AcquisitionSource(String id, boolean dedicated) {
        this.id = id;
        this.dedicated = dedicated;
    }

    public String id() {
        return this.id;
    }

    /** 是否专属途径（只出专属表里点名给它的附魔）。 */
    public boolean dedicated() {
        return this.dedicated;
    }

    public static AcquisitionSource byIdOrNull(String id) {
        for (AcquisitionSource source : values()) {
            if (source.id.equals(id)) {
                return source;
            }
        }
        return null;
    }
}
