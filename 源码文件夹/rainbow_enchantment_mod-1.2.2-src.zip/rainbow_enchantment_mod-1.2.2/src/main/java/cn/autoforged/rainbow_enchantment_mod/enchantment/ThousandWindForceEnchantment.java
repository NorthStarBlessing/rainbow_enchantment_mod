package cn.autoforged.rainbow_enchantment_mod.enchantment;

import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import net.minecraft.nbt.CompoundTag;

public class ThousandWindForceEnchantment extends ModEnchantment {
    public static final String THOUSAND_STARS_TAG = "thousand_wind_stars";

    protected ThousandWindForceEnchantment(Rarity rarity, EquipmentSlot... slots) {
        super(rarity, EnchantmentCategory.BOW, slots);
    }

    @Override
    public int getMinCost(int level) {
        return 20 + 10 * (level - 1);
    }

    @Override
    public int getMaxCost(int level) {
        return super.getMinCost(level) + 50;
    }

    @Override
    public int getMaxLevel() {
        return 5;
    }

    @Override
    public boolean isTreasureOnly() {
        return true;
    }

    @Override
    public boolean canEnchant(ItemStack stack) {
        return stack.getItem() instanceof BowItem;
    }

    public static int getStarCount(ItemStack stack) {
        var tag = stack.getTag();
        if (tag == null || !tag.contains(THOUSAND_STARS_TAG)) return 0;
        return tag.getInt(THOUSAND_STARS_TAG);
    }

    public static double getDamageMultiplier(ItemStack stack) {
        int stars = getStarCount(stack);
        return Math.pow(ModConfig.COMMON.windForceNetherStarBase.get(), stars);
    }

    public static double getRangeMultiplier(ItemStack stack) {
        int stars = getStarCount(stack);
        return Math.pow(ModConfig.COMMON.windForceNetherStarBase.get(), stars);
    }

    /**
     * ⚠ 千风之力<b>不再</b>在近战命中时触发。
     *
     * <p>维护者口径：千风之力是<b>弓箭</b>附魔 ——
     * 「蓄力弓箭会有进度条，进度条完毕时射出的弓箭为特殊弓箭，未满进度条 / 被打断则是普通箭」，
     * 箭命中后「打在地面上时只触发最低级的扩散效果，只有打怪物才会触发最高的扩散效果」。
     *
     * <p>现在的流程是：
     * {@code ArrowLooseEvent} 判定蓄满 → 射出一支带 {@code WindArrowMarker} 的特殊箭
     * → 箭命中时 {@code ModEvents.onWindArrowImpact} 按"打到地面 / 打到怪物"决定扩散等级
     * → {@code ParticleEffectManager} 播放扩散并逐环结算伤害。
     * 近战那条路径整个废弃，所以这里不再做任何事。
     */
    @Override
    public void doPostAttack(LivingEntity attacker, Entity target, int level) {
        // 故意留空：触发点已移到「满蓄力射出的特殊箭命中」，见 ModEvents.onArrowLoose / onWindArrowImpact
    }

    public static void applyWindWall(Player player, int level) {
        if (player.level().isClientSide) return;

        var c = ModConfig.COMMON;
        int windWallRange = c.windForceWallBaseRadius.get() + level * c.windForceWallRadiusPerLevel.get();
        AABB pushBox = player.getBoundingBox().inflate(windWallRange);
        Vec3 center = player.position();

        for (LivingEntity le : player.level().getEntitiesOfClass(LivingEntity.class, pushBox,
                e -> e != player && e.isAlive() && !player.isAlliedTo(e))) {
            Vec3 pushDir = le.position().subtract(center).normalize();
            le.push(pushDir.x * 0.5, 0.3, pushDir.z * 0.5);
        }

        for (Projectile p : player.level().getEntitiesOfClass(Projectile.class, pushBox,
                p -> p.getOwner() != player && p.isAlive())) {
            Vec3 pushDir = p.position().subtract(center).normalize();
            p.setDeltaMovement(p.getDeltaMovement().add(pushDir.scale(0.5)));
        }

        if (player.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.END_ROD,
                player.getX(), player.getY() + 0.5, player.getZ(),
                1, windWallRange, 0.1, windWallRange, 0.005);
        }
    }
}
