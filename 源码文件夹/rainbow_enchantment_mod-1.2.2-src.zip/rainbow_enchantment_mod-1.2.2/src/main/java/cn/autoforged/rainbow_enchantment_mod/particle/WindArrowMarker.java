package cn.autoforged.rainbow_enchantment_mod.particle;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Entity;

/**
 * 「千风特殊箭」的标记。
 *
 * <p>维护者口径：「蓄力弓箭会有进度条，进度条完毕时射出的弓箭为特殊弓箭，
 * 未满进度条 / 被打断则是普通箭」。
 *
 * <p>所以满蓄力射出的箭要能一路带着「我是一支特殊箭」这个身份飞到命中点，
 * 由命中点决定扩散等级：<b>打地面 → 最低级；打怪物 → 最高级</b>。
 * 标记写在实体的 persistentData 上，跨 tick、跨维度都跟着箭走。
 */
public final class WindArrowMarker {

    /** 标记键。只在 persistentData 里，不写进物品 NBT。 */
    private static final String TAG = "rainbow_wind_arrow";
    private static final String TAG_LEVEL = "level";
    private static final String TAG_STARS = "stars";

    private WindArrowMarker() {}

    /** 把一支箭标成「千风特殊箭」。 */
    public static void mark(Entity arrow, int enchantLevel, int stars) {
        CompoundTag data = arrow.getPersistentData();
        CompoundTag tag = new CompoundTag();
        tag.putInt(TAG_LEVEL, enchantLevel);
        tag.putInt(TAG_STARS, stars);
        data.put(TAG, tag);
    }

    public static boolean isMarked(Entity arrow) {
        return arrow.getPersistentData().contains(TAG, 10);
    }

    public static int getLevel(Entity arrow) {
        CompoundTag d = arrow.getPersistentData();
        return d.contains(TAG, 10) ? d.getCompound(TAG).getInt(TAG_LEVEL) : 0;
    }

    public static int getStars(Entity arrow) {
        CompoundTag d = arrow.getPersistentData();
        return d.contains(TAG, 10) ? d.getCompound(TAG).getInt(TAG_STARS) : 0;
    }

    /** 消耗掉标记（避免同一支箭重复触发）。 */
    public static void clear(Entity arrow) {
        arrow.getPersistentData().remove(TAG);
    }
}
