package cn.autoforged.rainbow_enchantment_mod.effect;

import cn.autoforged.rainbow_enchantment_mod.damage.ModDamageTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.world.entity.player.Player;

public class RuinWitherEffect extends MobEffect {
    public static final Map<UUID, Double> ATTACK_DAMAGE_CACHE = new HashMap<>();
    public static final Map<UUID, UUID> ATTACKER_CACHE = new HashMap<>();

    public RuinWitherEffect(MobEffectCategory category, int color) {
        super(category, color);
    }

    @Override
    public void applyEffectTick(LivingEntity entity, int amplifier) {
        if (!entity.level().isClientSide) {
            float maxHp = entity.getMaxHealth();
            float armor = entity.getArmorValue();
            float toughness = (float) entity.getAttributeValue(Attributes.ARMOR_TOUGHNESS);
            Double cachedAtkDmg = ATTACK_DAMAGE_CACHE.get(entity.getUUID());
            float atkDmg = cachedAtkDmg != null ? cachedAtkDmg.floatValue() : 0.0f;

            boolean hasDamageReduction = entity.hasEffect(MobEffects.DAMAGE_RESISTANCE);

            float rawDamage = maxHp * 0.05f + atkDmg * 0.01f;
            float finalDamage;
            if (hasDamageReduction) {
                finalDamage = rawDamage * (1.0f - 0.05f);
            } else {
                float dualDefense = armor + toughness * 0.5f;
                finalDamage = Math.max(1.0f, rawDamage - dualDefense);
            }

            var holder = entity.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ModDamageTypes.RUIN_FORCE);
            UUID attackerUUID = ATTACKER_CACHE.get(entity.getUUID());
            Player p = attackerUUID != null ? entity.level().getPlayerByUUID(attackerUUID) : null;
            if (p != null) {
                entity.hurt(new DamageSource(holder, p), finalDamage);
            } else {
                entity.hurt(new DamageSource(holder), finalDamage);
            }
        }
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        return duration % 20 == 0;
    }
}
