package cn.autoforged.rainbow_enchantment_mod.client;

import cn.autoforged.rainbow_enchantment_mod.RainbowEnchantmentMod;
import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import cn.autoforged.rainbow_enchantment_mod.enchantment.ModEnchantments;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.BowItem;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * 千风之力：蓄力进度条。
 *
 * <p>维护者口径：「蓄力弓箭会有进度条，进度条完毕时射出的弓箭为特殊弓箭，
 * 未满进度条 / 被打断则是普通箭」—— 之前世界里只有一个蓄力特效（老版是箭尖风环，
 * 2026-10-12 已改成玩家脚下的蓄力法阵 {@code ParticleEffectManager.spawnChargeArray}），
 * 屏幕上没有任何明确提示，玩家不好判断什么时候算「拉满」。
 *
 * <p><b>为什么不用网络包</b>：客户端本地就有完整的蓄力状态 ——
 * {@code LocalPlayer#getTicksUsingItem()}（{@code LivingEntity.java:3233}）
 * 直接返回 {@code useItem.getUseDuration() - getUseItemRemainingTicks()}，
 * 与服务端 {@code onPlayerTickChargeRings} 用的是同一个值，所以进度条与脚下法阵天然同步。
 *
 * <p><b>为什么必须 Bus.MOD</b>：{@code RegisterGuiOverlaysEvent} 是
 * {@code IModBusEvent}（在模组事件总线上发布），而 {@code @Mod.EventBusSubscriber}
 * 的默认总线是 {@code FORGE}。{@code value = Dist.CLIENT} 保证专用服务端不会加载这个类。
 */
@Mod.EventBusSubscriber(modid = RainbowEnchantmentMod.MOD_ID,
        bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class WindChargeHud {

    private static final int BAR_WIDTH = 62;
    private static final int BAR_HEIGHT = 5;

    private WindChargeHud() {}

    @SubscribeEvent
    public static void onRegisterOverlays(RegisterGuiOverlaysEvent event) {
        // 挂在准星之上（准星是原版 overlay，满足 registerAbove 只能对齐原版/自家 overlay 的约束）
        event.registerAbove(VanillaGuiOverlay.CROSSHAIR.id(), "wind_charge",
            (gui, graphics, partialTick, screenWidth, screenHeight) ->
                render(graphics, screenWidth, screenHeight));
    }

    private static void render(GuiGraphics graphics, int screenWidth, int screenHeight) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.options == null || mc.options.hideGui) return;
        if (!player.isUsingItem()) return;

        ItemStack useItem = player.getUseItem();
        if (!(useItem.getItem() instanceof BowItem)) return;
        if (useItem.getEnchantmentLevel(ModEnchantments.THOUSAND_WIND_FORCE.get()) <= 0) return;

        int chargeTicks = player.getTicksUsingItem();
        int need = Math.max(1, ModConfig.COMMON.fxWindChargeTicks.get());
        float progress = Math.min(1.0f, (float) chargeTicks / (float) need);
        // 与 onArrowLoose 的判据保持同一口径（vanilla 也是用 power == 1.0 标识满蓄力）
        boolean full = BowItem.getPowerForTime(chargeTicks) >= 1.0F;

        int x = (screenWidth - BAR_WIDTH) / 2;
        int y = (screenHeight - BAR_HEIGHT) / 2 + 18;   // 准星正下方

        graphics.fill(x - 1, y - 1, x + BAR_WIDTH + 1, y + BAR_HEIGHT + 1, 0xA0000000);
        graphics.fill(x, y, x + BAR_WIDTH, y + BAR_HEIGHT, 0xFF303030);

        int filled = (int) (BAR_WIDTH * progress);
        if (filled > 0) {
            graphics.fill(x, y, x + filled, y + BAR_HEIGHT, full ? 0xFF55FFFF : 0xFF66CC88);
        }

        if (full) {
            Component label = Component.translatable(
                "tooltip.rainbow_enchantment_mod.wind_charge_full");
            int w = mc.font.width(label);
            graphics.drawString(mc.font, label, (screenWidth - w) / 2, y - 11, 0xFF55FFFF, true);
        }
    }
}
