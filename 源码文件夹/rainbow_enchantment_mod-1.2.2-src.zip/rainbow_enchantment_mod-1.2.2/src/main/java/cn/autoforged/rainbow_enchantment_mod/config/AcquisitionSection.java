package cn.autoforged.rainbow_enchantment_mod.config;

import java.util.List;
import net.minecraftforge.common.ForgeConfigSpec;

/**
 * 「游玩获取配置」——本模组 37 个附魔在生存模式里到底怎么拿到。
 *
 * <p>归类（与 docs/ACQUISITION-SPEC.md 一致）：
 * <ul>
 *   <li><b>通用池途径</b>（古城 / 末地城 / 雪地 / 埋藏宝藏 / 钓鱼 / 村庄英雄送礼 / 图书管理员交易）：
 *       只产出「没有专属条目」的附魔，按 {@code curve_levels + curve_chances} 折线取概率；</li>
 *   <li><b>专属途径</b>（要塞图书馆 / 废弃传送门 / 唤魔者 / 凋灵 / 烈焰人 / 远古守卫者 /
 *       附魔台 / 判决机制）：只产出在 {@code [acquisition.exclusive]} 里点名给它的附魔。</li>
 * </ul>
 *
 * <p>概率折线：等级落在锚点之间线性插值，低于首锚点沿用首值，高于末锚点看
 * {@code above_last_level_chance}（负数 = 沿用末值）。
 */
public final class AcquisitionSection {
    // ================= 全局开关 =================
    public final ForgeConfigSpec.BooleanValue enabled;
    public final ForgeConfigSpec.BooleanValue logRolls;
    public final ForgeConfigSpec.BooleanValue rarityWeight;
    public final ForgeConfigSpec.IntValue rollsPerContainer;
    public final ForgeConfigSpec.ConfigValue<List<? extends String>> enchantmentWhitelist;
    public final ForgeConfigSpec.ConfigValue<List<? extends String>> enchantmentBlacklist;

    // ================= 幸运 / 超级幸运 =================
    public final ForgeConfigSpec.DoubleValue luckBonusPerPoint;
    public final ForgeConfigSpec.DoubleValue superLuckyMultiplier;
    public final ForgeConfigSpec.BooleanValue superLuckyUsesOwnChance;

    // ================= 原版途径总闸 =================
    public final ForgeConfigSpec.BooleanValue allowEnchantingTable;
    public final ForgeConfigSpec.BooleanValue allowVanillaRandomLoot;
    public final ForgeConfigSpec.BooleanValue allowVanillaVillagerBooks;

    // ================= 专属表 =================
    public final ForgeConfigSpec.ConfigValue<List<? extends String>> exclusive;

    // ================= 通用池途径 =================
    public final Source ancientCity;
    public final Source endCity;
    public final Source snowyChest;
    public final Source buriedTreasure;
    public final Source fishing;
    public final Librarian librarian;
    public final HeroGift heroGift;

    // ================= 专属途径（战利品表） =================
    public final Source strongholdLibrary;
    public final Source ruinedPortal;

    // ================= 专属途径（生物掉落） =================
    public final MobDrop evoker;
    public final MobDrop wither;
    public final MobDrop blaze;
    public final MobDrop elderGuardian;

    // ================= 附魔台两条隐藏机制 =================
    public final EnchantingTable enchantingTable;
    public final BonusEnchant bonusEnchant;

    public AcquisitionSection(ForgeConfigSpec.Builder b) {
        b.comment("==================================================",
                  "          游玩获取配置（附魔怎么拿到）",
                  "==================================================",
                  "本段决定生存里能从哪里、以多大概率拿到本模组的哪些附魔。",
                  "原版途径（附魔台随机 / 原版战利品随机附魔 / 原版村民附魔书）默认全部关闭，",
                  "由本段的概率表独占控制（需要放行时改 vanilla_sources.* 开关）。").push("acquisition");

        enabled = b
            .comment("总开关：关掉后本模组附魔不再从本段任何「获取途径」产出")
            .define("enabled", true);
        logRolls = b
            .comment("调试：把每一次获取判定（来源 / 附魔 / 等级 / 概率 / 是否命中）打进日志")
            .define("log_rolls", false);
        rarityWeight = b
            .comment("抽取附魔时是否按原版稀有度权重加权",
                     "true = 常见:少见:稀有:极稀有 = 10:5:2:1；false = 所有候选等概率")
            .define("rarity_weight", true);
        rollsPerContainer = b
            .comment("每个宝箱 / 每次钓鱼最多判定几次（1 = 最多产出一本）")
            .defineInRange("rolls_per_container", 1, 1, 10);
        enchantmentWhitelist = b
            .comment("参与获取的附魔白名单（注册名，如 rainbow_enchantment_mod:rainbow 或短名 rainbow）",
                     "留空 = 全部 37 个附魔都参与；非空 = 只有列出的参与")
            .defineList("enchantment_whitelist", List.of(), it -> it instanceof String);
        enchantmentBlacklist = b
            .comment("不参与获取的附魔黑名单，优先级高于白名单")
            .defineList("enchantment_blacklist", List.of(), it -> it instanceof String);

        luckBonusPerPoint = b
            .comment("每 1 点幸运对概率的相对加成（0.05 = +5%）；负幸运按同比例降低",
                     "幸运取自原版：宝箱 = 玩家幸运属性；钓鱼 = 海之眷顾 + 玩家幸运；生物掉落 = 击杀者幸运")
            .defineInRange("luck_bonus_per_point", 0.05, 0.0, 10.0);
        superLuckyMultiplier = b
            .comment("玩家身上有「超级幸运」时，宝箱 / 钓鱼 / 送礼概率的倍率（2.0 = 翻倍）")
            .defineInRange("super_lucky_multiplier", 2.0, 1.0, 100.0);
        superLuckyUsesOwnChance = b
            .comment("是否先按「超级幸运」自身的翻倍概率判定一次，成功了才翻倍",
                     "false = 只要带着超级幸运就必定翻倍")
            .define("super_lucky_uses_own_chance", false);

        b.comment("--- 原版途径总闸（默认全关：获取概率由本配置独占）---").push("vanilla_sources");
        allowEnchantingTable = b
            .comment("是否允许附魔台随机刷出本模组附魔（走原版候选池）",
                     "注：原版把「附魔台」和「原版随机附魔战利品」挂在同一个 isDiscoverable 标记上，",
                     "所以这两个开关只要有一个为 true，两者会同时被放行")
            .define("allow_enchanting_table", false);
        allowVanillaRandomLoot = b
            .comment("是否允许原版战利品表的随机附魔（enchant_randomly / enchant_with_levels）刷出本模组附魔")
            .define("allow_vanilla_random_loot", false);
        allowVanillaVillagerBooks = b
            .comment("是否允许原版图书管理员的「随机附魔书」交易卖出本模组附魔")
            .define("allow_vanilla_villager_books", false);
        b.pop();

        // ── 专属表 ──
        exclusive = b
            .comment("【专属表】格式：\"附魔=来源1,来源2\"，一行一个；未列出的附魔 = 通用池（所有通用途径都能出）",
                     "来源 id：ancient_city / end_city / snowy_chest / buried_treasure / fishing /",
                     "         librarian / hero_gift / stronghold_library / ruined_portal /",
                     "         evoker / wither / blaze / elder_guardian / enchanting_table / bonus_enchant",
                     "默认 = 需求里「点名并指定来源」的 20 个附魔（其余 17 个留在通用池）")
            .defineList("exclusive", List.of(
                "huff=enchanting_table",
                "ender_gaze=enchanting_table",
                "barbarian_vanguard=enchanting_table",
                "night_walker=enchanting_table",
                "pervert=enchanting_table",
                "super_nuke=enchanting_table",
                "great_fortune=enchanting_table",
                "judgment=bonus_enchant",
                "space_slash=evoker",
                "frost=evoker",
                "ocean_strike=evoker",
                "eternal=evoker",
                "double=evoker",
                "sea_god_explorer=evoker",
                "starlight_force=wither",
                "thousand_wind_force=wither",
                "eternal_flame=blaze",
                "oxygen=elder_guardian",
                "cherry_blossom=stronghold_library",
                "forest_strike=ruined_portal"
            ), it -> it instanceof String);

        b.comment("--- 通用池途径 ---").push("sources");

        ancientCity = new Source(b, "ancient_city",
            "古城宝箱（1 级 45%、2 级 41%，古城只出 1~2 级）",
            List.of("minecraft:chests/ancient_city", "minecraft:chests/ancient_city_ice_box"),
            1, 2, List.of(1, 2), List.of(0.45D, 0.41D), -1.0D);

        endCity = new Source(b, "end_city",
            "末地城宝箱（2~5 级 40%~22% 线性过渡，6 级及以上固定 0.75%）",
            List.of("minecraft:chests/end_city_treasure"),
            2, 0, List.of(2, 5), List.of(0.40D, 0.22D), 0.0075D);

        snowyChest = new Source(b, "snowy_chest",
            "雪地宝箱（雪屋 + 雪地村庄房屋，所有等级固定 1.7333%）",
            List.of("minecraft:chests/igloo_chest", "minecraft:chests/village/village_snowy_house"),
            1, 0, List.of(1), List.of(0.017333D), -1.0D);

        buriedTreasure = new Source(b, "buried_treasure",
            "埋藏的宝藏（1~3 级 7.5%，4~6 级 0.133%~0.0233% 线性过渡，7 级及以上固定 0.0155%）",
            List.of("minecraft:chests/buried_treasure"),
            1, 0, List.of(1, 3, 4, 6), List.of(0.075D, 0.075D, 0.00133D, 0.000233D), 0.000155D);

        fishing = new Source(b, "fishing",
            "钓鱼（所有等级固定 7.75%）",
            List.of("minecraft:gameplay/fishing"),
            1, 0, List.of(1), List.of(0.0775D), -1.0D);

        librarian = new Librarian(b);

        heroGift = new HeroGift(b);

        b.pop();  // sources

        b.comment("--- 专属途径：战利品表 ---").push("dedicated_sources");

        strongholdLibrary = new Source(b, "stronghold_library",
            "要塞图书馆（樱花粉专属，固定 12.32%）",
            List.of("minecraft:chests/stronghold_library"),
            1, 0, List.of(1), List.of(0.1232D), -1.0D);

        ruinedPortal = new Source(b, "ruined_portal",
            "废弃传送门（森林附加专属，固定 15.5%）",
            List.of("minecraft:chests/ruined_portal"),
            1, 0, List.of(1), List.of(0.155D), -1.0D);

        b.pop();

        b.comment("--- 专属途径：生物掉落 ---").push("mob_drops");

        evoker = new MobDrop(b, "evoker",
            "唤魔者（7.75%，1~3 级，受抢夺影响）",
            List.of("minecraft:evoker"), 0.0775D, 1, 3, true, 0.05D, true);

        wither = new MobDrop(b, "wither",
            "凋灵（5.25%，1~5 级，抢夺无效）",
            List.of("minecraft:wither"), 0.0525D, 1, 5, false, 0.0D, true);

        blaze = new MobDrop(b, "blaze",
            "烈焰人（8.55%，1~5 级，抢夺无效）",
            List.of("minecraft:blaze"), 0.0855D, 1, 5, false, 0.0D, true);

        elderGuardian = new MobDrop(b, "elder_guardian",
            "远古守卫者（5.52%，固定 1 级，抢夺无效）",
            List.of("minecraft:elder_guardian"), 0.0552D, 1, 1, false, 0.0D, true);

        b.pop();

        b.comment("--- 专属途径：附魔台两条隐藏机制 ---").push("enchanting");

        enchantingTable = new EnchantingTable(b);
        bonusEnchant = new BonusEnchant(b);

        b.pop();   // enchanting
        b.pop();   // acquisition
    }

    /**
     * 一条「战利品表」途径（通用池或专属池都复用）。
     *
     * <p>概率折线用两个平行列表表达：{@code curve_levels} 是附魔等级锚点，
     * {@code curve_chances} 是对应概率；长度必须一致。
     */
    public static final class Source {
        public final ForgeConfigSpec.BooleanValue enabled;
        public final ForgeConfigSpec.ConfigValue<List<? extends String>> lootTables;
        public final ForgeConfigSpec.IntValue levelMin;
        public final ForgeConfigSpec.IntValue levelMax;
        public final ForgeConfigSpec.ConfigValue<List<? extends Integer>> curveLevels;
        public final ForgeConfigSpec.ConfigValue<List<? extends Double>> curveChances;
        public final ForgeConfigSpec.DoubleValue aboveLastLevelChance;

        Source(ForgeConfigSpec.Builder b, String id, String description,
               List<String> defaultTables, int levelMin, int levelMax,
               List<Integer> curveLevels, List<Double> curveChances, double above) {
            b.comment(description).push(id);
            enabled = b.comment("是否启用这条途径").define("enabled", true);
            lootTables = b
                .comment("这条途径挂靠的原版战利品表（可自行增删）")
                .defineList("loot_tables", defaultTables, it -> it instanceof String);
            this.levelMin = b
                .comment("允许产出的附魔等级下限（1 起算）")
                .defineInRange("level_min", levelMin, 1, 30);
            this.levelMax = b
                .comment("允许产出的附魔等级上限；0 = 跟随附魔自身最高等级")
                .defineInRange("level_max", levelMax, 0, 30);
            this.curveLevels = b
                .comment("概率折线的等级锚点（升序），与 curve_chances 一一对应")
                .defineList("curve_levels", curveLevels, it -> it instanceof Number);
            this.curveChances = b
                .comment("概率折线的概率值，与 curve_levels 一一对应（0.45 = 45%）")
                .defineList("curve_chances", curveChances, it -> it instanceof Number);
            aboveLastLevelChance = b
                .comment("等级高于折线末端时的概率；负数 = 沿用折线末端那一档")
                .defineInRange("above_last_level_chance", above, -1.0D, 1.0D);
            b.pop();
        }
    }

    /**
     * 村庄英雄送礼（图书管理员礼物表）。
     *
     * <p>注意：这里的「等级」是**村庄英雄效果等级**（1 起算），不是附魔等级；
     * 附魔等级另由 {@code enchant_level_min / enchant_level_max} 控制。
     */
    public static final class HeroGift {
        public final ForgeConfigSpec.BooleanValue enabled;
        public final ForgeConfigSpec.ConfigValue<List<? extends String>> lootTables;
        public final ForgeConfigSpec.ConfigValue<List<? extends Integer>> heroLevels;
        public final ForgeConfigSpec.ConfigValue<List<? extends Double>> heroChances;
        public final ForgeConfigSpec.DoubleValue aboveLastLevelChance;
        public final ForgeConfigSpec.IntValue enchantLevelMin;
        public final ForgeConfigSpec.IntValue enchantLevelMax;
        public final ForgeConfigSpec.BooleanValue superLuckyApplies;

        HeroGift(ForgeConfigSpec.Builder b) {
            b.comment("村庄英雄送礼：英雄 1 级 0.25%、2 级 2.26%、3 级 5.76%（每次收到礼物判定一次）",
                      "原版图书管理员的礼物表只给普通书，这里额外按概率给一本本模组附魔书").push("hero_gift");
            enabled = b.comment("是否启用").define("enabled", true);
            lootTables = b
                .comment("villager 投掷礼物用的战利品表（默认只图书管理员；要全职业就把 13 张表都加进来）")
                .defineList("loot_tables", List.of("minecraft:gameplay/hero_of_the_village/librarian_gift"),
                    it -> it instanceof String);
            heroLevels = b
                .comment("概率折线的「村庄英雄等级」锚点")
                .defineList("hero_levels", List.of(1, 2, 3), it -> it instanceof Number);
            heroChances = b
                .comment("与 hero_levels 一一对应的概率（0.0025 = 0.25%）")
                .defineList("hero_chances", List.of(0.0025D, 0.0226D, 0.0576D), it -> it instanceof Number);
            aboveLastLevelChance = b
                .comment("英雄等级高于折线末端时的概率；负数 = 沿用末端值")
                .defineInRange("above_last_level_chance", -1.0D, -1.0D, 1.0D);
            enchantLevelMin = b
                .comment("产出的附魔等级下限")
                .defineInRange("enchant_level_min", 1, 1, 30);
            enchantLevelMax = b
                .comment("产出的附魔等级上限；0 = 跟随附魔自身最高等级")
                .defineInRange("enchant_level_max", 0, 0, 30);
            superLuckyApplies = b
                .comment("是否吃「超级幸运」翻倍（能通过村民找到收礼的玩家）")
                .define("super_lucky_applies", true);
            b.pop();
        }
    }

    /** 一条「生物死亡掉落」途径。 */
    public static final class MobDrop {
        public final ForgeConfigSpec.BooleanValue enabled;
        public final ForgeConfigSpec.ConfigValue<List<? extends String>> entities;
        public final ForgeConfigSpec.DoubleValue chance;
        public final ForgeConfigSpec.IntValue levelMin;
        public final ForgeConfigSpec.IntValue levelMax;
        public final ForgeConfigSpec.BooleanValue lootingEffect;
        public final ForgeConfigSpec.DoubleValue lootingBonusPerLevel;
        public final ForgeConfigSpec.BooleanValue playerKillOnly;

        MobDrop(ForgeConfigSpec.Builder b, String id, String description, List<String> entities,
                double chance, int levelMin, int levelMax, boolean lootingEffect,
                double lootingBonusPerLevel, boolean playerKillOnly) {
            b.comment(description).push(id);
            enabled = b.comment("是否启用").define("enabled", true);
            this.entities = b
                .comment("触发掉落的生物类型（注册名）")
                .defineList("entities", entities, it -> it instanceof String);
            this.chance = b
                .comment("每次击杀的掉落概率（0.0775 = 7.75%）")
                .defineInRange("chance", chance, 0.0D, 1.0D);
            this.levelMin = b
                .comment("掉落的附魔等级下限")
                .defineInRange("level_min", levelMin, 1, 30);
            this.levelMax = b
                .comment("掉落的附魔等级上限；0 = 跟随附魔自身最高等级")
                .defineInRange("level_max", levelMax, 0, 30);
            this.lootingEffect = b
                .comment("抢夺是否提高概率")
                .define("looting_effect", lootingEffect);
            this.lootingBonusPerLevel = b
                .comment("抢夺每级的相对加成（0.05 = 每级 +5%）；looting_effect = false 时无效")
                .defineInRange("looting_bonus_per_level", lootingBonusPerLevel, 0.0D, 10.0D);
            this.playerKillOnly = b
                .comment("是否要求玩家击杀（false = 任何死因都掉）")
                .define("player_kill_only", playerKillOnly);
            b.pop();
        }
    }

    /** 满级附魔台的隐藏追加：12.75% 概率附出 7 个指定附魔之一。 */
    public static final class EnchantingTable {
        public final ForgeConfigSpec.BooleanValue enabled;
        public final ForgeConfigSpec.IntValue requiredPower;
        public final ForgeConfigSpec.DoubleValue chance;
        public final ForgeConfigSpec.ConfigValue<List<? extends String>> enchantments;
        public final ForgeConfigSpec.IntValue levelMin;
        public final ForgeConfigSpec.IntValue levelMax;

        EnchantingTable(ForgeConfigSpec.Builder b) {
            b.comment("满级附魔台的隐藏追加：原版满级附魔台（15 书架）完成附魔时，",
                      "有 12.75% 概率额外附出下面 7 个附魔之一（预览不可见、不需要玩家选中）").push("enchanting_table");
            enabled = b.comment("是否启用").define("enabled", true);
            requiredPower = b
                .comment("要求的最低书架威力（原版满级 = 15）")
                .defineInRange("required_power", 15, 0, 15);
            chance = b
                .comment("触发概率（0.1275 = 12.75%）")
                .defineInRange("chance", 0.1275D, 0.0D, 1.0D);
            enchantments = b
                .comment("可被追加的附魔（本模组附魔的短名）")
                .defineList("enchantments", List.of("huff", "ender_gaze", "barbarian_vanguard",
                    "night_walker", "pervert", "super_nuke", "great_fortune"), it -> it instanceof String);
            levelMin = b
                .comment("追加等级下限")
                .defineInRange("level_min", 1, 1, 30);
            levelMax = b
                .comment("追加等级上限；0 = 跟随附魔自身最高等级")
                .defineInRange("level_max", 0, 0, 30);
            b.pop();
        }
    }

    /** 附魔台的判决隐藏追加：固定 15.55%，等级按书架数查表。 */
    public static final class BonusEnchant {
        public final ForgeConfigSpec.BooleanValue enabled;
        public final ForgeConfigSpec.DoubleValue chance;
        public final ForgeConfigSpec.ConfigValue<String> enchantment;
        public final ForgeConfigSpec.ConfigValue<List<? extends Integer>> levelMinByPower;
        public final ForgeConfigSpec.ConfigValue<List<? extends Integer>> levelMaxByPower;
        public final ForgeConfigSpec.BooleanValue keepHigher;

        BonusEnchant(ForgeConfigSpec.Builder b) {
            b.comment("附魔台的判决隐藏追加：完成附魔时固定 15.55% 概率附出判决，",
                      "判决等级由**当前附魔台的书架数**决定（见下面两张 16 项的表，下标 = 书架数 0~15）").push("bonus_enchant");
            enabled = b.comment("是否启用").define("enabled", true);
            chance = b
                .comment("触发概率（0.1555 = 15.55%）")
                .defineInRange("chance", 0.1555D, 0.0D, 1.0D);
            enchantment = b
                .comment("要追加的附魔（本模组附魔的短名）")
                .define("enchantment", "judgment");
            levelMinByPower = b
                .comment("各书架数对应的判决等级下限（下标 0~15）",
                         "0书架→1，1~2书架→1，3~4→2，5~6→3，7~8→5，9→6，10→7，11→8，12~13→9，14→10，15→11")
                .defineList("level_min_by_power",
                    List.of(1, 1, 1, 2, 2, 3, 3, 5, 5, 6, 7, 8, 9, 9, 10, 11), it -> it instanceof Number);
            levelMaxByPower = b
                .comment("各书架数对应的判决等级上限（下标 0~15）",
                         "0书架→1，1~2书架→2，3~4→3，5~6→4，7~8→6，9→7，10→8，11→9，12~13→10，14→11，15→20")
                .defineList("level_max_by_power",
                    List.of(1, 2, 2, 3, 3, 4, 4, 6, 6, 7, 8, 9, 10, 10, 11, 20), it -> it instanceof Number);
            keepHigher = b
                .comment("物品已有更高等级的同名附魔时不降级")
                .define("keep_higher", true);
            b.pop();
        }
    }

    /**
     * 图书管理员（附魔师）交易途径；三个按职业等级 1~5 索引的平行列表。
     */
    public static final class Librarian {
        public final ForgeConfigSpec.BooleanValue enabled;
        public final ForgeConfigSpec.BooleanValue compensateSelection;
        public final ForgeConfigSpec.ConfigValue<List<? extends Double>> chanceByTier;
        public final ForgeConfigSpec.ConfigValue<List<? extends Integer>> levelMinByTier;
        public final ForgeConfigSpec.ConfigValue<List<? extends Integer>> levelMaxByTier;
        public final ForgeConfigSpec.IntValue emeraldBase;
        public final ForgeConfigSpec.IntValue emeraldRandomBound;
        public final ForgeConfigSpec.IntValue emeraldPerEnchantLevel;
        public final ForgeConfigSpec.IntValue emeraldFlatPerEnchantLevel;
        public final ForgeConfigSpec.DoubleValue treasurePriceFactor;
        public final ForgeConfigSpec.IntValue emeraldCap;
        public final ForgeConfigSpec.IntValue maxUses;
        public final ForgeConfigSpec.ConfigValue<List<? extends Integer>> xpByTier;
        public final ForgeConfigSpec.DoubleValue priceMultiplier;

        Librarian(ForgeConfigSpec.Builder b) {
            b.comment("图书管理员（附魔师）出售本模组附魔书：",
                      "1 级 15%（售 1~3 级）、2 级 20%（1~3 级）、3 级 22.5%（2~4 级）、",
                      "4 级 25.5%（3~5 级）、5 级 28.5%（4~5 级）").push("librarian");
            enabled = b.comment("是否启用").define("enabled", true);
            compensateSelection = b
                .comment("是否补偿原版「从该等级交易表里随机抽 2 条」的机制",
                         "true（推荐）= 让 chance_by_tier 表示「村民真的卖出这本书」的最终概率")
                .define("compensate_selection", true);
            chanceByTier = b
                .comment("按职业等级 1~5 索引的最终概率（0.15 = 15%）")
                .defineList("chance_by_tier", List.of(0.15D, 0.20D, 0.225D, 0.255D, 0.285D),
                    it -> it instanceof Number);
            levelMinByTier = b
                .comment("按职业等级 1~5 索引的「可售附魔等级」下限")
                .defineList("enchant_level_min_by_tier", List.of(1, 1, 2, 3, 4), it -> it instanceof Number);
            levelMaxByTier = b
                .comment("按职业等级 1~5 索引的「可售附魔等级」上限")
                .defineList("enchant_level_max_by_tier", List.of(3, 3, 4, 5, 5), it -> it instanceof Number);
            emeraldBase = b.comment("价格公式：基础绿宝石数").defineInRange("emerald_base", 2, 0, 64);
            emeraldRandomBound = b
                .comment("价格公式：随机项上界 = 此值 + 附魔等级 x 每级项")
                .defineInRange("emerald_random_bound", 5, 0, 64);
            emeraldPerEnchantLevel = b
                .comment("价格公式：随机项里每个附魔等级贡献的数值")
                .defineInRange("emerald_per_enchant_level", 10, 0, 64);
            emeraldFlatPerEnchantLevel = b
                .comment("价格公式：固定项里每个附魔等级贡献的数值")
                .defineInRange("emerald_flat_per_enchant_level", 3, 0, 64);
            treasurePriceFactor = b
                .comment("宝藏类附魔的价格倍率（原版是 x2）")
                .defineInRange("treasure_price_factor", 2.0, 1.0, 10.0);
            emeraldCap = b.comment("绿宝石单价上限").defineInRange("emerald_cap", 64, 1, 64);
            maxUses = b.comment("每条交易可成交次数").defineInRange("max_uses", 12, 1, 64);
            xpByTier = b
                .comment("按职业等级 1~5 索引的村民经验")
                .defineList("villager_xp_by_tier", List.of(2, 5, 10, 15, 20), it -> it instanceof Number);
            priceMultiplier = b
                .comment("原版 MerchantOffer 的价格浮动系数")
                .defineInRange("price_multiplier", 0.2D, 0.0D, 1.0D);
            b.pop();
        }
    }
}
