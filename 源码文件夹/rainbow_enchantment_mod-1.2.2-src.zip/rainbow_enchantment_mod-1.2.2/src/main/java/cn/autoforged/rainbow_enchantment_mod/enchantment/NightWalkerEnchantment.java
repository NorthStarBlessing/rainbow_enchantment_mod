package cn.autoforged.rainbow_enchantment_mod.enchantment;

import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import cn.autoforged.rainbow_enchantment_mod.damage.ModDamageTypes;
import cn.autoforged.rainbow_enchantment_mod.event.ModEvents;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentCategory;

public class NightWalkerEnchantment extends ModEnchantment {
    protected NightWalkerEnchantment(Rarity rarity, EquipmentSlot... slots) {
        super(rarity, EnchantmentCategory.WEAPON, slots);
    }

    @Override
    public int getMinCost(int level) {
        return 20;
    }

    @Override
    public int getMaxCost(int level) {
        return 60;
    }

    @Override
    public int getMaxLevel() {
        return 1;
    }

    @Override
    public boolean isTreasureOnly() {
        return true;
    }

    @Override
    public boolean canEnchant(ItemStack stack) {
        return stack.getItem() instanceof SwordItem || stack.getItem() instanceof BowItem
            || stack.getItem() instanceof CrossbowItem || stack.getItem() instanceof AxeItem;
    }

    @Override
    public void doPostAttack(LivingEntity attacker, Entity target, int level) {
        if (target instanceof LivingEntity livingTarget && !target.level().isClientSide) {
            if (!attacker.level().isNight()) return;

            double weaponDamage = attacker.getAttributeValue(Attributes.ATTACK_DAMAGE);
            float bonus = (float) (weaponDamage * ModConfig.COMMON.nightWalkerDamageMultiplier.get() + ModConfig.COMMON.nightWalkerDamageConstant.get());

            var holder = target.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ModDamageTypes.OVERLOAD_DAMAGE);
            livingTarget.hurt(new DamageSource(holder), bonus);

            float rainbowExtra = getRainbowNightWalkerExtra(attacker);
            if (rainbowExtra > 0) {
                livingTarget.hurt(new DamageSource(holder), rainbowExtra);
            }
        }
    }

    private float getRainbowNightWalkerExtra(LivingEntity attacker) {
        ItemStack weapon = attacker.getMainHandItem();
        int rainbowLevel = weapon.getEnchantmentLevel(ModEnchantments.RAINBOW.get());
        if (rainbowLevel <= 0) return 0;

        int[] counts = ModEvents.countDyes(weapon);
        int unique = counts[0];
        int duplicate = counts[1];
        if (unique <= 0 && duplicate <= 0) return 0;

        double rawBonus = (unique + duplicate) * rainbowLevel;
        double rainbowMultiplier = ModConfig.COMMON.rainbowSwordDamageMultiplier.get();
        double nwMultiplier = ModConfig.COMMON.rainbowNightWalkerMultiplier.get();
        double extraDmg = rawBonus * rainbowMultiplier * (nwMultiplier - 1.0);
        return (float) extraDmg;
    }
}
