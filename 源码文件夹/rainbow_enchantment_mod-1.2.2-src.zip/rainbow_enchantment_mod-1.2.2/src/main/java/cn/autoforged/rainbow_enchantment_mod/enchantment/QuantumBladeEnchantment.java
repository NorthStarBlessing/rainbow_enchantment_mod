package cn.autoforged.rainbow_enchantment_mod.enchantment;

import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import cn.autoforged.rainbow_enchantment_mod.damage.ModDamageTypes;
import cn.autoforged.rainbow_enchantment_mod.effect.ModEffects;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.Enchantments;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class QuantumBladeEnchantment extends ModEnchantment {
    private static final Map<UUID, Long> MAX_HP_DEDUCTION_COOLDOWN = new HashMap<>();

    /** 扣上限用的属性修饰符 ID，按目标实体 UUID 派生，保证同一个目标始终是同一个修饰符。 */
    private static final String MAX_HP_MODIFIER_NAME = "Quantum Blade max HP deduction";
    private static UUID maxHpModifierId(UUID targetId) {
        return UUID.nameUUIDFromBytes(("quantum_blade_max_hp:" + targetId).getBytes());
    }

    /** 每个目标「上限被扣」的到期游戏刻；到期后移除修饰符恢复上限。 */
    private static final Map<UUID, Long> MAX_HP_MODIFIER_EXPIRY = new HashMap<>();

    protected QuantumBladeEnchantment(Rarity rarity, EquipmentSlot... slots) {
        super(rarity, EnchantmentCategory.WEAPON, slots);
    }

    @Override
    public int getMinCost(int level) {
        return 30;
    }

    @Override
    public int getMaxCost(int level) {
        return 60;
    }

    @Override
    public int getMaxLevel() {
        return 1;
    }

    @Override
    public boolean isTreasureOnly() {
        return true;
    }

    @Override
    public boolean checkCompatibility(Enchantment pOther) {
        if (pOther == Enchantments.FIRE_ASPECT) return false;
        if (pOther == ModEnchantments.ETERNAL_FLAME.get()) return false;
        if (pOther == ModEnchantments.FROST.get()) return false;
        if (pOther == ModEnchantments.OCEAN_STRIKE.get()) return false;
        return super.checkCompatibility(pOther);
    }

    @Override
    public void doPostAttack(LivingEntity attacker, Entity target, int level) {
        if (target instanceof LivingEntity livingTarget && !target.level().isClientSide) {
            applyCorrosion(livingTarget);
            applyMaxHpDeduction(attacker, livingTarget);

            sweepAttack(attacker, target, level);
        }
    }

    private void applyCorrosion(LivingEntity target) {
        target.addEffect(new MobEffectInstance(ModEffects.CORROSION.get(), 100, 0));
    }

    private void applyMaxHpDeduction(LivingEntity attacker, LivingEntity target) {
        long now = attacker.level().getGameTime();
        int cooldown = ModConfig.COMMON.quantumBladeCooldownTicks.get();
        Long lastTrigger = MAX_HP_DEDUCTION_COOLDOWN.get(attacker.getUUID());
        if (lastTrigger != null && (now - lastTrigger) < cooldown) return;

        MAX_HP_DEDUCTION_COOLDOWN.put(attacker.getUUID(), now);

        float deductionPct = ModConfig.COMMON.quantumBladeMaxHpDeductionPercent.get().floatValue();

        // 「减少百分比生命值上限」应当是**真的扣上限**，而不是打一发等量伤害。
        //
        // 【原来的写法为什么不是扣上限】
        // 旧代码是：
        //     float maxHpDamage = target.getMaxHealth() * deductionPct;
        //     target.hurt(new DamageSource(OVERLOAD_DAMAGE holder), maxHpDamage);
        // 这只是造成了一次「等于当前上限 × 百分比」的普通伤害：上限一点没变，
        // 而且这发伤害还会走护甲/减伤/无敌帧，实际掉血往往远小于配置值，
        // 表现就是「减百分比生命值上限无法触发」。
        //
        // 【现在的做法】
        // 给目标的 MAX_HEALTH 属性挂一个负数乘法修饰符（MULTIPLY_TOTAL，即扣掉当前上限的 pct），
        // 维持 quantumBladeCooldownTicks 这么久，到期由 tickMaxHpModifiers() 摘掉恢复。
        // 上限被扣到低于当前血量时，把血量夹到新上限，避免出现「血比上限还多」。
        AttributeInstance maxHealth = target.getAttribute(Attributes.MAX_HEALTH);
        if (maxHealth != null) {
            UUID modifierId = maxHpModifierId(target.getUUID());
            maxHealth.removeModifier(modifierId);

            // MULTIPLY_TOTAL 的语义是 base × (1 + Σamount)，这里的 base 是「基础值」而不是
            // 「当前最终值」。上面先 removeModifier 清掉旧修饰符，再取 getBaseValue()，
            // 因此反复触发也不会累积缩放（否则每次都会在上次已扣的基础上再扣 5%）。
            double base = maxHealth.getBaseValue();
            double newMax = Math.max(1.0, base * (1.0 - deductionPct));
            double amount = (newMax / Math.max(base, 1.0)) - 1.0;
            maxHealth.addTransientModifier(new AttributeModifier(
                modifierId, MAX_HP_MODIFIER_NAME, amount, AttributeModifier.Operation.MULTIPLY_TOTAL));

            MAX_HP_MODIFIER_EXPIRY.put(target.getUUID(), now + cooldown);

            if (target.getHealth() > newMax) {
                target.setHealth((float) newMax);
            }
        }

        if (target.level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.WITCH, target.getX(), target.getY() + target.getBbHeight() * 0.5, target.getZ(),
                12, 0.4, 0.4, 0.4, 0.05);
        }
    }

    /**
     * 移除到期的「上限扣除」修饰符，让目标的最大生命值恢复。
     * 由 ModEvents.onLevelTick() 每 tick 调用（只遍历非空表，开销可忽略）。
     */
    public static void tickMaxHpModifiers(net.minecraft.server.level.ServerLevel level) {
        if (MAX_HP_MODIFIER_EXPIRY.isEmpty()) return;
        long now = level.getGameTime();
        var it = MAX_HP_MODIFIER_EXPIRY.entrySet().iterator();
        while (it.hasNext()) {
            var entry = it.next();
            if (now < entry.getValue()) continue;
            it.remove();
            Entity entity = level.getEntity(entry.getKey());
            if (!(entity instanceof LivingEntity living)) continue;
            AttributeInstance maxHealth = living.getAttribute(Attributes.MAX_HEALTH);
            if (maxHealth != null) {
                maxHealth.removeModifier(maxHpModifierId(entry.getKey()));
            }
        }
    }

    private void sweepAttack(LivingEntity attacker, Entity target, int level) {
        if (!(attacker instanceof Player player)) return;
        if (player.getMainHandItem().getEnchantmentLevel(Enchantments.SWEEPING_EDGE) <= 0) return;

        var box = player.getMainHandItem().getSweepHitBox(player, target);
        for (LivingEntity le : player.level().getEntitiesOfClass(LivingEntity.class, box)) {
            if (le != player && le != target && !player.isAlliedTo(le)) {
                applyCorrosion(le);
                applyMaxHpDeduction(attacker, le);
            }
        }
    }
}
