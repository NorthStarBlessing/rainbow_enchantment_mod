package cn.autoforged.rainbow_enchantment_mod.acquisition;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import javax.annotation.Nonnull;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.common.loot.LootModifier;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 全局战利品修改器：把「不该从原版战利品里冒出来」的本模组附魔剥掉。
 *
 * <p>原版把「附魔台候选池」和「无选项的 {@code enchant_randomly}」挂在同一个 {@code isDiscoverable} 上，
 * 而 1.20.1 有 **45 处**无选项 {@code enchant_randomly}。所以只要某类附魔要进附魔池，
 * 就会顺带被原版战利品抽到 —— 这个修改器就是补上那一道闸门：
 *
 * <ul>
 *   <li>当前表是我们自己注入过的途径 → 只保留「该途径允许的」附魔（通用池 / 专属表一致）；</li>
 *   <li>当前表不是我们的途径 → 本模组附魔一律视为泄漏，全部剥掉；</li>
 *   <li>{@code vanilla_sources.allow_vanilla_random_loot = true} 时整个修改器不生效（尊重原版行为）。</li>
 * </ul>
 */
public class SourceGateModifier extends LootModifier {
    private static final Logger LOGGER = LogManager.getLogger();

    public static final Codec<SourceGateModifier> CODEC =
        RecordCodecBuilder.create(instance -> codecStart(instance).apply(instance, SourceGateModifier::new));

    public SourceGateModifier(LootItemCondition[] conditions) {
        super(conditions);
        LOGGER.info("[RainbowEnchantment] 原版战利品闸门已加载（source_gate 全局战利品修改器）");
    }

    @Nonnull
    @Override
    public Codec<? extends IGlobalLootModifier> codec() {
        return CODEC;
    }

    @Nonnull
    @Override
    protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> generatedLoot, LootContext context) {
        if (!ModAcquisition.enabled() || ModAcquisition.vanillaRandomLootAllowed()) {
            return generatedLoot;
        }
        String sourceId = ModAcquisition.sourceIdForLootTable(context.getQueriedLootTableId());
        for (int i = 0; i < generatedLoot.size(); i++) {
            ItemStack cleaned = ModAcquisition.stripLeakedEnchantments(generatedLoot.get(i), sourceId);
            if (cleaned == null) {
                generatedLoot.remove(i);
                i--;
            } else if (cleaned != generatedLoot.get(i)) {
                generatedLoot.set(i, cleaned);
            }
        }
        return generatedLoot;
    }
}
