package cn.autoforged.rainbow_enchantment_mod.acquisition;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import java.util.function.Consumer;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.entries.LootPoolEntryContainer;
import net.minecraft.world.level.storage.loot.entries.LootPoolEntryType;
import net.minecraft.world.level.storage.loot.entries.LootPoolSingletonContainer;
import net.minecraft.world.level.storage.loot.functions.LootItemFunction;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;

/**
 * 一个「按配置概率产出本模组附魔书」的战利品条目。
 *
 * <p>和「用函数把物品清空」的做法不同，这里在没命中时**根本不产出物品**，
 * 因此不会往战利品列表里塞空栈（钓鱼会把列表里每一项都变成掉落物实体，
 * 空栈会变成看不见的幽灵掉落物）。
 */
public class ModAcquisitionEntry extends LootPoolSingletonContainer {
    private final AcquisitionSource source;

    protected ModAcquisitionEntry(AcquisitionSource source, int weight, int quality,
                                  LootItemCondition[] conditions, LootItemFunction[] functions) {
        super(weight, quality, conditions, functions);
        this.source = source;
    }

    public AcquisitionSource source() {
        return this.source;
    }

    @Override
    protected void createItemStack(Consumer<ItemStack> consumer, LootContext context) {
        ItemStack stack = ModAcquisition.roll(this.source, context);
        if (!stack.isEmpty()) {
            consumer.accept(stack);
        }
    }

    @Override
    public LootPoolEntryType getType() {
        return ModLootEntries.ACQUISITION.get();
    }

    public static Builder acquisition(AcquisitionSource source) {
        return new Builder(source);
    }

    public static class Builder extends LootPoolSingletonContainer.Builder<Builder> {
        private final AcquisitionSource source;

        Builder(AcquisitionSource source) {
            this.source = source;
        }

        @Override
        protected Builder getThis() {
            return this;
        }

        @Override
        public LootPoolEntryContainer build() {
            return new ModAcquisitionEntry(this.source, this.weight, this.quality,
                this.getConditions(), this.getFunctions());
        }
    }

    public static class Serializer extends LootPoolSingletonContainer.Serializer<ModAcquisitionEntry> {
        @Override
        public void serializeCustom(JsonObject object, ModAcquisitionEntry entry,
                                    JsonSerializationContext context) {
            super.serializeCustom(object, entry, context);
            object.addProperty("source", entry.source.id());
        }

        @Override
        protected ModAcquisitionEntry deserialize(JsonObject object, JsonDeserializationContext context,
                                                  int weight, int quality, LootItemCondition[] conditions,
                                                  LootItemFunction[] functions) {
            // 数据包作者也可以直接用这个条目类型：{ "type": "rainbow_enchantment_mod:acquisition", "source": "..." }
            AcquisitionSource source = AcquisitionSource.byIdOrNull(GsonHelper.getAsString(object, "source", "ancient_city"));
            return new ModAcquisitionEntry(source == null ? AcquisitionSource.ANCIENT_CITY : source,
                weight, quality, conditions, functions);
        }
    }
}
