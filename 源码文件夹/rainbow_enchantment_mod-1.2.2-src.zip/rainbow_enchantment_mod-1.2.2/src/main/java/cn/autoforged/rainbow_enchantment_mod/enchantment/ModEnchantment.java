package cn.autoforged.rainbow_enchantment_mod.enchantment;

import cn.autoforged.rainbow_enchantment_mod.acquisition.ModEnchantTableState;
import cn.autoforged.rainbow_enchantment_mod.config.AcquisitionSection;
import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import java.util.function.Function;
import net.minecraft.ChatFormatting;
import net.minecraft.locale.Language;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraftforge.common.ForgeConfigSpec;

/**
 * 本模组所有附魔的公共基类：统一构造参数，并把「原版途径」的闸门交给获取配置。
 *
 * <p>原版有两个标记决定附魔会不会自己冒出来：
 * <ul>
 *   <li>{@code isDiscoverable()}：附魔台候选池、以及战利品表里「无选项的 {@code enchant_randomly}」都用它；</li>
 *   <li>{@code isTradeable()}：图书管理员的「随机附魔书」交易用它。</li>
 * </ul>
 *
 * <p>另外有一类附魔是**正常进附魔池**的（哈气 / 末影注视 / 蛮兵先锋 / 夜行者 / 变态 / 超级核弹 / 大运）：
 * 它们由 {@code [acquisition.enchanting.enchanting_table]} 配置点名，作为普通候选出现在三档预览里，
 * 但只在**满级附魔台**且**这次刷新命中 12.75%** 时纳入候选。
 * 由于原版把「附魔台」和「无选项 {@code enchant_randomly}」挂在同一个 {@code isDiscoverable} 上，
 * 泄漏到原版战利品的部分由 {@code SourceGateModifier}（全局战利品修改器）剥离。
 */
public abstract class ModEnchantment extends Enchantment {
    protected ModEnchantment(Rarity rarity, EnchantmentCategory category, EquipmentSlot... slots) {
        super(rarity, category, slots);
    }

    @Override
    public boolean isDiscoverable() {
        return ModEnchantTableState.isPoolMember(this)
            || flag(section -> section.allowEnchantingTable)
            || flag(section -> section.allowVanillaRandomLoot);
    }

    @Override
    public boolean isTradeable() {
        return flag(section -> section.allowVanillaVillagerBooks);
    }

    /**
     * 原版附魔台的候选过滤里有一条 {@code (!isTreasureOnly() || allowTreasure)}，而附魔台传的
     * {@code allowTreasure} 恒为 false。所以「宝藏类」附魔要想进附魔池，必须在这里对池成员放行。
     */
    @Override
    public boolean isTreasureOnly() {
        return !ModEnchantTableState.isPoolMember(this) && super.isTreasureOnly();
    }

    /** 池成员只在「这次刷新被标记纳入」时才算合法候选。 */
    @Override
    public boolean canApplyAtEnchantingTable(ItemStack stack) {
        if (ModEnchantTableState.isPoolMember(this) && !ModEnchantTableState.isMarked(stack)) {
            return false;
        }
        return super.canApplyAtEnchantingTable(stack);
    }

    /** 附魔书走的是这一条（原版方法没有 stack 参数，因此只能看「是否有物品处于已纳入状态」）。 */
    @Override
    public boolean isAllowedOnBooks() {
        if (ModEnchantTableState.isPoolMember(this)) {
            return ModEnchantTableState.anyMarked();
        }
        return super.isAllowedOnBooks();
    }

    /** 读一个布尔开关；配置还没加载时按 false 处理（= 维持「原版途径默认关闭」的安全默认）。 */
    private static boolean flag(Function<AcquisitionSection, ForgeConfigSpec.BooleanValue> getter) {
        try {
            return Boolean.TRUE.equals(getter.apply(ModConfig.COMMON.acquisition).get());
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 附魔名 + 等级后缀，并修掉原版在「等级 &gt; 10」时把翻译 key 漏到界面上的问题。
     *
     * <h2>为什么必须覆盖</h2>
     * 原版 {@code Enchantment#getFullname} 的实现是
     * {@code Component.translatable(getDescriptionId()).append(" ").append(Component.translatable("enchantment.level." + level))}，
     * 而原版的 {@code enchantment.level.*} **只定义到 10**（I~X，已从原版
     * {@code assets/minecraft/lang/en_us.json} 核实）。本模组的
     * <b>判决最高 30 级</b>、<b>永恒最高级来自 {@code eternalMaxLevel} 配置（默认 20）</b>，
     * 因此 11 级往上找不到翻译，界面会把 {@code enchantment.level.11} 这样的 key 原样拼在
     * 名字后面 —— 游戏里看到的就是「附魔名称后面挂一段英文」。
     * 创造模式标签页里这两种附魔书是按最大等级生成的，所以一悬停就能看到。
     *
     * <h2>做法</h2>
     * 等级键存在（1~10，或资源包自己补了）就照原版走，保留资源包覆盖原版等级写法的能力；
     * 缺失则用本地罗马数字兜底。{@link Language} 在客户端与服务端都可用（服务端是内置 en_us），
     * 所以这里不能改用仅有客户端的 {@code I18n}。
     */
    @Override
    public Component getFullname(int level) {
        MutableComponent name = Component.translatable(this.getDescriptionId());
        name.withStyle(this.isCurse() ? ChatFormatting.RED : ChatFormatting.GRAY);

        if (level != 1 || this.getMaxLevel() != 1) {
            String levelKey = "enchantment.level." + level;
            name.append(" ").append(Language.getInstance().has(levelKey)
                ? Component.translatable(levelKey)
                : Component.literal(toRoman(level)));
        }
        return name;
    }

    /** 1..3999 的罗马数字。原版只给到 X，这里为可配置的超高等级兜底。 */
    private static String toRoman(int value) {
        if (value <= 0 || value > 3999) {
            return String.valueOf(value);
        }
        int[] values = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String[] symbols = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        StringBuilder roman = new StringBuilder();
        int rest = value;
        for (int i = 0; i < values.length; i++) {
            while (rest >= values[i]) {
                roman.append(symbols[i]);
                rest -= values[i];
            }
        }
        return roman.toString();
    }
}
