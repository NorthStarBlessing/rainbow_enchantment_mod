package cn.autoforged.rainbow_enchantment_mod.acquisition;

import cn.autoforged.rainbow_enchantment_mod.RainbowEnchantmentMod;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * 生物死亡掉落（唤魔者 / 凋灵 / 烈焰人 / 远古守卫者）。
 *
 * <p>需求里三个「抢夺无效」的途径会忽略 {@link LivingDropsEvent#getLootingLevel()}；
 * 唤魔者受抢夺影响，加成公式可配。
 */
@Mod.EventBusSubscriber(modid = RainbowEnchantmentMod.MOD_ID)
public final class MobDropHandler {
    private MobDropHandler() {
    }

    @SubscribeEvent
    public static void onLivingDrops(LivingDropsEvent event) {
        if (!ModAcquisition.enabled()) {
            return;
        }
        LivingEntity entity = event.getEntity();
        if (!(entity.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        Player killer = event.getSource().getEntity() instanceof Player player ? player : null;
        for (MobSource source : MobSource.values()) {
            if (!ModAcquisition.matchesEntity(source.config(), entity)) {
                continue;
            }
            ItemStack drop = ModAcquisition.rollMob(source, serverLevel, killer, event.getLootingLevel());
            if (drop == null || drop.isEmpty()) {
                continue;
            }
            ItemEntity itemEntity = new ItemEntity(serverLevel, entity.getX(),
                entity.getY() + 0.5D, entity.getZ(), drop);
            itemEntity.setDefaultPickUpDelay();
            event.getDrops().add(itemEntity);
        }
    }
}
