package cn.autoforged.rainbow_enchantment_mod.enchantment;

import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import cn.autoforged.rainbow_enchantment_mod.effect.ModEffects;
import cn.autoforged.rainbow_enchantment_mod.event.ModEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;

public class FrostEnchantment extends ModEnchantment {
    public static final int NIGHT_WALKER_AMPLIFIER_FLAG = 100;

    protected FrostEnchantment(Rarity rarity, EquipmentSlot... slots) {
        super(rarity, EnchantmentCategory.WEAPON, slots);
    }

    @Override
    public int getMinCost(int level) {
        return 10 + 20 * (level - 1);
    }

    @Override
    public int getMaxCost(int level) {
        return super.getMinCost(level) + 50;
    }

    @Override
    public int getMaxLevel() {
        return 5;
    }

    @Override
    public void doPostAttack(LivingEntity attacker, Entity target, int level) {
        if (target instanceof LivingEntity livingTarget && !target.level().isClientSide) {
            applyFrostEffect(attacker, livingTarget, level);
            sweepAttack(attacker, target, level);
        }
    }

    private void applyFrostEffect(LivingEntity attacker, LivingEntity target, int level) {
        int maxAmplifier = ModConfig.COMMON.frostEffectMaxAmplifier.get();
        int amplifier = Math.min(level - 1, maxAmplifier);

        boolean nightWalkerBoost = attacker.level().isNight()
            && EnchantmentHelper.getEnchantmentLevel(ModEnchantments.NIGHT_WALKER.get(), attacker) > 0;
        if (nightWalkerBoost) {
            amplifier += NIGHT_WALKER_AMPLIFIER_FLAG;
        }

        int duration = ModConfig.COMMON.frostEffectDuration.get();
        target.addEffect(new MobEffectInstance(ModEffects.COLD.get(), duration, amplifier));

        if (attacker instanceof Player p) {
            ModEvents.COLD_APPLY_TIMES.put(target.getUUID(), target.level().getGameTime());
            ModEvents.COLD_APPLY_ATTACKER.put(target.getUUID(), p.getUUID());
        }

        if (target instanceof EnderMan enderman && !enderman.hasEffect(ModEffects.ENDER_SHACKLE.get())) {
            enderman.addEffect(new MobEffectInstance(ModEffects.ENDER_SHACKLE.get(), 60, 0));
        }
    }

    private void sweepAttack(LivingEntity attacker, Entity target, int level) {
        if (!(attacker instanceof Player player)) return;
        if (player.getMainHandItem().getEnchantmentLevel(Enchantments.SWEEPING_EDGE) <= 0) return;

        var box = player.getMainHandItem().getSweepHitBox(player, target);
        for (LivingEntity le : player.level().getEntitiesOfClass(LivingEntity.class, box)) {
            if (le != player && le != target && !player.isAlliedTo(le)) {
                applyFrostEffect(attacker, le, level);
            }
        }
    }
}
