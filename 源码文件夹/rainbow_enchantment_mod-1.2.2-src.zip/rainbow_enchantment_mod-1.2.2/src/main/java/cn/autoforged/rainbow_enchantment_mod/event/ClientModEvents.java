package cn.autoforged.rainbow_enchantment_mod.event;

import cn.autoforged.rainbow_enchantment_mod.RainbowEnchantmentMod;
import cn.autoforged.rainbow_enchantment_mod.config.ModConfig;
import cn.autoforged.rainbow_enchantment_mod.enchantment.CherryBlossomEnchantment;
import cn.autoforged.rainbow_enchantment_mod.enchantment.EternalEnchantment;
import cn.autoforged.rainbow_enchantment_mod.enchantment.ModEnchantments;
import cn.autoforged.rainbow_enchantment_mod.enchantment.StarTreasureEnchantment;
import cn.autoforged.rainbow_enchantment_mod.enchantment.StarTreasureMinerals;
import cn.autoforged.rainbow_enchantment_mod.enchantment.StarlightForceEnchantment;
import cn.autoforged.rainbow_enchantment_mod.enchantment.ThousandWindForceEnchantment;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;

@Mod.EventBusSubscriber(value = net.minecraftforge.api.distmarker.Dist.CLIENT, modid = RainbowEnchantmentMod.MOD_ID)
public final class ClientModEvents {
    private static final String RAINBOW_DYES_TAG = "rainbow_dyes";

    /**
     * 星光之力：<b>左键空气</b>时触发流星。
     *
     * <p>维护者口径：「星光之力的触发特效为，左键空气时，将会从天上射下一道流星，并砸向地面」。
     * 旧实现是"攻击命中时触发"，与原效果不一致。
     *
     * <p>这个事件是**纯客户端**的（服务端收不到"对着空气挥了一下"），所以这里只负责发包，
     * 真正的演出由服务端 {@code StarlightTriggerPacket} 开。
     */
    @SubscribeEvent
    public static void onLeftClickEmpty(net.minecraftforge.event.entity.player.PlayerInteractEvent.LeftClickEmpty event) {
        var player = event.getEntity();
        if (player == null) return;
        if (player.getMainHandItem().getEnchantmentLevel(ModEnchantments.STARLIGHT_FORCE.get()) <= 0) return;
        cn.autoforged.rainbow_enchantment_mod.event.ModEvents.requestStarlight();
    }

    @SubscribeEvent
    public static void onItemTooltip(ItemTooltipEvent event) {
        ItemStack stack = event.getItemStack();

        // 查看特殊信息的热键由配置项 misc.info_key_shift / info_key_ctrl 控制：
        // 两个都为 true（默认）时等价于原来的「Shift + Ctrl」。
        boolean hasShiftCtrl = (!ModConfig.COMMON.miscInfoKeyShift.get() || Screen.hasShiftDown())
            && (!ModConfig.COMMON.miscInfoKeyCtrl.get() || Screen.hasControlDown());

        // Rainbow dye tooltip
        handleRainbowTooltip(event, stack, hasShiftCtrl);

        // Starlight Force star count
        handleStarlightTooltip(event, stack, hasShiftCtrl);

        // Thousand Wind Force star count
        handleThousandWindTooltip(event, stack, hasShiftCtrl);

        // Eternal uses count
        handleEternalTooltip(event, stack);

        // Star Treasure forged minerals
        handleStarTreasureTooltip(event, stack, hasShiftCtrl);

        // Cherry Blossom forged count
        handleCherryBlossomTooltip(event, stack, hasShiftCtrl);
    }

    private static void handleRainbowTooltip(ItemTooltipEvent event, ItemStack stack, boolean hasShiftCtrl) {
        if (stack.getEnchantmentLevel(ModEnchantments.RAINBOW.get()) <= 0) return;

        CompoundTag tag = stack.getTag();
        boolean hasDyes = tag != null && tag.contains(RAINBOW_DYES_TAG, 9) && !tag.getList(RAINBOW_DYES_TAG, 8).isEmpty();

        if (!hasShiftCtrl) {
            if (hasDyes) {
                event.getToolTip().add(Component.translatable("tooltip.rainbow_enchantment_mod.dyes_hint")
                    .withStyle(ChatFormatting.DARK_GRAY));
            }
            return;
        }

        if (!hasDyes) return;

        ListTag dyesList = tag.getList(RAINBOW_DYES_TAG, 8);

        Map<String, Integer> colorCounts = new HashMap<>();
        for (int i = 0; i < dyesList.size(); i++) {
            String colorName = dyesList.getString(i);
            colorCounts.merge(colorName, 1, Integer::sum);
        }

        event.getToolTip().add(Component.literal(""));
        event.getToolTip().add(Component.translatable("tooltip.rainbow_enchantment_mod.dyes_header")
            .withStyle(ChatFormatting.LIGHT_PURPLE));

        for (Map.Entry<String, Integer> entry : colorCounts.entrySet()) {
            String colorKey = "color.minecraft." + entry.getKey();
            Component colorName = Component.translatable(colorKey);
            Component line = Component.literal("  ")
                .append(colorName)
                .append(Component.literal(": "))
                .append(Component.literal(String.valueOf(entry.getValue())))
                .append(Component.translatable("tooltip.rainbow_enchantment_mod.times"))
                .withStyle(ChatFormatting.GRAY);
            event.getToolTip().add(line);
        }
    }

    private static void handleStarlightTooltip(ItemTooltipEvent event, ItemStack stack, boolean hasShiftCtrl) {
        if (stack.getEnchantmentLevel(ModEnchantments.STARLIGHT_FORCE.get()) <= 0) return;
        int stars = StarlightForceEnchantment.getStarCount(stack);
        int maxStars = ModConfig.COMMON.netherStarForgeLimit.get();

        if (!hasShiftCtrl) {
            if (stars > 0) {
                event.getToolTip().add(Component.translatable("tooltip.rainbow_enchantment_mod.starlight_hint")
                    .withStyle(ChatFormatting.DARK_GRAY));
            }
            return;
        }

        event.getToolTip().add(Component.literal(""));
        event.getToolTip().add(Component.translatable("tooltip.rainbow_enchantment_mod.starlight_header")
            .withStyle(ChatFormatting.LIGHT_PURPLE));
        // 上限取自配置，不再写死 20
        event.getToolTip().add(Component.translatable("tooltip.rainbow_enchantment_mod.star_count",
                stars, maxStars)
            .withStyle(ChatFormatting.GRAY));
    }

    private static void handleThousandWindTooltip(ItemTooltipEvent event, ItemStack stack, boolean hasShiftCtrl) {
        if (stack.getEnchantmentLevel(ModEnchantments.THOUSAND_WIND_FORCE.get()) <= 0) return;
        int stars = ThousandWindForceEnchantment.getStarCount(stack);
        int maxStars = ModConfig.COMMON.netherStarForgeLimit.get();

        if (!hasShiftCtrl) {
            if (stars > 0) {
                event.getToolTip().add(Component.translatable("tooltip.rainbow_enchantment_mod.thousand_wind_hint")
                    .withStyle(ChatFormatting.DARK_GRAY));
            }
            return;
        }

        event.getToolTip().add(Component.literal(""));
        event.getToolTip().add(Component.translatable("tooltip.rainbow_enchantment_mod.thousand_wind_header")
            .withStyle(ChatFormatting.LIGHT_PURPLE));
        event.getToolTip().add(Component.translatable("tooltip.rainbow_enchantment_mod.star_count",
                stars, maxStars)
            .withStyle(ChatFormatting.GRAY));
    }

    private static void handleEternalTooltip(ItemTooltipEvent event, ItemStack stack) {
        if (stack.getEnchantmentLevel(ModEnchantments.ETERNAL.get()) <= 0) return;
        int remaining = EternalEnchantment.getRemainingUses(stack);
        int maxUses = EternalEnchantment.getMaxUses(stack.getEnchantmentLevel(ModEnchantments.ETERNAL.get()));

        event.getToolTip().add(Component.translatable("tooltip.rainbow_enchantment_mod.eternal_uses",
                remaining, maxUses)
            .withStyle(ChatFormatting.GOLD));
    }

    private static void handleStarTreasureTooltip(ItemTooltipEvent event, ItemStack stack, boolean hasShiftCtrl) {
        if (stack.getEnchantmentLevel(ModEnchantments.STAR_TREASURE.get()) <= 0) return;

        var tag = stack.getTag();
        if (tag == null || !tag.contains(StarTreasureEnchantment.STAR_TREASURE_DATA_TAG, 10)) return;
        CompoundTag data = tag.getCompound(StarTreasureEnchantment.STAR_TREASURE_DATA_TAG);

        boolean any = false;
        for (StarTreasureMinerals mineral : StarTreasureMinerals.all()) {
            if (mineral.getCount(data) > 0) {
                any = true;
                break;
            }
        }
        if (!any) return;

        if (!hasShiftCtrl) {
            event.getToolTip().add(Component.translatable("tooltip.rainbow_enchantment_mod.star_treasure_hint")
                .withStyle(ChatFormatting.DARK_GRAY));
            return;
        }

        event.getToolTip().add(Component.literal(""));
        event.getToolTip().add(Component.translatable("tooltip.rainbow_enchantment_mod.star_treasure_header")
            .withStyle(ChatFormatting.LIGHT_PURPLE));

        // 逐类列出「已锻造计数 / 计数上限」，颜色按矿物主色区分
        for (StarTreasureMinerals mineral : StarTreasureMinerals.all()) {
            int count = mineral.getCount(data);
            if (count <= 0) continue;
            event.getToolTip().add(Component.translatable(
                    "tooltip.rainbow_enchantment_mod.star_treasure_mineral." + mineral.getKey(),
                    count, mineral.getLimit())
                .withStyle(colorOf(mineral)));
        }

        // 汇总：当前三类加成的实际数值（已经过总上限截断，与属性计算同一套口径）
        StarTreasureMinerals.Stats stats = StarTreasureMinerals.computeStats(tag);
        if (stats.damage() > 0) {
            event.getToolTip().add(Component.translatable(
                    "tooltip.rainbow_enchantment_mod.star_treasure_total.damage",
                    formatBonus(stats.damage()))
                .withStyle(ChatFormatting.RED));
        }
        if (stats.speed() > 0) {
            event.getToolTip().add(Component.translatable(
                    "tooltip.rainbow_enchantment_mod.star_treasure_total.speed",
                    formatBonus(stats.speed()))
                .withStyle(ChatFormatting.YELLOW));
        }
        if (stats.durability() > 0) {
            event.getToolTip().add(Component.translatable(
                    "tooltip.rainbow_enchantment_mod.star_treasure_total.durability",
                    formatBonus(stats.durability()))
                .withStyle(ChatFormatting.GRAY));
        }
    }

    /** 每种矿物的 tooltip 颜色，与它的主色一致。 */
    private static ChatFormatting colorOf(StarTreasureMinerals mineral) {
        return switch (mineral) {
            case IRON -> ChatFormatting.DARK_GRAY;
            case DIAMOND -> ChatFormatting.AQUA;
            case EMERALD -> ChatFormatting.GREEN;
            case AMETHYST -> ChatFormatting.LIGHT_PURPLE;
            case REDSTONE -> ChatFormatting.RED;
            case ECHO_SHARD -> ChatFormatting.DARK_AQUA;
            case GLOWSTONE -> ChatFormatting.YELLOW;
            case STONE -> ChatFormatting.GRAY;
            case END_STONE -> ChatFormatting.WHITE;
            case OBSIDIAN -> ChatFormatting.DARK_PURPLE;
            case BLACKSTONE -> ChatFormatting.DARK_RED;
            case NETHERITE -> ChatFormatting.DARK_GRAY;
            case LAPIS -> ChatFormatting.BLUE;
            case QUARTZ -> ChatFormatting.WHITE;
            case GOLD -> ChatFormatting.GOLD;
            case COPPER -> ChatFormatting.GOLD;
            case MOD_ORE -> ChatFormatting.LIGHT_PURPLE;
        };
    }

    /** 加成数值格式化：整数不显示小数点（+10 而不是 +10.0），小数最多两位。 */
    private static String formatBonus(double value) {
        if (Math.abs(value - Math.rint(value)) < 1.0e-6) {
            return String.valueOf((long) Math.rint(value));
        }
        return String.format(java.util.Locale.ROOT, "%.2f", value);
    }

    private static void handleCherryBlossomTooltip(ItemTooltipEvent event, ItemStack stack, boolean hasShiftCtrl) {
        if (stack.getEnchantmentLevel(ModEnchantments.CHERRY_BLOSSOM.get()) <= 0) return;

        var tag = stack.getTag();
        if (tag == null) return;
        int count = tag.getInt(CherryBlossomEnchantment.CHERRY_BLOSSOM_COUNT_TAG);
        if (count <= 0) return;

        if (!hasShiftCtrl) {
            event.getToolTip().add(Component.translatable("tooltip.rainbow_enchantment_mod.cherry_blossom_hint")
                .withStyle(ChatFormatting.DARK_GRAY));
            return;
        }

        // 上限按物品类别取（与锻造时用的是同一套配置），不再只显示一个裸数字
        var item = stack.getItem();
        var c = ModConfig.COMMON;
        int max;
        if (item instanceof net.minecraft.world.item.ArmorItem) max = c.cherryBlossomMaxArmor.get();
        else if (item.isEdible()) max = c.cherryBlossomMaxFood.get();
        else if (item instanceof net.minecraft.world.item.SwordItem) max = c.cherryBlossomMaxWeapon.get();
        else if (item instanceof net.minecraft.world.item.DiggerItem) max = c.cherryBlossomMaxTool.get();
        else max = count;

        event.getToolTip().add(Component.literal(""));
        event.getToolTip().add(Component.translatable("tooltip.rainbow_enchantment_mod.cherry_blossom_header")
            .withStyle(ChatFormatting.LIGHT_PURPLE));
        event.getToolTip().add(Component.translatable("tooltip.rainbow_enchantment_mod.cherry_blossom_count",
                count, max)
            .withStyle(ChatFormatting.GRAY));
    }
}
