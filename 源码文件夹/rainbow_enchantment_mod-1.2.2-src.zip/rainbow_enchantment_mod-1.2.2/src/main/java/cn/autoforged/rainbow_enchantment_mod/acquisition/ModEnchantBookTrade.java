package cn.autoforged.rainbow_enchantment_mod.acquisition;

import cn.autoforged.rainbow_enchantment_mod.config.AcquisitionSection;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.npc.VillagerTrades;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraft.world.item.trading.MerchantOffer;

/**
 * 图书管理员（附魔师）出售本模组附魔书的交易条目。
 *
 * <p>概率的口径：配置里的 {@code chance_by_tier} 表示「该等级的图书管理员真的会卖一本
 * 本模组附魔书」的**最终概率**。原版的选法是从该等级的交易数组里随机抽 2 条
 * （{@code Villager#updateTrades} -&gt; {@code addOffersFromItemListings(..., 2)}），
 * 所以本条被抓到的概率是 {@code min(1, 2 / N)}（N = 该等级交易条数）。代码用
 * {@code 目标概率 / 被抓概率} 反推本条内部的判定概率，从而让最终概率等于配置值；
 * 关掉 {@code compensate_selection} 时就直接用配置值判定（出现率会偏低）。
 */
public class ModEnchantBookTrade implements VillagerTrades.ItemListing {
    /** 原版 {@code Villager#updateTrades} 每个等级抽几条交易。 */
    private static final int VANILLA_PICKS = 2;

    private final int tier;
    private final List<VillagerTrades.ItemListing> siblings;
    private final double finalChance;

    public ModEnchantBookTrade(int tier, List<VillagerTrades.ItemListing> siblings, double finalChance) {
        this.tier = tier;
        this.siblings = siblings;
        this.finalChance = finalChance;
    }

    @Nullable
    @Override
    public MerchantOffer getOffer(Entity trader, RandomSource random) {
        AcquisitionSection.Librarian cfg = ModAcquisition.section().librarian;
        boolean compensate;
        try {
            compensate = cfg.compensateSelection.get();
        } catch (Exception e) {
            compensate = true;
        }

        double judged = this.finalChance;
        if (compensate) {
            int count = Math.max(1, this.siblings.size());
            double selected = Math.min(1.0D, (double) VANILLA_PICKS / (double) count);
            judged = Math.min(1.0D, this.finalChance / selected);
        }
        if (random.nextDouble() >= judged) {
            return null;
        }

        int levelMin = tierValue(cfg.levelMinByTier.get(), this.tier, defaultLevelMin(this.tier));
        int levelMax = tierValue(cfg.levelMaxByTier.get(), this.tier, defaultLevelMax(this.tier));
        EnchantmentInstance instance = ModAcquisition.pickInstance(levelMin, levelMax, random);
        if (instance == null) {
            return null;
        }

        ItemStack book = EnchantedBookItem.createForEnchantment(instance);
        int cost = this.emeraldCost(instance, random, cfg);
        int xp = tierValue(cfg.xpByTier.get(), this.tier, 10);
        int maxUses = intValue(cfg.maxUses.get(), 12);
        float priceMultiplier = doubleValue(cfg.priceMultiplier.get(), 0.2D, 0.0D, 1.0D);
        return new MerchantOffer(new ItemStack(Items.EMERALD, cost), new ItemStack(Items.BOOK),
            book, maxUses, xp, priceMultiplier);
    }

    /** 沿用原版 {@code EnchantBookForEmeralds} 的定价公式，只是全部改为可配置。 */
    private int emeraldCost(EnchantmentInstance instance, RandomSource random, AcquisitionSection.Librarian cfg) {
        int base = intValue(cfg.emeraldBase.get(), 2);
        int randomBound = intValue(cfg.emeraldRandomBound.get(), 5);
        int perLevel = intValue(cfg.emeraldPerEnchantLevel.get(), 10);
        int flatPerLevel = intValue(cfg.emeraldFlatPerEnchantLevel.get(), 3);
        int cap = intValue(cfg.emeraldCap.get(), 64);
        double treasureFactor = doubleValue(cfg.treasurePriceFactor.get(), 2.0D, 1.0D, 10.0D);
        int level = instance.level;

        int bound = randomBound + level * perLevel;
        int cost = base + (bound > 0 ? random.nextInt(bound) : 0) + flatPerLevel * level;
        if (instance.enchantment.isTreasureOnly()) {
            cost = (int) Math.round(cost * treasureFactor);
        }
        return Mth.clamp(cost, 1, Math.max(1, cap));
    }

    private static int defaultLevelMin(int tier) {
        return switch (tier) {
            case 1, 2 -> 1;
            case 3 -> 2;
            case 4 -> 3;
            default -> 4;
        };
    }

    private static int defaultLevelMax(int tier) {
        return switch (tier) {
            case 1, 2 -> 3;
            case 3 -> 4;
            default -> 5;
        };
    }

    private static int tierValue(List<? extends Integer> list, int tier, int fallback) {
        if (list == null || tier < 1 || tier > list.size()) {
            return fallback;
        }
        Integer value = list.get(tier - 1);
        return value == null ? fallback : value;
    }

    private static int intValue(Integer value, int fallback) {
        return value == null ? fallback : value;
    }

    private static float doubleValue(Double value, double fallback, double min, double max) {
        double v = value == null ? fallback : value;
        return (float) Mth.clamp(v, min, max);
    }
}
