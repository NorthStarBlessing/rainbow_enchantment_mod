package cn.autoforged.rainbow_enchantment_mod.mixin;

import cn.autoforged.rainbow_enchantment_mod.enchantment.UndyingGuard;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.game.ClientboundPlayerCombatKillPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 客户端：不死保护期间不打开死亡界面（仅客户端加载，见 mixins.json 的 client 列表）。
 *
 * <h2>为什么只做这一件事</h2>
 * 死亡界面的来源只有一处：客户端收到「你死了」这个包之后，自己 new 一个死亡界面并打开它。
 * 所以在这里把整个包处理取消掉，界面上就什么都不会发生 —— 这是<b>确定性</b>的做法，
 * 不需要跟任何人抢。
 *
 * <h2>绝对不做的事（踩过的坑）</h2>
 * <b>这里绝不调用「打开界面」的方法。</b> 打开界面这个方法自己会再抛一次「界面即将打开」的
 * 通知，而原版在「玩家处于濒死状态」时会把「要打开空界面」自动换成一个新的死亡界面 ——
 * 于是在「界面即将打开」的回调里再调一次打开界面，就会变成
 * 打开界面 → 通知 → 回调 → 再打开界面 → … 的无限递归，直接把栈打爆、整个客户端卡死。
 * 所以：只取消包处理，不碰界面。
 *
 * <p>另一条相关的保险在 {@link LivingEntityGuardMixin}：保护窗口内客户端也认为「没死」，
 * 于是任何「打开空界面」的路径都不会被原版换成死亡界面。
 */
@Mixin(ClientPacketListener.class)
public abstract class ClientPacketListenerGuardMixin {

    @Inject(method = "handlePlayerCombatKill", at = @At("HEAD"), cancellable = true)
    private void rainbow$skipDeathScreen(ClientboundPlayerCombatKillPacket packet, CallbackInfo ci) {
        try {
            LocalPlayer player = Minecraft.getInstance().player;
            if (player != null && UndyingGuard.isGuarded(player)) {
                // 取消整个包处理：原版随后的「打开死亡界面」与客户端重生都跳过。
                ci.cancel();
                // 清掉客户端自己留下的死亡痕迹（计时、受伤动画），不发包、不碰界面。
                UndyingGuard.recover(player);
            }
        } catch (Throwable ignored) {
            // 失败一律放行
        }
    }
}
