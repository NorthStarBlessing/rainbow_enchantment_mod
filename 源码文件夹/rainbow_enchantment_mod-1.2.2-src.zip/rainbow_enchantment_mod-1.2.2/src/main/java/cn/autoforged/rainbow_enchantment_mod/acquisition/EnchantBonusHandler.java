package cn.autoforged.rainbow_enchantment_mod.acquisition;

import cn.autoforged.rainbow_enchantment_mod.RainbowEnchantmentMod;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.inventory.EnchantmentMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.EnchantmentTableBlock;
import net.minecraftforge.event.entity.player.PlayerXpEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * 附魔台的两条隐藏机制（12.75% 追加 7 个附魔之一 / 15.55% 追加判决）。
 *
 * <p><b>为什么挂在这里</b>：Forge 1.20.1 没有「附魔完成」事件，唯一的入口是
 * {@code PlayerXpEvent.LevelChange} —— 它由 {@code Player#giveExperienceLevels} 触发，
 * 而附魔菜单 {@code EnchantmentMenu#clickMenuButton} 在**原版把附魔写进物品之前**正好调用了
 * {@code player.onEnchantmentPerformed(...)}（扣经验）。所以：
 * <ul>
 *   <li>时机精确：只在真正附魔成功时触发（失败时原版不会扣经验）；</li>
 *   <li>顺序正确：我们追加的附魔会跟着原版流程一起落到最终物品上
 *       （普通物品是同一个 ItemStack；书会被原版转成附魔书并整份复制 NBT）；</li>
 *   <li>不需要 Mixin、也不需要改 accesstransformer。</li>
 * </ul>
 *
 * <p>书架威力用 {@link EnchantmentTableBlock} 的公开工具方法在附魔瞬间现算（找玩家附近最近的附魔台）。
 */
@Mod.EventBusSubscriber(modid = RainbowEnchantmentMod.MOD_ID)
public final class EnchantBonusHandler {
    private static final int SEARCH_RADIUS_XZ = 8;
    private static final int SEARCH_RADIUS_Y = 4;

    private EnchantBonusHandler() {
    }

    /**
     * 附魔台每次刷新三档候选时都会按行触发本事件（k = 0,1,2）。
     * 我们只处理第 0 行，掷一次「满级附魔台附加池 12.75%」并把结果绑到槽位里的物品上；
     * 之后原版算候选列表（{@code ModEnchantment#isDiscoverable} 等）就会读到这个标记。
     */
    @SubscribeEvent
    public static void onEnchantmentLevelSet(net.minecraftforge.event.enchanting.EnchantmentLevelSetEvent event) {
        if (event.getEnchantRow() != 0 || !ModAcquisition.enabled()) {
            return;
        }
        ModEnchantTableState.refreshMark(event.getItem(), event.getPower(), event.getLevel().getRandom());
    }

    /** 关闭附魔界面时清掉标记，避免状态残留。 */
    @SubscribeEvent
    public static void onContainerClose(net.minecraftforge.event.entity.player.PlayerContainerEvent.Close event) {
        if (event.getContainer() instanceof EnchantmentMenu menu) {
            ModEnchantTableState.clear(menu.getSlot(0).getItem());
        }
    }

    @SubscribeEvent
    public static void onXpLevelChange(PlayerXpEvent.LevelChange event) {
        if (event.getLevels() >= 0) {
            return;   // 只关心「扣经验」（附魔消耗等级）
        }
        if (!ModAcquisition.enabled()) {
            return;
        }
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        if (!(player.containerMenu instanceof EnchantmentMenu menu)) {
            return;
        }
        int row = -event.getLevels();
        if (row < 1 || row > 3) {
            return;   // 附魔台只扣 1~3 级；其它扣级（/xp、铁砧等）不在这里
        }
        ItemStack stack = menu.getSlot(0).getItem();
        if (stack.isEmpty()) {
            return;
        }
        ModAcquisition.applyEnchantingBonuses(player, stack, bookshelfPower(player), player.getRandom());
    }

    /** 玩家附近最近附魔台的书架威力（0~15）；找不到附魔台时返回 0。 */
    private static int bookshelfPower(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        BlockPos center = player.blockPosition();
        BlockPos tablePos = null;
        double bestDistance = Double.MAX_VALUE;
        for (BlockPos pos : BlockPos.betweenClosed(
                center.offset(-SEARCH_RADIUS_XZ, -SEARCH_RADIUS_Y, -SEARCH_RADIUS_XZ),
                center.offset(SEARCH_RADIUS_XZ, SEARCH_RADIUS_Y, SEARCH_RADIUS_XZ))) {
            if (!level.getBlockState(pos).is(Blocks.ENCHANTING_TABLE)) {
                continue;
            }
            double distance = pos.distSqr(center);
            if (distance < bestDistance) {
                bestDistance = distance;
                tablePos = pos.immutable();
            }
        }
        if (tablePos == null) {
            return 0;
        }
        float power = 0.0F;
        for (BlockPos offset : EnchantmentTableBlock.BOOKSHELF_OFFSETS) {
            if (!EnchantmentTableBlock.isValidBookShelf(level, tablePos, offset)) {
                continue;
            }
            BlockPos shelf = tablePos.offset(offset);
            power += level.getBlockState(shelf).getEnchantPowerBonus(level, shelf);
        }
        return Mth.floor(power);
    }
}
